package com.sanstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DeveloperActivity extends Activity {
    private LinearLayout content;
    private LinearLayout actions;
    private LinearLayout publishedApps;
    private TextView publishedAppsHeading;
    private TextView accessStatus;
    private TextView publisherStatus;
    private boolean resumedOnce;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
        refreshAccess();
    }

    @Override protected void onResume() {
        super.onResume();
        if (resumedOnce) refreshAccess();
        else resumedOnce = true;
    }

    private void render() {
        content = StoreUi.screen(this, "Desenvolvedor", "Publicações analisadas pelo administrador", true);

        LinearLayout hero = StoreUi.vertical(this);
        hero.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18));
        hero.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 24), 0xff354767));
        hero.setElevation(StoreUi.dp(this, 6));
        hero.addView(StoreUi.badge(this, "ÁREA DO DESENVOLVEDOR", 0xff2b3d61, 0xffd7e2ff));
        TextView info = StoreUi.text(this,
                "Envie aplicativos para análise, acompanhe os publicados e submeta atualizações ao administrador.",
                14, StoreUi.TEXT, false);
        info.setLineSpacing(StoreUi.dp(this, 3), 1f);
        info.setPadding(0, StoreUi.dp(this, 12), 0, 0);
        hero.addView(info);
        content.addView(hero);

        StoreUi.section(this, content, "Status de desenvolvedor");
        accessStatus = StoreUi.text(this, "Verificando acesso…", 13, StoreUi.MUTED, false);
        accessStatus.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 13), StoreUi.dp(this, 14), StoreUi.dp(this, 13));
        accessStatus.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 17), 0xff2b3a53));
        accessStatus.setElevation(StoreUi.dp(this, 4));
        content.addView(accessStatus);

        StoreUi.section(this, content, "Publicador exibido na loja");
        publisherStatus = StoreUi.text(this, "Carregando nome público…", 13, StoreUi.MUTED, false);
        publisherStatus.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 13), StoreUi.dp(this, 14), StoreUi.dp(this, 13));
        publisherStatus.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 17), 0xff2b3a53));
        publisherStatus.setElevation(StoreUi.dp(this, 4));
        content.addView(publisherStatus);

        actions = StoreUi.vertical(this);
        StoreUi.gap(this, content, 10);
        content.addView(actions);

        publishedAppsHeading = StoreUi.text(this, "Seus aplicativos publicados", 18, StoreUi.TEXT, true);
        publishedAppsHeading.setPadding(0, StoreUi.dp(this, 22), 0, StoreUi.dp(this, 12));
        publishedAppsHeading.setVisibility(View.GONE);
        content.addView(publishedAppsHeading);
        publishedApps = StoreUi.vertical(this);
        content.addView(publishedApps);

        Button settings = StoreUi.button(this, "⚙  Configurar conexão da API", false);
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52));
        settingsParams.topMargin = StoreUi.dp(this, 16);
        content.addView(settings, settingsParams);
    }

    private void refreshAccess() {
        if (actions == null) return;
        ApiClient.getDeveloperAccess(this, (access, error) -> {
            if (isFinishing()) return;
            actions.removeAllViews();
            publishedAppsHeading.setVisibility(View.GONE);
            publishedApps.removeAllViews();
            if (error != null) {
                publisherStatus.setText("Não foi possível consultar o publicador desta conta.");
                accessStatus.setText("Não foi possível consultar o acesso. Tente novamente.");
                accessStatus.setTextColor(StoreUi.GOLD);
                Button retry = StoreUi.button(this, "Tentar novamente", false);
                retry.setOnClickListener(v -> refreshAccess());
                actions.addView(retry, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));
                return;
            }
            String publisher = access.developerName == null || access.developerName.trim().isEmpty()
                    ? access.developerAccount : access.developerName;
            publisherStatus.setText(publisher == null || publisher.trim().isEmpty()
                    ? "O administrador ainda não definiu o nome público desta conta."
                    : "Os aplicativos desta conta aparecem como: " + publisher.trim());
            switch (access.status) {
                case "active":
                    accessStatus.setText("✓  Acesso aprovado. Você pode enviar publicações para análise.");
                    accessStatus.setTextColor(StoreUi.GREEN);
                    Button add = StoreUi.button(this, "＋  Enviar aplicativo ou jogo", true);
                    add.setOnClickListener(v -> startActivity(new Intent(this, PublishAppActivity.class)));
                    actions.addView(add, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
                    publishedAppsHeading.setVisibility(View.VISIBLE);
                    loadDeveloperApps();
                    break;
                case "pending":
                    accessStatus.setText("◷  Solicitação em análise. O administrador vai liberar o acesso.");
                    accessStatus.setTextColor(StoreUi.GOLD);
                    break;
                case "suspended":
                    accessStatus.setText("Acesso de desenvolvedor suspenso. Fale com o administrador da loja.");
                    accessStatus.setTextColor(StoreUi.GOLD);
                    break;
                default:
                    accessStatus.setText("Ainda não há acesso de desenvolvedor nesta conta.");
                    accessStatus.setTextColor(StoreUi.MUTED);
                    Button request = StoreUi.button(this, "Solicitar acesso de desenvolvedor", true);
                    request.setOnClickListener(v -> requestAccess(request));
                    actions.addView(request, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
                    break;
            }
        });
    }

    private void loadDeveloperApps() {
        ApiClient.getDeveloperApps(this, (apps, error) -> {
            if (isFinishing()) return;
            publishedApps.removeAllViews();
            if (error != null) {
                publishedApps.addView(StoreUi.text(this,
                        "Não foi possível carregar seus apps publicados. Volte a esta tela para tentar novamente.",
                        13, StoreUi.MUTED, false));
                return;
            }
            if (apps == null || apps.isEmpty()) {
                publishedApps.addView(StoreUi.text(this,
                        "Depois que uma publicação for aprovada, ela aparecerá aqui para você enviar atualizações.",
                        13, StoreUi.MUTED, false));
                return;
            }
            for (ApiClient.DeveloperApp entry : apps) addPublishedApp(entry);
        });
    }

    private void addPublishedApp(ApiClient.DeveloperApp entry) {
        AppItem app = entry.app;
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        card.setElevation(StoreUi.dp(this, 5));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = StoreUi.dp(this, 10);
        publishedApps.addView(card, params);
        card.addView(StoreUi.text(this, app.name, 16, StoreUi.TEXT, true));
        TextView meta = StoreUi.text(this,
                ("Game".equals(app.category) ? "Jogo" : "Aplicativo") + " · " + app.category +
                        (app.subcategory.isEmpty() ? "" : " · " + app.subcategory),
                12, StoreUi.MUTED, false);
        meta.setPadding(0, StoreUi.dp(this, 4), 0, StoreUi.dp(this, 8));
        card.addView(meta);

        if ("removed".equals(entry.status)) {
            card.addView(StoreUi.badge(this, "REMOVIDO DA LOJA", 0xff4b2830, 0xffffc2ca));
            TextView removed = StoreUi.text(this,
                    "A apelação foi recusada. O app foi removido do catálogo; o registro fica visível nesta conta para consulta.",
                    12, StoreUi.GOLD, false);
            removed.setPadding(0, StoreUi.dp(this, 8), 0, 0);
            card.addView(removed);
            return;
        }

        if (app.blocked) {
            card.addView(StoreUi.badge(this, "🔒 BLOQUEADO NA SAN STORE", 0xff4b2830, 0xffffc2ca));
            String blockMessage = app.blockReason == null || app.blockReason.trim().isEmpty()
                    ? "Os downloads deste app estão suspensos." : app.blockReason.trim();
            TextView blocked = StoreUi.text(this, blockMessage, 12, StoreUi.GOLD, false);
            blocked.setPadding(0, StoreUi.dp(this, 7), 0, StoreUi.dp(this, 10));
            card.addView(blocked);

            if ("pending".equals(entry.appealStatus)) {
                TextView pending = StoreUi.text(this, "Apelação enviada e aguardando análise do administrador.",
                        12, StoreUi.GOLD, true);
                pending.setPadding(0, 0, 0, StoreUi.dp(this, 8));
                card.addView(pending);
                Button waiting = StoreUi.button(this, "Apelação em análise", false);
                waiting.setEnabled(false);
                card.addView(waiting, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
            } else {
                Button appeal = StoreUi.button(this, "Pedir desbloqueio ao administrador", true);
                card.addView(appeal, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
                appeal.setOnClickListener(view -> requestUnblockAppeal(app, appeal));
            }
            return;
        }

        if ("approved".equals(entry.appealStatus)) {
            TextView approved = StoreUi.text(this, "Apelação aprovada. O app foi desbloqueado.", 12, StoreUi.GREEN, true);
            approved.setPadding(0, 0, 0, StoreUi.dp(this, 8));
            card.addView(approved);
        }
        if (entry.pendingUpdate) {
            TextView pending = StoreUi.text(this,
                    "Alteração em análise. A versão atual continua publicada.", 12, StoreUi.GOLD, true);
            pending.setPadding(0, 0, 0, StoreUi.dp(this, 8));
            card.addView(pending);
        } else if ("rejected".equals(entry.latestUpdateStatus)) {
            String note = entry.rejectionReason == null || entry.rejectionReason.trim().isEmpty()
                    ? "A última atualização foi recusada. Você pode corrigir e enviar novamente."
                    : "Última atualização recusada: " + entry.rejectionReason;
            TextView rejected = StoreUi.text(this, note, 12, StoreUi.GOLD, false);
            rejected.setPadding(0, 0, 0, StoreUi.dp(this, 8));
            card.addView(rejected);
        } else if ("approved".equals(entry.latestUpdateStatus)) {
            TextView approved = StoreUi.text(this, "Última atualização aprovada.", 12, StoreUi.GREEN, false);
            approved.setPadding(0, 0, 0, StoreUi.dp(this, 8));
            card.addView(approved);
        }
        Button edit = StoreUi.button(this,
                entry.pendingUpdate ? "Atualização aguardando aprovação" : "Editar e reenviar atualização",
                !entry.pendingUpdate);
        edit.setEnabled(!entry.pendingUpdate);
        card.addView(edit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
        edit.setOnClickListener(v -> startActivity(StoreUi.appIntent(this, EditPublishedAppActivity.class, app)));
    }

    private void requestUnblockAppeal(AppItem app, Button button) {
        EditText message = StoreUi.input(this, "Explique por que o app deve ser desbloqueado", true);
        new AlertDialog.Builder(this)
                .setTitle("Apelar do bloqueio")
                .setMessage("O pedido será enviado ao administrador SAN STORE, que poderá desbloquear o app ou removê-lo da loja.")
                .setView(message)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Enviar apelação", (dialog, which) -> {
                    String explanation = message.getText().toString().trim();
                    if (explanation.length() < 10 || explanation.length() > 1000) {
                        Toast.makeText(this, "Explique o pedido em 10 a 1000 caracteres.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    button.setEnabled(false);
                    button.setText("Enviando apelação…");
                    ApiClient.submitAppAppeal(this, app.id, explanation, (response, error) -> {
                        if (isFinishing()) return;
                        if (error != null) {
                            button.setEnabled(true);
                            button.setText("Pedir desbloqueio ao administrador");
                            Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
                            return;
                        }
                        Toast.makeText(this, "Apelação enviada para análise.", Toast.LENGTH_LONG).show();
                        loadDeveloperApps();
                    });
                })
                .show();
    }

    private void requestAccess(Button button) {
        button.setEnabled(false);
        button.setText("Enviando solicitação…");
        ApiClient.requestDeveloperAccess(this, (access, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                button.setEnabled(true);
                button.setText("Tentar solicitar novamente");
                accessStatus.setText(error.getMessage());
                accessStatus.setTextColor(StoreUi.GOLD);
            } else {
                refreshAccess();
            }
        });
    }
}
