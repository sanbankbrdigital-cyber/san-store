package com.sanstore.admin;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Periodic, battery-aware fallback. Android may defer this job; it is not push messaging. */
public class AppealCheckJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            boolean retry = false;
            try {
                String token = AdminApi.token(this);
                if (token == null || token.isEmpty()) {
                    AppealNotifications.cancel(this);
                } else {
                    HttpURLConnection connection = null;
                    try {
                        URL url = new URL(AdminApi.BASE + "/api/admin/appeals?status=pending");
                        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalStateException("HTTPS required");
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("GET");
                        connection.setConnectTimeout(15_000);
                        connection.setReadTimeout(20_000);
                        connection.setUseCaches(false);
                        connection.setRequestProperty("Accept", "application/json");
                        connection.setRequestProperty("Authorization", "Bearer " + token);
                        int status = connection.getResponseCode();
                        if (status == 200) {
                            InputStream input = connection.getInputStream();
                            StringBuilder body = new StringBuilder();
                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                                String line;
                                while ((line = reader.readLine()) != null) body.append(line);
                            }
                            JSONArray appeals = new JSONArray(body.toString());
                            JSONObject latest = appeals.optJSONObject(0);
                            if (latest != null) {
                                String appealId = latest.optString("id", "");
                                boolean notificationAllowed = Build.VERSION.SDK_INT < 33 ||
                                        checkSelfPermission("android.permission.POST_NOTIFICATIONS") == android.content.pm.PackageManager.PERMISSION_GRANTED;
                                if (notificationAllowed && AppealNotifications.markNew(this, appealId)) {
                                    AppealNotifications.show(this,
                                            latest.optString("appName", "Aplicativo"),
                                            latest.optString("developerName", latest.optString("developerAccount", "Desenvolvedor")),
                                            appeals.length());
                                }
                            }
                        } else if (status == 401 || status == 403) {
                            AppealNotifications.cancel(this);
                        } else {
                            retry = true;
                        }
                    } finally {
                        if (connection != null) connection.disconnect();
                    }
                }
            } catch (Exception ignored) {
                retry = true;
            }
            jobFinished(params, retry);
        }, "san-store-appeal-check").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        return true;
    }
}
