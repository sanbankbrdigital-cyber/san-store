package com.sanstore.admin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

public final class AppealNotifications {
    public static final String CHANNEL_ID = "san_store_app_appeals";
    public static final int NOTIFICATION_ID = 7418;
    public static final int JOB_ID = 7417;
    private static final String PREFS = "admin_appeal_notifications";

    private AppealNotifications() { }

    public static void schedule(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        if (Build.VERSION.SDK_INT >= 24 && scheduler.getPendingJob(JOB_ID) != null) return;
        ComponentName service = new ComponentName(context, AppealCheckJobService.class);
        JobInfo job = new JobInfo.Builder(JOB_ID, service)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(15 * 60 * 1000L)
                .build();
        scheduler.schedule(job);
    }

    public static void cancel(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) scheduler.cancel(JOB_ID);
    }

    public static boolean isNew(Context context, String appealId) {
        if (appealId == null || appealId.isEmpty()) return false;
        return !appealId.equals(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("last_appeal_id", ""));
    }

    public static boolean markNew(Context context, String appealId) {
        if (!isNew(context, appealId)) return false;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("last_appeal_id", appealId).apply();
        return true;
    }

    public static boolean wasPermissionRequestedFor(Context context, String appealId) {
        return appealId != null && appealId.equals(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("permission_requested_for", ""));
    }

    public static void notePermissionRequest(Context context, String appealId) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("permission_requested_for", appealId == null ? "" : appealId).apply();
    }

    public static void show(Context context, String appName, String developerName, int pendingCount) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Apelações SAN STORE", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Novos pedidos para desbloquear aplicativos.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, AppealsActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, NOTIFICATION_ID, open, flags);
        String app = appName == null || appName.trim().isEmpty() ? "um aplicativo" : appName.trim();
        String developer = developerName == null || developerName.trim().isEmpty() ? "Um desenvolvedor" : developerName.trim();
        String body = developer + " pediu o desbloqueio de “" + app + "”. " + pendingCount + " pedido(s) aguardam análise.";
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        Notification notification = builder.setSmallIcon(R.drawable.ic_san_store)
                .setContentTitle("Nova apelação de app")
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();
        manager.notify(NOTIFICATION_ID, notification);
    }
}
