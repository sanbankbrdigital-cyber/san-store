package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class PasswordResetRequestsActivity extends Activity {
    private LinearLayout content;
    private TextView state;
    private boolean loading;

    @Override public void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        content = AdminUi.screen(this, "Redefinição de senha", "Solicitações aguardando aprovação", true);
        TextView note = AdminUi.text(this,
                "Ao aprovar, a senha solicitada passa a valer e as sessões antigas são encerradas. Ao recusar, a senha atual permanece.",
                13, AdminUi.MUTED, false);
        note.setLineSpacing(AdminUi.dp(this, 3), 1f);
        content.addView(note);
        Button refresh = AdminUi.button(this, "Atualizar solicitações", false);
        LinearLayout.LayoutParams refreshParams = new LinearLayout.LayoutParams(-1, -2);
        refreshParams.topMargin = AdminUi.dp(this, 12);
        content.addView(refresh, refreshParams);
        refresh.setOnClickListener(v -> load());
        state = AdminUi.text(this, "Carregando…", 13, AdminUi.MUTED, true);
        state.setPadding(0, AdminUi.dp(this, 12), 0, 0);
        content.addView(state);
        load();
    }

    private void load() {
        if (loading || isFinishing()) return;
        loading = true;
        AdminApi.call(this, "GET", "/api/admin/password-reset-requests", null, (code, object, array, error) -> {
            loading = false;
            if (isFinishing()) return;
            if (code != 200 || array == null) {
                state.setText(error != null ? error : AdminApi.message(object, "Não foi possível carregar as solicitações."));
                state.setTextColor(AdminUi.GOLD);
                return;
            }
            content.removeViews(3, Math.max(0, content.getChildCount() - 3));
            state.setText(array.length() == 0 ? "Nenhuma solicitação pendente." : array.length() + " solicitação(ões) aguardando análise.");
            state.setTextColor(array.length() == 0 ? AdminUi.GREEN : AdminUi.GOLD);
            if (array.length() == 0) {
                TextView empty = AdminUi.text(this, "Quando alguém pedir uma nova senha, a solicitação aparecerá aqui.", 13, AdminUi.MUTED, false);
                empty.setPadding(0, AdminUi.dp(this, 10), 0, 0);
                content.addView(empty);
                return;
            }
            for (int i = 0; i < array.length(); i++) {
                JSONObject request = array.optJSONObject(i);
                if (request != null) addRequestCard(request);
            }
        });
    }

    private void addRequestCard(JSONObject request) {
        String id = request.optString("id", "");
        LinearLayout card = AdminUi.card(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = AdminUi.dp(this, 12);
        content.addView(card, cardParams);
        card.addView(AdminUi.badge(this, "REDEFINIÇÃO PENDENTE", AdminUi.ALT, AdminUi.GOLD));
        TextView account = AdminUi.text(this, request.optString("account", "Conta SAN STORE"), 18, AdminUi.TEXT, true);
        account.setPadding(0, AdminUi.dp(this, 10), 0, 0);
        card.addView(account);
        TextView email = AdminUi.text(this, request.optString("email", ""), 13, AdminUi.MUTED, false);
        email.setPadding(0, AdminUi.dp(this, 3), 0, 0);
        card.addView(email);
        String createdAt = request.optString("createdAt", "");
        TextView date = AdminUi.text(this, createdAt.isEmpty() ? "Solicitação recebida" : "Recebida: " + createdAt, 10, AdminUi.MUTED, false);
        date.setPadding(0, AdminUi.dp(this, 4), 0, AdminUi.dp(this, 10));
        card.addView(date);

        LinearLayout actions = AdminUi.horizontal(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        Button approve = AdminUi.button(this, "Aprovar", true);
        Button reject = AdminUi.button(this, "Recusar", false);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, -2, 1f);
        actionParams.rightMargin = AdminUi.dp(this, 6);
        actions.addView(approve, actionParams);
        LinearLayout.LayoutParams rejectParams = new LinearLayout.LayoutParams(0, -2, 1f);
        rejectParams.leftMargin = AdminUi.dp(this, 6);
        actions.addView(reject, rejectParams);
        approve.setOnClickListener(v -> confirmDecision(id, request.optString("account", "esta conta"), true));
        reject.setOnClickListener(v -> confirmDecision(id, request.optString("account", "esta conta"), false));
    }

    private void confirmDecision(String id, String account, boolean approve) {
        new AlertDialog.Builder(this)
                .setTitle(approve ? "Aprovar nova senha?" : "Recusar solicitação?")
                .setMessage(approve
                        ? "A senha desejada de " + account + " será ativada e a conta precisará entrar novamente em todos os aparelhos."
                        : "A senha atual de " + account + " será mantida. A senha nova solicitada será descartada.")
                .setNegativeButton("Voltar", null)
                .setPositiveButton(approve ? "Aprovar" : "Recusar", (dialog, which) -> decide(id, approve))
                .show();
    }

    private void decide(String id, boolean approve) {
        String path = "/api/admin/password-reset-requests/" + id + (approve ? "/approve" : "/reject");
        JSONObject body = approve ? null : AdminApi.json("reason", "Recusada pelo administrador.");
        AdminApi.call(this, "POST", path, body, (code, object, array, error) -> {
            if (isFinishing()) return;
            if (code != 200) {
                Toast.makeText(this, error != null ? error : AdminApi.message(object, "Não foi possível concluir a decisão."), Toast.LENGTH_LONG).show();
                load();
                return;
            }
            Toast.makeText(this, approve ? "Senha alterada e sessões antigas encerradas." : "Solicitação recusada; senha antiga mantida.", Toast.LENGTH_LONG).show();
            load();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null) load();
    }
}
