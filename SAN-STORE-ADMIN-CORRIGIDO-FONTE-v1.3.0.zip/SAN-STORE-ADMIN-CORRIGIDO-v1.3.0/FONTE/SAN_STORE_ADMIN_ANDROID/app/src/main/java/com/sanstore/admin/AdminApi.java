package com.sanstore.admin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class AdminApi {
    public static final String BASE = "https://san-store-dnrd.onrender.com";
    private static final String PREF = "admin_session";
    private AdminApi() {}
    public static String token(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("token","");}
    public static void saveToken(Context c,String t){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("token",t).apply();}
    public static void clear(Context c){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();}
    public interface Callback { void done(int code, JSONObject object, JSONArray array, String error); }
    public static void call(Activity a,String method,String path,JSONObject body,Callback cb){
        new AsyncTask<Void,Void,Result>(){
            protected Result doInBackground(Void... ignored){
                HttpURLConnection c=null;
                try{
                    URL url=new URL(BASE+path); if(!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("Conexão segura obrigatória.");
                    c=(HttpURLConnection)url.openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(100000);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");
                    String t=token(a);if(t!=null&&!t.isEmpty())c.setRequestProperty("Authorization","Bearer "+t);
                    if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);try(OutputStream os=c.getOutputStream()){os.write(bytes);}}
                    int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();StringBuilder s=new StringBuilder();if(is!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}}
                    Result out=new Result();out.code=code;String text=s.toString();if(text.startsWith("["))out.array=new JSONArray(text);else if(!text.isEmpty())out.object=new JSONObject(text);return out;
                }catch(Exception e){Result r=new Result();r.error="Não foi possível conectar ao servidor. Verifique a internet e tente novamente.";return r;}finally{if(c!=null)c.disconnect();}
            }
            protected void onPostExecute(Result r){if(!a.isFinishing())cb.done(r.code,r.object,r.array,r.error);}
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
    private static final class Result{int code;JSONObject object;JSONArray array;String error;}
    public static JSONObject json(String... pairs){JSONObject o=new JSONObject();try{for(int i=0;i+1<pairs.length;i+=2)o.put(pairs[i],pairs[i+1]);}catch(Exception ignored){}return o;}
    public static String message(JSONObject o,String fallback){return o==null?fallback:o.optString("error",fallback);}
    public static void logout(Activity a,Runnable done){call(a,"DELETE","/api/auth/session",null,(code,o,ar,e)->{clear(a);done.run();});}
}
