package com.sanstore.admin;

import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

public class AdminLoginActivity extends Activity {
    EditText identity,password; Button login; TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b);if(!AdminApi.token(this).isEmpty()){verifyExisting();return;}show();}
    private void show(){LinearLayout p=AdminUi.screen(this,"SAN STORE Admin","Acesso administrativo seguro",false);AdminUi.section(this,p,"Entrar na conta SAN STORE");AdminUi.label(this,p,"Conta ou e-mail @sanstore.com");identity=AdminUi.input(this,"Conta ou e-mail",false);p.addView(identity);AdminUi.label(this,p,"Senha");password=AdminUi.input(this,"Senha (não será salva)",false);password.setInputType(0x81);p.addView(password);AdminUi.gap(this,p,16);login=AdminUi.button(this,"Entrar",true);p.addView(login);status=AdminUi.text(this,"Use sua conta SAN STORE. Não há cadastro administrativo automático.",12,AdminUi.MUTED,false);status.setPadding(0,AdminUi.dp(this,16),0,0);p.addView(status);login.setOnClickListener(v->doLogin());}
    private void doLogin(){String id=identity.getText().toString().trim(),pw=password.getText().toString();if(id.isEmpty()||pw.isEmpty()){status.setText("Informe conta e senha.");return;}login.setEnabled(false);AdminApi.call(this,"POST","/api/auth/login",AdminApi.json("identifier",id,"password",pw),(code,o,a,e)->{login.setEnabled(true);password.setText("");if(e!=null){status.setText(e);return;}if(code!=200||o==null){status.setText(AdminApi.message(o,"Não foi possível entrar (HTTP "+code+")."));return;}String t=o.optString("token","");if(t.isEmpty()){status.setText("Resposta de sessão inválida.");return;}AdminApi.saveToken(this,t);verifyExisting();});}
    private void verifyExisting(){AdminApi.call(this,"GET","/api/admin/me",null,(code,o,a,e)->{if(code==200){startActivity(new android.content.Intent(this,AdminDashboardActivity.class));finish();}else if(code==403){startActivity(new android.content.Intent(this,BootstrapActivity.class));finish();}else if(code==401){AdminApi.clear(this);show();}else{show();status.setText(e!=null?e:AdminApi.message(o,"Serviço temporariamente indisponível (HTTP "+code+")."));}});}
}
