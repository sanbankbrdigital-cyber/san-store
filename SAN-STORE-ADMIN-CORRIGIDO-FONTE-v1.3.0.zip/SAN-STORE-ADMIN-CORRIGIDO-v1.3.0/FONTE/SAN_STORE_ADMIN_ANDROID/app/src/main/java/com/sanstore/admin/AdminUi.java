package com.sanstore.admin;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class AdminUi {
    public static final int BG = Color.rgb(9, 13, 22);
    public static final int CARD = Color.rgb(18, 26, 40);
    public static final int ALT = Color.rgb(27, 38, 57);
    public static final int TEXT = Color.rgb(245, 248, 255);
    public static final int MUTED = Color.rgb(165, 177, 198);
    public static final int BLUE = Color.rgb(123, 151, 255);
    public static final int GREEN = Color.rgb(104, 226, 184);
    public static final int GOLD = Color.rgb(255, 203, 126);
    private static final int BORDER = Color.rgb(43, 57, 79);
    private static int cardSequence;

    private AdminUi() {}
    public static int dp(Activity a, float v) { return (int)(v * a.getResources().getDisplayMetrics().density + 0.5f); }
    public static LinearLayout vertical(Activity a) { LinearLayout l=new LinearLayout(a);l.setOrientation(LinearLayout.VERTICAL);return l; }
    public static LinearLayout horizontal(Activity a) { LinearLayout l=new LinearLayout(a);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    private static boolean isGlassSurface(int color) {
        int rgb = color & 0x00ffffff;
        return color == CARD || color == ALT || rgb == 0x090d16 || rgb == 0x121a28 ||
                rgb == 0x1b2639 || rgb == 0x0e1420 || rgb == 0x202f4c || rgb == 0x172337 ||
                rgb == 0x202c45 || rgb == 0x263b6d || rgb == 0x17243d;
    }

    public static GradientDrawable shape(int color, int radius, int stroke) {
        boolean glass = isGlassSurface(color);
        GradientDrawable drawable = glass
                ? new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{0xc72b4566, 0xa8192b43})
                : new GradientDrawable();
        if (!glass) drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (glass) drawable.setStroke(1, 0x89dceaff);
        else if (stroke != 0) drawable.setStroke(1, stroke);
        return drawable;
    }

    public static GradientDrawable gradient(int from, int to, int radius, int stroke) {
        boolean glass = isGlassSurface(from) || isGlassSurface(to);
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                glass ? new int[]{0xc72b4566, 0xa8192b43} : new int[]{from, to});
        drawable.setCornerRadius(radius);
        if (glass) drawable.setStroke(1, 0x89dceaff);
        else if (stroke != 0) drawable.setStroke(1, stroke);
        return drawable;
    }
    public static TextView text(Activity a,String s,float size,int color,boolean bold){TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    public static TextView badge(Activity a,String s,int bg,int fg){TextView t=text(a,s,10,fg,true);t.setLetterSpacing(.06f);t.setPadding(dp(a,10),dp(a,6),dp(a,10),dp(a,6));t.setBackground(shape(bg,dp(a,24),0));return t;}
    public static LinearLayout screen(Activity a, String title, String subtitle, boolean back) {
        cardSequence = 0;
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        LinearLayout outer = vertical(a);
        outer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff0a1220, 0xff101b2e, 0xff0a1423}));
        LinearLayout header = horizontal(a);
        header.setPadding(dp(a, 20), dp(a, 14), dp(a, 20), dp(a, 12));
        if (back) {
            TextView button = text(a, "‹", 32, TEXT, false);
            button.setGravity(Gravity.CENTER);
            button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),
                    shape(ALT, dp(a, 20), BORDER), shape(Color.WHITE, dp(a, 20), 0)));
            header.addView(button, new LinearLayout.LayoutParams(dp(a, 46), dp(a, 46)));
            pressFeedback(button);
            button.setOnClickListener(v -> a.finish());
        }
        LinearLayout titles = vertical(a);
        if (back) titles.setPadding(dp(a, 12), 0, 0, 0);
        titles.addView(text(a, title, back ? 21 : 24, TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView sub = text(a, subtitle, 12, MUTED, false);
            sub.setPadding(0, dp(a, 3), 0, 0);
            titles.addView(sub);
        }
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        outer.addView(header);
        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content = vertical(a);
        content.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), dp(a, 32));
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        outer.setAlpha(0f);
        outer.setTranslationY(dp(a, 8));
        outer.setOnApplyWindowInsetsListener((v, i) -> {
            v.setPadding(0, i.getSystemWindowInsetTop(), 0, i.getSystemWindowInsetBottom());
            return i;
        });
        a.setContentView(outer);
        outer.requestApplyInsets();
        outer.post(() -> outer.animate().alpha(1f).translationY(0f).setDuration(320L)
                .setInterpolator(new DecelerateInterpolator()).start());
        return content;
    }
    private static void pressFeedback(View view) {
        view.setOnTouchListener((target, event) -> {
            if (!target.isEnabled()) return false;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                target.animate().cancel();
                target.animate().scaleX(0.975f).scaleY(0.975f).setDuration(90L)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP ||
                    event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                target.animate().scaleX(1f).scaleY(1f).setDuration(170L)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
            return false;
        });
    }

    private static void animateCard(Activity activity, View card) {
        int order = cardSequence++;
        card.setAlpha(0f);
        card.setTranslationY(dp(activity, 10));
        long delay = Math.min(order * 36L, 216L);
        card.post(() -> card.animate().alpha(1f).translationY(0f).setStartDelay(delay)
                .setDuration(330L).setInterpolator(new DecelerateInterpolator()).start());
    }

    public static void section(Activity a, LinearLayout p, String title) {
        TextView t = text(a, title, 18, TEXT, true);
        t.setPadding(0, dp(a, 22), 0, dp(a, 12));
        p.addView(t);
    }

    public static void label(Activity a, LinearLayout p, String title) {
        TextView t = text(a, title, 12, MUTED, true);
        t.setPadding(dp(a, 2), dp(a, 16), 0, dp(a, 8));
        p.addView(t);
    }

    public static EditText input(Activity a, String hint, boolean multiline) {
        EditText e = new EditText(a);
        e.setSingleLine(!multiline);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(122, 137, 160));
        e.setHint(hint);
        e.setTextSize(14);
        e.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        e.setBackground(shape(Color.rgb(14, 20, 32), dp(a, 20), BORDER));
        e.setElevation(dp(a, 3));
        if (multiline) { e.setGravity(Gravity.TOP); e.setMinLines(3); e.setMaxLines(6); }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(a, 5);
        e.setLayoutParams(params);
        return e;
    }

    public static Button button(Activity a, String title, boolean primary) {
        Button b = new Button(a);
        b.setText(title);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setPadding(dp(a, 18), dp(a, 12), dp(a, 18), dp(a, 12));
        GradientDrawable fill = primary ? gradient(0xff708dff, 0xff5b73e8, dp(a, 20), 0)
                : shape(ALT, dp(a, 20), BORDER);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44ffffff), fill, shape(Color.WHITE, dp(a, 20), 0)));
        b.setMinHeight(dp(a, 52));
        b.setElevation(dp(a, 5));
        pressFeedback(b);
        return b;
    }

    public static void gap(Activity a, LinearLayout p, int h) {
        View v = new View(a);
        p.addView(v, new LinearLayout.LayoutParams(1, dp(a, h)));
    }

    public static LinearLayout card(Activity a) {
        LinearLayout card = vertical(a);
        card.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));
        card.setBackground(shape(CARD, dp(a, 24), BORDER));
        card.setElevation(dp(a, 6));
        animateCard(a, card);
        return card;
    }
}
