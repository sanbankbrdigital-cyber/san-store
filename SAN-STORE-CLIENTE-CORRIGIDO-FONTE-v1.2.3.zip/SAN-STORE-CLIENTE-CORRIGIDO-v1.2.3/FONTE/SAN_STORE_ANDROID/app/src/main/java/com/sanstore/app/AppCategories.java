package com.sanstore.app;

public final class AppCategories {
    public static final String[] VALUES = {
            "Educação", "Finanças", "Ferramentas", "Redes sociais",
            "Entretenimento", "Saúde", "Produtividade"
    };

    private AppCategories() {}

    public static boolean isValid(String value) {
        if (value == null) return false;
        for (String category : VALUES) if (category.equals(value)) return true;
        return false;
    }
}
