package com.sanstore.app;

/** Unified category browser for apps and games. */
public final class BrowseCategoryActivity extends CategoryActivity {
    @Override protected String categoryKey() { return "All"; }
}
