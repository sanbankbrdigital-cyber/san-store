package com.sanstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadsActivity extends Activity {
    private static final String STORE_DOWNLOAD_DESCRIPTION = "SAN STORE · download do aplicativo";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private LinearLayout content;
    private LinearLayout list;
    private TextView summary;
    private boolean firstResume = true;
    private boolean queryRunning;

    private static final class DownloadedApp {
        long id;
        String title;
        int status;
        int reason;
        long downloadedBytes;
        long totalBytes;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
        loadDownloads();
    }

    private void render() {
        content = StoreUi.screen(this, "Meus downloads", "Apps e jogos baixados pela SAN STORE", true);

        LinearLayout intro = StoreUi.vertical(this);
        intro.setPadding(StoreUi.dp(this, 16), StoreUi.dp(this, 15), StoreUi.dp(this, 16), StoreUi.dp(this, 15));
        intro.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 22), 0xff354767));
        intro.addView(StoreUi.badge(this, "BIBLIOTECA DE DOWNLOADS", 0xff2b3d61, 0xffd7e2ff));
        TextView explanation = StoreUi.text(this,
                "Consulte o andamento dos seus downloads ou remova do aparelho os arquivos APK baixados pela loja.",
                13, StoreUi.TEXT, false);
        explanation.setLineSpacing(StoreUi.dp(this, 2), 1f);
        explanation.setPadding(0, StoreUi.dp(this, 9), 0, 0);
        intro.addView(explanation);
        content.addView(intro);

        LinearLayout heading = StoreUi.horizontal(this);
        StoreUi.section(this, heading, "Seus aplicativos");
        Button refresh = StoreUi.button(this, "Atualizar", false);
        LinearLayout.LayoutParams refreshParams = new LinearLayout.LayoutParams(-2, StoreUi.dp(this, 42));
        refreshParams.gravity = Gravity.CENTER_VERTICAL;
        refreshParams.leftMargin = StoreUi.dp(this, 10);
        heading.addView(refresh, refreshParams);
        content.addView(heading);
        refresh.setOnClickListener(v -> loadDownloads());

        summary = StoreUi.text(this, "Carregando downloads…", 12, StoreUi.MUTED, false);
        summary.setPadding(0, 0, 0, StoreUi.dp(this, 8));
        content.addView(summary);

        list = StoreUi.vertical(this);
        content.addView(list);
    }

    private void loadDownloads() {
        if (queryRunning || content == null) return;
        queryRunning = true;
        StoreUi.showLoading(this);
        IO.execute(() -> {
            ArrayList<DownloadedApp> downloads = queryStoreDownloads();
            runOnUiThread(() -> {
                StoreUi.hideLoading(this);
                queryRunning = false;
                if (isFinishing() || isDestroyed()) return;
                renderDownloads(downloads);
            });
        });
    }

    private ArrayList<DownloadedApp> queryStoreDownloads() {
        ArrayList<DownloadedApp> results = new ArrayList<>();
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (manager == null) return results;
        Cursor cursor = null;
        try {
            cursor = manager.query(new DownloadManager.Query());
            if (cursor == null) return results;
            int idColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID);
            int titleColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE);
            int descriptionColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_DESCRIPTION);
            int statusColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS);
            int reasonColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON);
            int downloadedColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
            int totalColumn = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
            while (cursor.moveToNext()) {
                String description = cursor.getString(descriptionColumn);
                if (description == null || !description.startsWith(STORE_DOWNLOAD_DESCRIPTION)) continue;
                DownloadedApp item = new DownloadedApp();
                item.id = cursor.getLong(idColumn);
                item.title = cursor.getString(titleColumn);
                item.status = cursor.getInt(statusColumn);
                item.reason = cursor.getInt(reasonColumn);
                item.downloadedBytes = cursor.getLong(downloadedColumn);
                item.totalBytes = cursor.getLong(totalColumn);
                results.add(item);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        Collections.reverse(results);
        return results;
    }

    private void renderDownloads(ArrayList<DownloadedApp> downloads) {
        list.removeAllViews();
        summary.setText(downloads.size() + (downloads.size() == 1 ? " download" : " downloads"));
        if (downloads.isEmpty()) {
            LinearLayout empty = StoreUi.vertical(this);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(StoreUi.dp(this, 20), StoreUi.dp(this, 25), StoreUi.dp(this, 20), StoreUi.dp(this, 25));
            empty.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 22), 0xff2b3a53));
            TextView title = StoreUi.text(this, "Nenhum download por enquanto", 16, StoreUi.TEXT, true);
            title.setGravity(Gravity.CENTER);
            empty.addView(title);
            TextView note = StoreUi.text(this, "Os apps e jogos baixados pela SAN STORE vão aparecer aqui.", 13, StoreUi.MUTED, false);
            note.setGravity(Gravity.CENTER);
            note.setPadding(0, StoreUi.dp(this, 7), 0, 0);
            empty.addView(note);
            list.addView(empty);
            return;
        }
        for (DownloadedApp item : downloads) addDownloadCard(item);
    }

    private void addDownloadCard(DownloadedApp item) {
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 22), 0xff2b3a53));
        card.setElevation(StoreUi.dp(this, 2));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = StoreUi.dp(this, 11);
        list.addView(card, cardParams);

        String appName = item.title == null ? "Aplicativo" : item.title.replaceFirst("^Baixando\\s+", "");
        TextView title = StoreUi.text(this, appName, 16, StoreUi.TEXT, true);
        title.setMaxLines(2);
        card.addView(title);

        String statusText = statusText(item);
        String sizeText = item.totalBytes > 0 ? formatSize(item.downloadedBytes) + " / " + formatSize(item.totalBytes) : formatSize(item.downloadedBytes);
        TextView meta = StoreUi.text(this, statusText + " · " + sizeText, 12,
                item.status == DownloadManager.STATUS_FAILED ? StoreUi.GOLD : StoreUi.MUTED, false);
        meta.setPadding(0, StoreUi.dp(this, 5), 0, 0);
        card.addView(meta);

        if (item.status == DownloadManager.STATUS_RUNNING || item.status == DownloadManager.STATUS_PENDING ||
                item.status == DownloadManager.STATUS_PAUSED || item.status == DownloadManager.STATUS_SUCCESSFUL) {
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setMax(1000);
            progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(StoreUi.BLUE));
            progress.setProgressTintList(android.content.res.ColorStateList.valueOf(StoreUi.BLUE));
            if (item.status == DownloadManager.STATUS_SUCCESSFUL) {
                progress.setIndeterminate(false);
                progress.setProgress(1000);
            } else if (item.totalBytes > 0) {
                progress.setIndeterminate(false);
                progress.setProgress((int) Math.min(1000, item.downloadedBytes * 1000 / item.totalBytes));
            } else {
                progress.setIndeterminate(true);
            }
            LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 6));
            progressParams.topMargin = StoreUi.dp(this, 10);
            card.addView(progress, progressParams);
        }

        Button remove = StoreUi.button(this,
                item.status == DownloadManager.STATUS_RUNNING || item.status == DownloadManager.STATUS_PENDING
                        ? "Cancelar e remover" : "Excluir APK baixado", false);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48));
        buttonParams.topMargin = StoreUi.dp(this, 12);
        card.addView(remove, buttonParams);
        remove.setOnClickListener(v -> confirmRemove(item));
    }

    private String statusText(DownloadedApp item) {
        switch (item.status) {
            case DownloadManager.STATUS_PENDING: return "Aguardando download";
            case DownloadManager.STATUS_RUNNING: return "Baixando";
            case DownloadManager.STATUS_PAUSED: return "Download pausado";
            case DownloadManager.STATUS_SUCCESSFUL: return "Concluído";
            case DownloadManager.STATUS_FAILED: return "Falhou (código " + item.reason + ")";
            default: return "Estado indisponível";
        }
    }

    private String formatSize(long bytes) {
        if (bytes < 0) return "Tamanho desconhecido";
        return String.format(Locale.getDefault(), "%.1f MB", bytes / 1048576f);
    }

    private void confirmRemove(DownloadedApp item) {
        boolean active = item.status == DownloadManager.STATUS_RUNNING || item.status == DownloadManager.STATUS_PENDING ||
                item.status == DownloadManager.STATUS_PAUSED;
        new AlertDialog.Builder(this)
                .setTitle(active ? "Cancelar download?" : "Excluir download?")
                .setMessage("O arquivo baixado será removido deste aparelho. Se o aplicativo já estiver instalado, ele não será desinstalado.")
                .setNegativeButton("Manter", null)
                .setPositiveButton(active ? "Cancelar download" : "Excluir", (dialog, which) -> removeDownload(item.id))
                .show();
    }

    private void removeDownload(long id) {
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        int removed = manager == null ? 0 : manager.remove(id);
        Toast.makeText(this, removed > 0 ? "Download removido do aparelho." : "Não foi possível remover este download.",
                Toast.LENGTH_SHORT).show();
        loadDownloads();
    }

    @Override protected void onResume() {
        super.onResume();
        if (firstResume) firstResume = false;
        else if (content != null) loadDownloads();
    }
}
