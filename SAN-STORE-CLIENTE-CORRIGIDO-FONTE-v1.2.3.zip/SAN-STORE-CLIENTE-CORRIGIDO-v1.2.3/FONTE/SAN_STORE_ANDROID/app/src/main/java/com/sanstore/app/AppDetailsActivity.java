package com.sanstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class AppDetailsActivity extends Activity {
    private AppItem item;
    private RatingBar ratingInput;
    private EditText reviewInput;
    private Button submitButton;
    private TextView ratingSummary;
    private RatingBar averageRating;
    private LinearLayout reviewsList;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        item = StoreUi.fromIntent(getIntent());
        render();
        loadReviews();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Detalhes do app", "Informações e avaliações", true);
        LinearLayout hero = StoreUi.horizontal(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15));
        hero.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 24), 0xff2b3a53));
        hero.setElevation(StoreUi.dp(this, 3));

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(StoreUi.shape(0xff263046, StoreUi.dp(this, 22), 0));
        icon.setClipToOutline(true);
        icon.setImageDrawable(getDrawable(android.R.drawable.sym_def_app_icon));
        icon.setTag(item.image);
        StoreUi.loadImage(icon, item.image);
        hero.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(this, 90), StoreUi.dp(this, 90)));

        TextView title = StoreUi.text(this, item.name, 21, StoreUi.TEXT, true);
        title.setPadding(StoreUi.dp(this, 15), 0, 0, 0);
        hero.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(hero);

        StoreUi.gap(this, content, 17);
        content.addView(StoreUi.text(this, "Game".equals(item.category) ? "JOGO" : "APLICATIVO", 12, StoreUi.BLUE, true));
        if (item.subcategory != null && !item.subcategory.trim().isEmpty()) {
            TextView subcategory = StoreUi.badge(this, item.subcategory, 0xff1b3b4a, 0xffa5e1e8);
            LinearLayout.LayoutParams subcategoryParams = new LinearLayout.LayoutParams(-2, -2);
            subcategoryParams.topMargin = StoreUi.dp(this, 6);
            content.addView(subcategory, subcategoryParams);
        }
        Button install = StoreUi.button(this, "Instalar", true);
        LinearLayout.LayoutParams installParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54));
        installParams.topMargin = StoreUi.dp(this, 15);
        content.addView(install, installParams);
        install.setOnClickListener(v -> startActivity(StoreUi.appIntent(this, AppDownloadActivity.class, item)));
        StoreUi.section(this, content, "Publicador");
        content.addView(StoreUi.text(this, "Publicado por " + item.developerName, 14, StoreUi.MUTED, false));
        StoreUi.section(this, content, "Sobre este aplicativo");
        TextView description = StoreUi.text(this, item.description, 15, StoreUi.MUTED, false);
        description.setLineSpacing(StoreUi.dp(this, 3), 1f);
        content.addView(description);

        StoreUi.section(this, content, "Avaliações dos usuários");
        LinearLayout scoreCard = StoreUi.horizontal(this);
        scoreCard.setGravity(Gravity.CENTER_VERTICAL);
        scoreCard.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 12), StoreUi.dp(this, 14), StoreUi.dp(this, 12));
        scoreCard.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        averageRating = ratingBar(true);
        averageRating.setRating(0f);
        scoreCard.addView(averageRating, new LinearLayout.LayoutParams(-2, -2));
        ratingSummary = StoreUi.text(this, "Carregando avaliações…", 13, StoreUi.MUTED, true);
        ratingSummary.setPadding(StoreUi.dp(this, 10), 0, 0, 0);
        scoreCard.addView(ratingSummary, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(scoreCard);

        LinearLayout reviewForm = StoreUi.vertical(this);
        reviewForm.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        reviewForm.setBackground(StoreUi.shape(0xff151e2d, StoreUi.dp(this, 20), 0xff2b3a53));
        LinearLayout.LayoutParams formParams = new LinearLayout.LayoutParams(-1, -2);
        formParams.topMargin = StoreUi.dp(this, 12);
        content.addView(reviewForm, formParams);
        reviewForm.addView(StoreUi.text(this, "Deixe sua avaliação", 15, StoreUi.TEXT, true));
        ratingInput = ratingBar(false);
        ratingInput.setRating(5f);
        LinearLayout.LayoutParams inputRatingParams = new LinearLayout.LayoutParams(-2, -2);
        inputRatingParams.topMargin = StoreUi.dp(this, 6);
        reviewForm.addView(ratingInput, inputRatingParams);
        reviewInput = StoreUi.input(this, "Conte o que achou do aplicativo", true);
        reviewForm.addView(reviewInput);
        submitButton = StoreUi.button(this, "Publicar avaliação", true);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48));
        sendParams.topMargin = StoreUi.dp(this, 7);
        reviewForm.addView(submitButton, sendParams);
        submitButton.setOnClickListener(v -> submitReview());

        StoreUi.section(this, content, "Comentários recentes");
        reviewsList = StoreUi.vertical(this);
        content.addView(reviewsList);

        StoreUi.section(this, content, "Instalação segura");
        content.addView(StoreUi.text(this,
                "O Android abrirá a confirmação final da instalação para você.",
                13, StoreUi.MUTED, false));
    }

    private RatingBar ratingBar(boolean indicator) {
        RatingBar bar = new RatingBar(this);
        bar.setNumStars(5);
        bar.setStepSize(1f);
        bar.setIsIndicator(indicator);
        bar.setProgressTintList(ColorStateList.valueOf(StoreUi.GOLD));
        boolean lightTheme = StoreUi.isLightTheme(this);
        bar.setSecondaryProgressTintList(ColorStateList.valueOf(lightTheme ? 0xffdeca98 : 0xff75603a));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(lightTheme ? 0xffd7e0eb : 0xff3a465a));
        return bar;
    }

    private void loadReviews() {
        ApiClient.getReviews(this, item.id, (summary, error) -> {
            if (isFinishing()) return;
            reviewsList.removeAllViews();
            if (error != null || summary == null) {
                ratingSummary.setText("As avaliações não estão disponíveis agora.");
                reviewsList.addView(StoreUi.text(this, "Tente atualizar esta tela daqui a pouco.", 13, StoreUi.MUTED, false));
                return;
            }
            averageRating.setRating(summary.averageRating);
            ratingSummary.setText(String.format(Locale.getDefault(), "%.1f / 5  ·  %d avaliação(ões)",
                    summary.averageRating, summary.reviewCount));
            if (summary.reviews.isEmpty()) {
                TextView empty = StoreUi.text(this, "Ainda não há avaliações. Seja a primeira pessoa a avaliar!", 13, StoreUi.MUTED, false);
                empty.setPadding(StoreUi.dp(this, 3), StoreUi.dp(this, 2), 0, 0);
                reviewsList.addView(empty);
                return;
            }
            for (ApiClient.AppReview review : summary.reviews) addReviewCard(review);
        });
    }

    private void addReviewCard(ApiClient.AppReview review) {
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 12), StoreUi.dp(this, 14), StoreUi.dp(this, 12));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 18), 0xff2b3a53));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = StoreUi.dp(this, 9);
        reviewsList.addView(card, cardParams);

        LinearLayout heading = StoreUi.horizontal(this);
        heading.addView(StoreUi.text(this, review.reviewerName, 13, StoreUi.TEXT, true),
                new LinearLayout.LayoutParams(0, -2, 1));
        TextView stars = StoreUi.text(this, String.format(Locale.getDefault(), "★ %.1f", (float) review.rating),
                12, StoreUi.GOLD, true);
        heading.addView(stars);
        card.addView(heading);

        if (review.createdAt != null && review.createdAt.length() >= 10) {
            TextView date = StoreUi.text(this, review.createdAt.substring(0, 10), 10, StoreUi.MUTED, false);
            date.setPadding(0, StoreUi.dp(this, 3), 0, StoreUi.dp(this, 4));
            card.addView(date);
        }
        TextView comment = StoreUi.text(this, review.comment, 13, StoreUi.MUTED, false);
        comment.setLineSpacing(StoreUi.dp(this, 2), 1f);
        card.addView(comment);
    }

    private void submitReview() {
        String comment = reviewInput.getText().toString().trim();
        if (ApiClient.sessionToken(this).isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Entre na sua conta")
                    .setMessage("Você precisa entrar para publicar uma avaliação.")
                    .setNegativeButton("Agora não", null)
                    .setPositiveButton("Entrar", (dialog, which) -> startActivity(new Intent(this, LoginActivity.class)))
                    .show();
            return;
        }
        if (comment.length() < 3 || comment.length() > 500) {
            Toast.makeText(this, "Escreva uma avaliação de 3 a 500 caracteres.", Toast.LENGTH_LONG).show();
            return;
        }
        submitButton.setEnabled(false);
        ApiClient.submitReview(this, item.id, Math.round(ratingInput.getRating()), comment, (response, error) -> {
            if (isFinishing()) return;
            submitButton.setEnabled(true);
            if (error != null) {
                Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }
            reviewInput.setText("");
            Toast.makeText(this, "Sua avaliação foi publicada.", Toast.LENGTH_SHORT).show();
            loadReviews();
        });
    }
}
