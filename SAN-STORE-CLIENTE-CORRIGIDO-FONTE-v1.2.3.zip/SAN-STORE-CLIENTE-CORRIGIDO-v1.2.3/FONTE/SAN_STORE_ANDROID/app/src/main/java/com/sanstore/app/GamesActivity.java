package com.sanstore.app;

/** Dedicated Activity for browsing games. */
public final class GamesActivity extends CategoryActivity {
    @Override protected String categoryKey() { return "Game"; }
}
