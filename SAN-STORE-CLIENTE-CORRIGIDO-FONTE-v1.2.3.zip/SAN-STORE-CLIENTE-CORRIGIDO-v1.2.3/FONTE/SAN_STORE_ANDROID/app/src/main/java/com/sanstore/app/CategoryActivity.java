package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/** Shared native screen logic; each category has its own concrete Activity. */
public abstract class CategoryActivity extends Activity {
    private String category;
    private LinearLayout list;
    private LinearLayout filtersRow;
    private TextView status;
    private ArrayList<AppItem> catalog = new ArrayList<>();
    private String selectedSubcategory = "";

    protected abstract String categoryKey();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        category = categoryKey();
        String requestedSubcategory = getIntent().getStringExtra("subcategory");
        if (AppCategories.isValid(requestedSubcategory)) selectedSubcategory = requestedSubcategory;
        render();
        load();
    }

    private void render() {
        String title = "Game".equals(category) ? "Jogos" : "All".equals(category) ? "Categorias" : "Aplicativos";
        String selectedTab = "Game".equals(category) ? "games" : "apps";
        LinearLayout content = StoreUi.screenWithBottomNav(this, title, "Explore por categoria", true, selectedTab);

        StoreUi.section(this, content, "Filtrar por categoria");
        HorizontalScrollView filterScroll = new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);
        filterScroll.setOverScrollMode(HorizontalScrollView.OVER_SCROLL_NEVER);
        filtersRow = StoreUi.horizontal(this);
        filterScroll.addView(filtersRow, new HorizontalScrollView.LayoutParams(-2, -2));
        content.addView(filterScroll, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 42)));
        renderFilters();

        status = StoreUi.text(this, "Carregando catálogo…", 12, StoreUi.MUTED, false);
        status.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 12), 0, StoreUi.dp(this, 3));
        content.addView(status);
        list = StoreUi.vertical(this);
        StoreUi.gap(this, content, 7);
        content.addView(list);
    }

    private void renderFilters() {
        if (filtersRow == null) return;
        filtersRow.removeAllViews();
        addFilter("Todas", "");
        for (String value : AppCategories.VALUES) addFilter(value, value);
    }

    private void addFilter(String label, String value) {
        boolean selected = selectedSubcategory.equals(value);
        TextView chip = StoreUi.text(this, label, 12,
                selected ? 0xff075f95 : StoreUi.MUTED, selected);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(StoreUi.dp(this, 13), 0, StoreUi.dp(this, 13), 0);
        chip.setBackground(StoreUi.shape(selected ? 0xffc9e8fc : StoreUi.CARD_ALT,
                StoreUi.dp(this, 20), selected ? 0 : 0xff344767));
        chip.setClickable(true);
        chip.setFocusable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, StoreUi.dp(this, 36));
        params.rightMargin = StoreUi.dp(this, 8);
        filtersRow.addView(chip, params);
        chip.setOnClickListener(v -> {
            selectedSubcategory = value;
            renderFilters();
            renderItems();
        });
    }

    private void load() {
        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                catalog = new ArrayList<>();
                catalog.add(AppItem.sanbank());
                status.setText("Servidor indisponível · mostrando conteúdo de demonstração");
            } else {
                catalog = items == null ? new ArrayList<>() : items;
            }
            renderItems();
        });
    }

    private void renderItems() {
        if (list == null) return;
        list.removeAllViews();
        int count = 0;
        for (AppItem item : catalog) {
            if (!"All".equals(category) && !category.equals(item.category)) continue;
            if (!selectedSubcategory.isEmpty() && !selectedSubcategory.equals(item.subcategory)) continue;
            count++;
            list.addView(StoreUi.appCard(this, item, () -> StoreUi.openDetails(this, item)));
        }
        if (status != null && !"Servidor indisponível · mostrando conteúdo de demonstração".contentEquals(status.getText())) {
            String unit = "All".equals(category) ? "itens" : "Game".equals(category) ? "jogos" : "aplicativos";
            String suffix = selectedSubcategory.isEmpty() ? "" : " · " + selectedSubcategory;
            status.setText(count + " " + unit + suffix);
        }
        if (count == 0) {
            String unit = "All".equals(category) ? "itens" : "Game".equals(category) ? "jogos" : "aplicativos";
            String message = selectedSubcategory.isEmpty()
                    ? "Ainda não há itens nesta categoria."
                    : "Ainda não há " + unit + " em “" + selectedSubcategory + "”.";
            list.addView(StoreUi.text(this, message, 14, StoreUi.MUTED, false));
        }
    }
}
