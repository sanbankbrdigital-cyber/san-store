package com.sanstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class AppDownloadActivity extends Activity {
    private static final String STATE_DOWNLOAD_ID = "download_id";
    private static final int REQUEST_INSTALL_PERMISSION = 43;
    private static final int REQUEST_LEGACY_SECURITY_SETTINGS = 44;
    private static final long NO_DOWNLOAD = -1L;

    private AppItem item;
    private DownloadManager manager;
    private long downloadId = NO_DOWNLOAD;
    private TextView status;
    private TextView progressLabel;
    private ProgressBar progress;
    private Button startButton;
    private Button cancelButton;
    private boolean receiverRegistered;
    private boolean installerLaunched;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            updateProgress();
        }
    };

    private final BroadcastReceiver completed = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())
                    && intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, NO_DOWNLOAD) == downloadId) {
                updateProgress();
            }
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        item = StoreUi.fromIntent(getIntent());
        manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (state != null) downloadId = state.getLong(STATE_DOWNLOAD_ID, NO_DOWNLOAD);
        render();

        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(completed, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(completed, filter);
        receiverRegistered = true;

        if (downloadId != NO_DOWNLOAD) {
            startButton.setEnabled(false);
            cancelButton.setVisibility(View.VISIBLE);
            handler.post(poll);
        }
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Download", "Baixar e instalar com segurança", true);
        content.addView(StoreUi.text(this, item.name, 20, StoreUi.TEXT, true));
        StoreUi.gap(this, content, 8);
        content.addView(StoreUi.text(this, "O arquivo será baixado pelo serviço oficial do Android. A instalação será confirmada por você.",
                14, StoreUi.MUTED, false));
        StoreUi.gap(this, content, 18);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        content.addView(progress, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 8)));
        progressLabel = StoreUi.text(this, "Pronto para iniciar", 12, StoreUi.MUTED, false);
        progressLabel.setPadding(0, StoreUi.dp(this, 8), 0, 0);
        content.addView(progressLabel);
        StoreUi.gap(this, content, 12);

        startButton = StoreUi.button(this, "Baixar aplicativo", true);
        startButton.setOnClickListener(v -> checkPermissionAndDownload());
        content.addView(startButton, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
        StoreUi.gap(this, content, 9);

        cancelButton = StoreUi.button(this, "Cancelar download", false);
        cancelButton.setVisibility(View.GONE);
        cancelButton.setOnClickListener(v -> cancelDownload());
        content.addView(cancelButton, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
        status = StoreUi.text(this, "", 13, StoreUi.MUTED, false);
        status.setPadding(0, StoreUi.dp(this, 10), 0, 0);
        content.addView(status);
    }

    private void checkPermissionAndDownload() {
        if (item.apk == null || !item.apk.startsWith("https://")) {
            status.setText("O link do APK não é válido ou não usa HTTPS.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent permission = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(permission, REQUEST_INSTALL_PERMISSION);
            } catch (Exception e) {
                status.setText("Permita instalações da SAN STORE nas configurações do Android.");
                status.setTextColor(StoreUi.GOLD);
            }
            return;
        }
        if (Build.VERSION.SDK_INT < 26) {
            new AlertDialog.Builder(this)
                    .setTitle("Fontes desconhecidas")
                    .setMessage("No Android 5.0–7.1, a permissão é controlada pelo sistema em Configurações > Segurança > Fontes desconhecidas. Você precisa ativá-la manualmente; a SAN STORE não consegue concedê-la sozinha.")
                    .setPositiveButton("Abrir Segurança", (dialog, which) -> {
                        try { startActivityForResult(new Intent(Settings.ACTION_SECURITY_SETTINGS), REQUEST_LEGACY_SECURITY_SETTINGS); }
                        catch (Exception e) { beginDownload(); }
                    })
                    .setNeutralButton("Continuar download", (dialog, which) -> beginDownload())
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        beginDownload();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LEGACY_SECURITY_SETTINGS) {
            beginDownload();
            return;
        }
        if (requestCode == REQUEST_INSTALL_PERMISSION) {
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) beginDownload();
            else {
                status.setText("A permissão não foi concedida. O download não foi iniciado.");
                status.setTextColor(StoreUi.GOLD);
            }
        }
    }

    private void beginDownload() {
        try {
            String fileName = item.name.replaceAll("[^A-Za-z0-9._-]", "_") + ".apk";
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(item.apk));
            request.setTitle("Baixando " + item.name);
            request.setDescription("SAN STORE · download do aplicativo");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            downloadId = manager.enqueue(request);
            installerLaunched = false;
            startButton.setEnabled(false);
            startButton.setText("Download em andamento...");
            cancelButton.setVisibility(View.VISIBLE);
            status.setText("O download foi iniciado; acompanhe o andamento abaixo ou na notificação.");
            status.setTextColor(StoreUi.MUTED);
            handler.removeCallbacks(poll);
            handler.post(poll);
        } catch (Exception e) {
            status.setText("Não foi possível iniciar o download. Confira o link do aplicativo.");
            status.setTextColor(StoreUi.GOLD);
            startButton.setEnabled(true);
        }
    }

    private void updateProgress() {
        if (manager == null || downloadId == NO_DOWNLOAD || isFinishing()) return;
        Cursor cursor = null;
        try {
            cursor = manager.query(new DownloadManager.Query().setFilterById(downloadId));
            if (cursor == null || !cursor.moveToFirst()) {
                showRetry("Não encontrei o download. Você pode tentar novamente.");
                return;
            }
            int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
            int downloadedIndex = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
            int totalIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
            int state = statusIndex >= 0 ? cursor.getInt(statusIndex) : -1;

            if (state == DownloadManager.STATUS_SUCCESSFUL) {
                progress.setProgress(100);
                progressLabel.setText("Download concluído · 100%");
                status.setText("Abrindo o instalador oficial do Android...");
                cancelButton.setVisibility(View.GONE);
                handler.removeCallbacks(poll);
                if (!installerLaunched) openInstaller();
                return;
            }
            if (state == DownloadManager.STATUS_FAILED) {
                int reason = reasonIndex >= 0 ? cursor.getInt(reasonIndex) : -1;
                showRetry("O download falhou (código " + reason + "). Confira a conexão ou o link e tente novamente.");
                return;
            }

            long downloaded = downloadedIndex >= 0 ? cursor.getLong(downloadedIndex) : 0;
            long total = totalIndex >= 0 ? cursor.getLong(totalIndex) : -1;
            if (total > 0) {
                int percent = (int) Math.min(100, downloaded * 100L / total);
                progress.setProgress(percent);
                progressLabel.setText("Baixado " + percent + "%");
            } else {
                progress.setIndeterminate(true);
                progressLabel.setText("Download em andamento...");
            }
            status.setText(state == DownloadManager.STATUS_PAUSED ? "Download pausado pelo Android; será retomado quando possível." : "Baixando " + item.name + "…");
            handler.removeCallbacks(poll);
            handler.postDelayed(poll, 900);
        } catch (Exception e) {
            showRetry("Não consegui consultar o andamento do download. Tente novamente.");
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void openInstaller() {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            installerLaunched = false;
            status.setText("Autorize a instalação da SAN STORE nas configurações do Android e volte aqui.");
            try {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())), REQUEST_INSTALL_PERMISSION);
            } catch (Exception ignored) {}
            return;
        }
        try {
            Uri uri = manager.getUriForDownloadedFile(downloadId);
            if (uri == null) throw new IllegalStateException("Arquivo indisponível");
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(uri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
            installerLaunched = true;
        } catch (Exception e) {
            status.setText("O Android não abriu o instalador. Confira a permissão de instalação e tente novamente.");
            status.setTextColor(StoreUi.GOLD);
            installerLaunched = true;
        }
    }

    private void showRetry(String message) {
        handler.removeCallbacks(poll);
        progress.setIndeterminate(false);
        progress.setProgress(0);
        progressLabel.setText("Download não concluído");
        status.setText(message);
        status.setTextColor(StoreUi.GOLD);
        startButton.setEnabled(true);
        startButton.setText("Tentar novamente");
        cancelButton.setVisibility(View.GONE);
        downloadId = NO_DOWNLOAD;
    }

    private void cancelDownload() {
        handler.removeCallbacks(poll);
        if (manager != null && downloadId != NO_DOWNLOAD) manager.remove(downloadId);
        downloadId = NO_DOWNLOAD;
        progress.setIndeterminate(false);
        progress.setProgress(0);
        progressLabel.setText("Download cancelado");
        status.setText("O download foi cancelado.");
        status.setTextColor(StoreUi.MUTED);
        cancelButton.setVisibility(View.GONE);
        startButton.setEnabled(true);
        startButton.setText("Baixar novamente");
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putLong(STATE_DOWNLOAD_ID, downloadId);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(poll);
        if (receiverRegistered) {
            try { unregisterReceiver(completed); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
