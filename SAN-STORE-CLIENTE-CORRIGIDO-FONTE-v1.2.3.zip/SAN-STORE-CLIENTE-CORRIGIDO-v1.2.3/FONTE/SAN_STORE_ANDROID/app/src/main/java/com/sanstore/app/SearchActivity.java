package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class SearchActivity extends Activity {
    private final ArrayList<AppItem> apps=new ArrayList<>(); private LinearLayout list; private EditText search;
    @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout content=StoreUi.screen(this,"Buscar","Pesquise aplicativos e jogos",true);search=StoreUi.input(this,"Nome ou descrição do app",false);content.addView(search);list=StoreUi.vertical(this);StoreUi.gap(this,content,12);content.addView(list);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render();}public void afterTextChanged(Editable e){}});ApiClient.getApps(this,(items,error)->{apps.clear();if(error==null)apps.addAll(items);else apps.add(AppItem.sanbank());render();});}
    private void render(){if(list==null)return;list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(new Locale("pt","BR"));int count=0;for(AppItem a:apps){String hay=(a.name+" "+a.description+" "+a.category).toLowerCase(new Locale("pt","BR"));if(q.isEmpty()||hay.contains(q)){count++;list.addView(StoreUi.appCard(this,a,()->StoreUi.openDetails(this,a)));}}if(count==0)list.addView(StoreUi.text(this,"Nenhum aplicativo encontrado.",14,StoreUi.MUTED,false));}
}
