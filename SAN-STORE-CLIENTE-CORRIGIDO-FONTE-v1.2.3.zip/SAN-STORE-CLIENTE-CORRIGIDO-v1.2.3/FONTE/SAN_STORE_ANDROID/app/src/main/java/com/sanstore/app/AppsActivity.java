package com.sanstore.app;

/** Dedicated Activity for browsing applications. */
public final class AppsActivity extends CategoryActivity {
    @Override protected String categoryKey() { return "App"; }
}
