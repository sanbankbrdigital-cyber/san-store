# SAN STORE Cliente Android — v1.1.6

Aplicativo Android cliente da SAN STORE, desenvolvido em Java com interface nativa.

## Recursos

- Catálogo de aplicativos e jogos publicados e aprovados na SAN STORE.
- Carrossel de destaques com cartões arredondados e troca automática a cada 10 segundos.
- Busca, categorias, detalhes dos aplicativos e downloads.
- Avaliações dos usuários nas páginas de detalhes: nota de 1 a 5 estrelas e comentário escrito (3 a 500 caracteres). É necessário entrar em uma conta SAN STORE para enviar uma avaliação; as avaliações publicadas são exibidas junto da média e da quantidade de notas.
- Conta de usuário, área do desenvolvedor e envio de aplicativos para aprovação.

## Compatibilidade

- `minSdk 21` — Android 5.0 ou superior.
- `targetSdk 37` / `compileSdk 37`.
- Identificador do pacote: `com.sanstore.app`.
- Versão: `1.1.6` (`versionCode 12`).

## Compilação

Abra o diretório `FONTE/SAN_STORE_ANDROID` com Android Studio (JDK 17 e Android SDK 37) ou compile com Gradle 8.13:

```sh
gradle assembleDebug
```

APK de depuração gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O cliente usa o backend SAN STORE configurado em `ApiClient.java`. As avaliações requerem a versão do backend que implementa `GET` e `POST /api/apps/:appId/reviews`.
