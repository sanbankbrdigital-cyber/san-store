package com.sanstore.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Selects 2–8 local screenshots, normalizes them to PNG, and returns Base64 strings. */
public final class ScreenshotPicker {
    public static final int MIN_IMAGES = 2;
    public static final int MAX_IMAGES = 8;
    public static final int MAX_IMAGE_BYTES = 512 * 1024;
    public static final int MAX_TOTAL_BYTES = 4 * 1024 * 1024;
    private static final int MAX_EDGE = 1280;
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Callback { void done(ArrayList<String> base64Pngs, String error); }
    private ScreenshotPicker() { }

    public static void open(Activity activity, int requestCode) {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.setType("image/*");
        picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        activity.startActivityForResult(picker, requestCode);
    }

    public static boolean handleResult(Activity activity, int requestCode, int expectedRequestCode,
                                       int resultCode, Intent data, Callback callback) {
        if (requestCode != expectedRequestCode) return false;
        if (resultCode != Activity.RESULT_OK || data == null) return true;
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount() && unique.size() <= MAX_IMAGES; i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) unique.add(uri.toString());
            }
        } else if (data.getData() != null) {
            unique.add(data.getData().toString());
        }
        if (unique.size() < MIN_IMAGES || unique.size() > MAX_IMAGES) {
            callback.done(null, "Selecione de 2 a 8 imagens de captura de tela.");
            return true;
        }
        ArrayList<Uri> uris = new ArrayList<>();
        for (String value : unique) uris.add(Uri.parse(value));
        WORKER.execute(() -> {
            ArrayList<String> images = new ArrayList<>();
            String error = null;
            int total = 0;
            try {
                for (Uri uri : uris) {
                    byte[] png = toPng(activity, uri);
                    total += png.length;
                    if (total > MAX_TOTAL_BYTES) throw new IllegalArgumentException("O conjunto de imagens ficou grande demais. Escolha capturas menores.");
                    images.add(Base64.encodeToString(png, Base64.NO_WRAP));
                }
            } catch (Exception e) {
                error = e.getMessage() == null ? "Não foi possível processar uma das imagens." : e.getMessage();
                images = null;
            } catch (OutOfMemoryError errorOnImage) {
                error = "Uma imagem é grande demais para processar. Escolha capturas menores.";
                images = null;
            }
            ArrayList<String> result = images;
            String resultError = error;
            MAIN.post(() -> callback.done(result, resultError));
        });
        return true;
    }

    private static byte[] toPng(Activity activity, Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream stream = activity.getContentResolver().openInputStream(uri)) {
            if (stream == null) throw new IllegalArgumentException("Não foi possível abrir uma imagem selecionada.");
            BitmapFactory.decodeStream(stream, null, bounds);
        }
        if (bounds.outWidth < 1 || bounds.outHeight < 1) throw new IllegalArgumentException("Uma imagem selecionada não é válida.");
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_EDGE) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        Bitmap bitmap;
        try (InputStream stream = activity.getContentResolver().openInputStream(uri)) {
            if (stream == null) throw new IllegalArgumentException("Não foi possível abrir uma imagem selecionada.");
            bitmap = BitmapFactory.decodeStream(stream, null, options);
        }
        if (bitmap == null) throw new IllegalArgumentException("Uma imagem selecionada não pôde ser decodificada.");
        try {
            while (true) {
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) throw new IllegalArgumentException("Falha ao converter uma captura para PNG.");
                byte[] result = output.toByteArray();
                if (result.length <= MAX_IMAGE_BYTES) return result;
                int width = Math.round(bitmap.getWidth() * 0.82f);
                int height = Math.round(bitmap.getHeight() * 0.82f);
                if (Math.max(width, height) < 360) throw new IllegalArgumentException("Uma captura ainda excede 512 KB após a conversão.");
                Bitmap smaller = Bitmap.createScaledBitmap(bitmap, Math.max(1, width), Math.max(1, height), true);
                if (smaller != bitmap) bitmap.recycle();
                bitmap = smaller;
            }
        } finally {
            if (!bitmap.isRecycled()) bitmap.recycle();
        }
    }
}
