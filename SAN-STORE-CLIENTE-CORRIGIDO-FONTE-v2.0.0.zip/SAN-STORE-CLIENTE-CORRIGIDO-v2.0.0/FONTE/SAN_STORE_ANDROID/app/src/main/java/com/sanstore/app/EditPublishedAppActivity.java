package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class EditPublishedAppActivity extends Activity {
    private static final int REQUEST_SCREENSHOTS = 6402;
    private AppItem app;
    private ArrayList<String> screenshots = new ArrayList<>();
    private TextView screenshotsStatus;
    private EditText imageUrl;
    private EditText apkUrl;
    private EditText description;
    private EditText whatsNew;
    private TextView status;
    private Button submit;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        app = StoreUi.fromIntent(getIntent());
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Atualizar aplicativo", app.name, true);

        LinearLayout notice = StoreUi.vertical(this);
        notice.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        notice.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        notice.setElevation(StoreUi.dp(this, 5));
        notice.addView(StoreUi.text(this, "O app atual continua publicado enquanto o administrador analisa esta atualização.",
                13, StoreUi.MUTED, false));
        content.addView(notice);

        StoreUi.section(this, content, "Dados da atualização");
        StoreUi.label(this, "URL HTTPS do novo ícone");
        imageUrl = StoreUi.input(this, "https://.../icone.webp", false);
        imageUrl.setText(app.image);
        content.addView(imageUrl);

        StoreUi.label(this, "URL HTTPS do novo APK");
        apkUrl = StoreUi.input(this, "https://.../aplicativo.apk", false);
        apkUrl.setText(app.apk);
        content.addView(apkUrl);

        StoreUi.label(this, "Descrição do aplicativo");
        description = StoreUi.input(this, "Descreva o que o app faz", true);
        description.setText(app.description);
        content.addView(description);

        StoreUi.label(this, "Novidades desta versão");
        whatsNew = StoreUi.input(this, "Descreva as novidades deste lançamento (até 500 caracteres)", true);
        whatsNew.setText(app.whatsNew);
        content.addView(whatsNew);

        StoreUi.section(this, content, "Capturas de tela");
        TextView screenshotHelp = StoreUi.text(this,
                "Se não selecionar novas capturas, a galeria atual será mantida. Para substituí-la, escolha de 2 a 8 imagens.",
                12, StoreUi.MUTED, false);
        screenshotHelp.setPadding(0, 0, 0, StoreUi.dp(this, 8));
        content.addView(screenshotHelp);
        Button chooseScreenshots = StoreUi.button(this, "Selecionar novas capturas (2 a 8)", false);
        chooseScreenshots.setOnClickListener(v -> ScreenshotPicker.open(this, REQUEST_SCREENSHOTS));
        content.addView(chooseScreenshots, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
        screenshotsStatus = StoreUi.text(this, "Buscando capturas atuais…", 12, StoreUi.MUTED, false);
        screenshotsStatus.setPadding(0, StoreUi.dp(this, 6), 0, StoreUi.dp(this, 4));
        content.addView(screenshotsStatus);
        ApiClient.getScreenshots(this, app.id, (current, error) -> {
            if (isFinishing()) return;
            screenshotsStatus.setText(error == null
                    ? current.size() + " captura(s) atualmente publicada(s)."
                    : "Não foi possível contar as capturas atuais; elas serão mantidas se não houver substituição.");
        });

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 10), 0, StoreUi.dp(this, 8));
        content.addView(status);

        submit = StoreUi.button(this, "Enviar atualização para aprovação", true);
        submit.setOnClickListener(v -> sendForReview());
        content.addView(submit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ScreenshotPicker.handleResult(this, requestCode, REQUEST_SCREENSHOTS, resultCode, data, (images, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                return;
            }
            screenshots = images;
            screenshotsStatus.setText(screenshots.size() + " novas capturas prontas para substituir a galeria após aprovação.");
            screenshotsStatus.setTextColor(StoreUi.GREEN);
        });
    }

    private void sendForReview() {
        String image = imageUrl.getText().toString().trim();
        String apk = apkUrl.getText().toString().trim();
        String text = description.getText().toString().trim();
        String changes = whatsNew.getText().toString().trim();
        if (!image.startsWith("https://") || !apk.startsWith("https://") || text.length() < 5 ||
                text.length() > 350 || changes.length() > 500) {
            status.setText("Use URLs HTTPS válidas; descrição de 5 a 350 caracteres e novidades de até 500.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        submit.setEnabled(false);
        submit.setText("Enviando para análise…");
        status.setText("O app publicado não muda até a aprovação do administrador.");
        status.setTextColor(StoreUi.MUTED);
        ApiClient.submitAppUpdate(this, app, image, apk, text, changes, screenshots, (response, error) -> {
            if (isFinishing()) return;
            submit.setEnabled(true);
            submit.setText("Enviar atualização para aprovação");
            if (error != null) {
                status.setText(error.getMessage());
                status.setTextColor(StoreUi.GOLD);
                return;
            }
            Toast.makeText(this, "Atualização enviada para aprovação.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
