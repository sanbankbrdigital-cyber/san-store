package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class PublishAppActivity extends Activity {
    private static final int REQUEST_SCREENSHOTS = 6401;
    private EditText name, image, apk, description, whatsNew;
    private ArrayList<String> screenshots = new ArrayList<>();
    private TextView screenshotsStatus;
    private Spinner category;
    private Spinner subcategory;
    private Button submit;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Nova publicação", "Envio para análise administrativa", true);

        LinearLayout note = StoreUi.vertical(this);
        note.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        note.setBackground(StoreUi.shape(0xff202c45, StoreUi.dp(this, 19), 0xff354767));
        note.setElevation(StoreUi.dp(this, 6));
        note.addView(StoreUi.badge(this, "PUBLICAÇÃO SOB REVISÃO", 0xff2b3d61, 0xffd7e2ff));
        TextView explanation = StoreUi.text(this, "O app não aparecerá na loja até ser aprovado pelo administrador.", 12, StoreUi.MUTED, false);
        explanation.setPadding(0, StoreUi.dp(this, 8), 0, 0);
        note.addView(explanation);
        content.addView(note);

        StoreUi.label(this, "Nome do app ou jogo");
        name = StoreUi.input(this, "Ex.: Meu aplicativo", false);
        content.addView(name);

        StoreUi.label(this, "Tipo de publicação");
        category = new Spinner(this);
        ArrayAdapter<String> adapter = spinnerAdapter(new String[]{"Aplicativo", "Jogo"});
        category.setAdapter(adapter);
        category.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 16), 0xff2b3a53));
        category.setElevation(StoreUi.dp(this, 4));
        category.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 6), StoreUi.dp(this, 14), StoreUi.dp(this, 6));
        content.addView(category, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));

        StoreUi.label(this, "Categoria do aplicativo");
        subcategory = new Spinner(this);
        String[] categoryChoices = new String[AppCategories.VALUES.length + 1];
        categoryChoices[0] = "Selecione uma categoria";
        System.arraycopy(AppCategories.VALUES, 0, categoryChoices, 1, AppCategories.VALUES.length);
        ArrayAdapter<String> subcategoryAdapter = spinnerAdapter(categoryChoices);
        subcategory.setAdapter(subcategoryAdapter);
        subcategory.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 16), 0xff2b3a53));
        subcategory.setElevation(StoreUi.dp(this, 4));
        subcategory.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 6), StoreUi.dp(this, 14), StoreUi.dp(this, 6));
        content.addView(subcategory, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));

        StoreUi.label(this, "Link HTTPS público do ícone");
        image = StoreUi.input(this, "https://.../icone.webp", false);
        content.addView(image);
        StoreUi.label(this, "Link HTTPS público do APK");
        apk = StoreUi.input(this, "https://.../aplicativo.apk", false);
        content.addView(apk);
        StoreUi.label(this, "Descrição");
        description = StoreUi.input(this, "Descreva o que o app faz", true);
        content.addView(description);
        StoreUi.label(this, "Novidades desta versão (opcional)");
        whatsNew = StoreUi.input(this, "O que há de novo neste lançamento?", true);
        content.addView(whatsNew);

        StoreUi.section(this, content, "Capturas de tela do aplicativo ou jogo");
        TextView screenshotHelp = StoreUi.text(this,
                "Escolha de 2 a 8 imagens. Elas serão convertidas para PNG e Base64; após a aprovação, aparecerão publicamente na loja.",
                12, StoreUi.MUTED, false);
        screenshotHelp.setPadding(0, 0, 0, StoreUi.dp(this, 8));
        content.addView(screenshotHelp);
        Button chooseScreenshots = StoreUi.button(this, "Selecionar capturas (2 a 8)", false);
        chooseScreenshots.setOnClickListener(v -> ScreenshotPicker.open(this, REQUEST_SCREENSHOTS));
        content.addView(chooseScreenshots, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
        screenshotsStatus = StoreUi.text(this, "Nenhuma captura selecionada.", 12, StoreUi.GOLD, false);
        screenshotsStatus.setPadding(0, StoreUi.dp(this, 6), 0, StoreUi.dp(this, 4));
        content.addView(screenshotsStatus);

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 9), 0, StoreUi.dp(this, 7));
        content.addView(status);
        submit = StoreUi.button(this, "Enviar para aprovação", true);
        submit.setOnClickListener(v -> submit());
        content.addView(submit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private ArrayAdapter<String> spinnerAdapter(String[] choices) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, choices) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView row = (TextView) super.getView(position, convertView, parent);
                row.setTextColor(StoreUi.TEXT);
                return row;
            }

            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView row = (TextView) super.getDropDownView(position, convertView, parent);
                row.setTextColor(StoreUi.TEXT);
                row.setBackgroundColor(StoreUi.CARD_ALT);
                row.setPadding(StoreUi.dp(PublishAppActivity.this, 14), StoreUi.dp(PublishAppActivity.this, 12),
                        StoreUi.dp(PublishAppActivity.this, 14), StoreUi.dp(PublishAppActivity.this, 12));
                return row;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ScreenshotPicker.handleResult(this, requestCode, REQUEST_SCREENSHOTS, resultCode, data, (images, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                return;
            }
            screenshots = images;
            screenshotsStatus.setText(screenshots.size() + " capturas prontas em PNG para enviar.");
            screenshotsStatus.setTextColor(StoreUi.GREEN);
        });
    }

    private void submit() {
        String n = name.getText().toString().trim();
        String im = image.getText().toString().trim();
        String ap = apk.getText().toString().trim();
        String desc = description.getText().toString().trim();
        String changes = whatsNew.getText().toString().trim();
        if (screenshots.size() < ScreenshotPicker.MIN_IMAGES || screenshots.size() > ScreenshotPicker.MAX_IMAGES) {
            status.setText("Selecione de 2 a 8 capturas de tela antes de enviar.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        if (n.length() < 2 || n.length() > 60 || desc.length() < 5 || desc.length() > 350 || changes.length() > 500 ||
                !im.startsWith("https://") || !ap.startsWith("https://")) {
            status.setText("Preencha os campos e use links HTTPS válidos.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        if (subcategory.getSelectedItemPosition() == 0) {
            status.setText("Selecione uma categoria para o aplicativo.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        submit.setEnabled(false);
        submit.setText("Enviando…");
        status.setText("Enviando para análise do administrador…");
        status.setTextColor(StoreUi.MUTED);
        String value = category.getSelectedItemPosition() == 1 ? "Game" : "App";
        String categoryValue = (String) subcategory.getSelectedItem();
        ApiClient.submitApp(this, n, value, categoryValue, im, ap, desc, changes, screenshots, (response, error) -> {
            if (isFinishing()) return;
            submit.setEnabled(true);
            submit.setText("Enviar para aprovação");
            if (error != null) {
                status.setText(error.getMessage());
                status.setTextColor(StoreUi.GOLD);
                return;
            }
            Toast.makeText(this, "Enviado. O app só será publicado após aprovação.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
