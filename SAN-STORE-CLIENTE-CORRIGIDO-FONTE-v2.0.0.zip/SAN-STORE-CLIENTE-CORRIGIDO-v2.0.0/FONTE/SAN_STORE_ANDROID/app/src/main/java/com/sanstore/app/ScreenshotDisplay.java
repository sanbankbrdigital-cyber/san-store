package com.sanstore.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

public final class ScreenshotDisplay {
    private ScreenshotDisplay() { }

    public static Bitmap decode(String encodedPng, int maximumEdge) {
        try {
            byte[] bytes = Base64.decode(encodedPng, Base64.DEFAULT);
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth < 1 || bounds.outHeight < 1) return null;
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maximumEdge) sample *= 2;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        } catch (Exception | OutOfMemoryError ignored) {
            return null;
        }
    }
}
