package com.sanstore.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native, battery-aware notification checks for appeal decisions. */
public final class DeveloperAppealNotifications {
    private static final String CHANNEL_ID = "san_store_appeal_decisions";
    private static final int JOB_ID = 8301;
    private static final String PREFS = "developer_appeal_notifications";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private DeveloperAppealNotifications() { }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean("enabled", true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        SharedPreferences preferences = prefs(context);
        SharedPreferences.Editor editor = preferences.edit().putBoolean("enabled", enabled);
        if (!enabled) {
            for (String key : preferences.getAll().keySet()) {
                if (key.startsWith("appeal_id_") || key.startsWith("appeal_status_")) editor.remove(key);
            }
        }
        editor.apply();
        if (enabled) schedule(context); else cancel(context);
    }

    public static boolean notificationsAllowed(Context context) {
        return Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                == PackageManager.PERMISSION_GRANTED;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void schedule(Context context) {
        if (!isEnabled(context)) return;
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        if (Build.VERSION.SDK_INT >= 24 && scheduler.getPendingJob(JOB_ID) != null) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(context, DeveloperAppealCheckJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(15 * 60 * 1000L)
                .build();
        scheduler.schedule(job);
    }

    public static void cancel(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) scheduler.cancel(JOB_ID);
    }

    public static synchronized void observe(Context context, String appId, String appName,
                                            String appealId, String status) {
        if (appId == null || appId.isEmpty() || appealId == null || appealId.isEmpty() ||
                status == null || status.isEmpty()) return;
        SharedPreferences preferences = prefs(context);
        String idKey = "appeal_id_" + appId;
        String statusKey = "appeal_status_" + appId;
        String previousId = preferences.getString(idKey, "");
        String previousStatus = preferences.getString(statusKey, "");
        boolean resolved = "approved".equals(status) || "rejected".equals(status);
        boolean decisionArrived = appealId.equals(previousId) && "pending".equals(previousStatus) && resolved;
        if (decisionArrived && isEnabled(context)) {
            if (notificationsAllowed(context)) {
                show(context, appId, appName, "approved".equals(status));
            } else {
                // Keep the pending baseline so granting notification permission can deliver this decision later.
                return;
            }
        }
        preferences.edit().putString(idKey, appealId).putString(statusKey, status).apply();
    }

    public static void observeDeveloperApps(Context context, JSONArray apps) {
        if (apps == null) return;
        for (int i = 0; i < apps.length(); i++) {
            JSONObject app = apps.optJSONObject(i);
            if (app == null) continue;
            observe(context, app.optString("id", ""), app.optString("name", "Aplicativo"),
                    app.optString("appealId", ""), app.optString("appealStatus", ""));
        }
    }

    public static void checkInBackground(Context context) {
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> checkNow(appContext));
    }

    static void checkNow(Context context) {
        if (!isEnabled(context)) {
            cancel(context);
            return;
        }
        String token = ApiClient.sessionToken(context);
        if (token == null || token.isEmpty()) {
            cancel(context);
            return;
        }
        HttpURLConnection connection = null;
        try {
            String base = ApiClient.baseUrl(context).replaceAll("/+$", "");
            URL url = new URL(base + "/api/developer/apps");
            if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalStateException("HTTPS required");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15_000);
            connection.setReadTimeout(25_000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-store");
            connection.setRequestProperty("Authorization", "Bearer " + token);
            int code = connection.getResponseCode();
            if (code == 200) {
                StringBuilder text = new StringBuilder();
                try (InputStream input = connection.getInputStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) text.append(line);
                }
                observeDeveloperApps(context, new JSONArray(text.toString()));
            } else if (code == 401 || code == 403) {
                cancel(context);
            }
        } catch (Exception ignored) {
            // The periodic job will retry on its next network window.
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static void show(Context context, String appId, String appName, boolean approved) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Decisões de apelação SAN STORE", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Avisos sobre desbloqueio ou remoção de apps após apelação.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, DeveloperActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int notificationId = appId.hashCode() & 0x7fffffff;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(context, notificationId, open, flags);
        String name = appName == null || appName.trim().isEmpty() ? "Seu aplicativo" : appName.trim();
        String title = approved ? "Apelação aprovada" : "Apelação recusada";
        String message = approved
                ? name + " foi desbloqueado e pode voltar a receber downloads na SAN STORE."
                : name + " foi removido da loja após a recusa da apelação.";
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        Notification notification = builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title).setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(pending).setAutoCancel(true).build();
        manager.notify(notificationId, notification);
    }
}
