package com.sanstore.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiClient {
    private static final String PREFS = "san_store_settings";
    private static final String BASE_URL = "api_base_url";
    private static final String SESSION_TOKEN = "auth_session_token";
    private static final String SESSION_ACCOUNT = "auth_session_account";
    private static final String SESSION_EMAIL = "auth_session_email";
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Callback<T> { void done(T value, Exception error); }

    public static final class ApiException extends Exception {
        public final int statusCode;
        ApiException(int statusCode, String message) { super(message); this.statusCode = statusCode; }
    }

    public static final class AuthSession {
        public final String account;
        public final String email;
        AuthSession(String account, String email) { this.account = account; this.email = email; }
    }

    private ApiClient() {}

    private static Activity beginLoading(Context context) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            StoreUi.showLoading(activity);
            return activity;
        }
        return null;
    }

    private static void endLoading(Activity activity) {
        if (activity != null) StoreUi.hideLoading(activity);
    }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String baseUrl(Context context) {
        return preferences(context).getString(BASE_URL, "https://san-store-dnrd.onrender.com").trim().replaceAll("/+$", "");
    }

    public static void saveBaseUrl(Context context, String value) {
        preferences(context).edit().putString(BASE_URL, value.trim().replaceAll("/+$", "")).apply();
    }

    public static String sessionToken(Context context) { return preferences(context).getString(SESSION_TOKEN, ""); }
    public static String sessionAccount(Context context) { return preferences(context).getString(SESSION_ACCOUNT, ""); }
    public static String sessionEmail(Context context) { return preferences(context).getString(SESSION_EMAIL, ""); }

    public static void clearSession(Context context) {
        preferences(context).edit().remove(SESSION_TOKEN).remove(SESSION_ACCOUNT).remove(SESSION_EMAIL).apply();
        DeveloperAppealNotifications.cancel(context);
    }

    private static String endpoint(Context c, String path) throws Exception {
        String base = baseUrl(c);
        if (base.isEmpty()) throw new IllegalStateException("Configure o endereço do servidor em Configurações.");
        URL u = new URL(base);
        if (!"https".equalsIgnoreCase(u.getProtocol())) throw new IllegalArgumentException("O servidor precisa usar HTTPS.");
        return base + path;
    }

    private static String request(Context context, String path, String method, JSONObject body, String key) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint(context, path)).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(75000);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Cache-Control", "no-store");
        if (key != null && !key.trim().isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + key.trim());
        if (body != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream out = conn.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String text = readAll(stream);
        conn.disconnect();
        if (code < 200 || code >= 300) {
            String detail = "Falha HTTP " + code;
            try { detail = new JSONObject(text).optString("error", detail); } catch (Exception ignored) {}
            throw new ApiException(code, detail);
        }
        return text;
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void fail(String message, Callback<?> callback) {
        Exception e = new Exception(message);
        MAIN.post(() -> callback.done(null, e));
    }

    private static AuthSession parseAndSaveSession(Context context, JSONObject response, String token) throws Exception {
        JSONObject user = response.optJSONObject("user");
        if (user == null) throw new IllegalArgumentException("Resposta de conta inválida.");
        String account = user.optString("account", "");
        String email = user.optString("email", "");
        if (account.isEmpty() || email.isEmpty()) throw new IllegalArgumentException("Dados da conta incompletos.");
        SharedPreferences.Editor editor = preferences(context).edit()
                .putString(SESSION_ACCOUNT, account)
                .putString(SESSION_EMAIL, email);
        if (token != null) editor.putString(SESSION_TOKEN, token);
        editor.apply();
        return new AuthSession(account, email);
    }

    public static void register(Context context, String account, String email, String password, Callback<AuthSession> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("account", account.trim());
                body.put("email", email.trim());
                body.put("password", password);
                JSONObject response = new JSONObject(request(appContext, "/api/auth/register", "POST", body, null));
                String token = response.optString("token", "");
                if (token.isEmpty()) throw new IllegalArgumentException("A API não retornou uma sessão válida.");
                AuthSession session = parseAndSaveSession(appContext, response, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(session, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void login(Context context, String identifier, String password, Callback<AuthSession> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("identifier", identifier.trim());
                body.put("password", password);
                JSONObject response = new JSONObject(request(appContext, "/api/auth/login", "POST", body, null));
                String token = response.optString("token", "");
                if (token.isEmpty()) throw new IllegalArgumentException("A API não retornou uma sessão válida.");
                AuthSession session = parseAndSaveSession(appContext, response, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(session, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void verifySession(Context context, Callback<AuthSession> callback) {
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        if (token.isEmpty()) { fail("Entre na sua conta para continuar.", callback); return; }
        Activity loadingActivity = beginLoading(context);
        EXECUTOR.execute(() -> {
            try {
                JSONObject response = new JSONObject(request(appContext, "/api/auth/me", "GET", null, token));
                AuthSession session = parseAndSaveSession(appContext, response, null);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(session, null); });
            } catch (Exception e) {
                if (e instanceof ApiException && ((ApiException) e).statusCode == 401) clearSession(appContext);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); });
            }
        });
    }

    public static void logout(Context context, Callback<Boolean> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        clearSession(appContext);
        EXECUTOR.execute(() -> {
            if (!token.isEmpty()) {
                try { request(appContext, "/api/auth/session", "DELETE", null, token); }
                catch (Exception ignored) { /* The local token is cleared even if offline. */ }
            }
            MAIN.post(() -> { endLoading(loadingActivity); callback.done(Boolean.TRUE, null); });
        });
    }

    public static final class DeveloperAccess {
        public final String status;
        public final String developerName;
        public final String developerAccount;
        DeveloperAccess(String status, String developerName, String developerAccount) {
            this.status = status;
            this.developerName = developerName;
            this.developerAccount = developerAccount;
        }
    }

    public static final class DeveloperApp {
        public final AppItem app;
        public final boolean pendingUpdate;
        public final String latestUpdateStatus;
        public final String rejectionReason;
        public final String status;
        public final String appealStatus;
        public final String appealId;
        public final String appealMessage;
        public final String appealReviewReason;
        DeveloperApp(AppItem app, boolean pendingUpdate, String latestUpdateStatus, String rejectionReason,
                     String status, String appealStatus, String appealId, String appealMessage, String appealReviewReason) {
            this.app = app;
            this.pendingUpdate = pendingUpdate;
            this.latestUpdateStatus = latestUpdateStatus;
            this.rejectionReason = rejectionReason;
            this.status = status;
            this.appealStatus = appealStatus;
            this.appealId = appealId;
            this.appealMessage = appealMessage;
            this.appealReviewReason = appealReviewReason;
        }
    }

    public static final class AppReview {
        public final int rating;
        public final String reviewerName;
        public final String comment;
        public final String createdAt;
        AppReview(int rating, String reviewerName, String comment, String createdAt) {
            this.rating = rating;
            this.reviewerName = reviewerName;
            this.comment = comment;
            this.createdAt = createdAt;
        }
    }

    public static final class ReviewSummary {
        public final float averageRating;
        public final int reviewCount;
        public final ArrayList<AppReview> reviews;
        ReviewSummary(float averageRating, int reviewCount, ArrayList<AppReview> reviews) {
            this.averageRating = averageRating;
            this.reviewCount = reviewCount;
            this.reviews = reviews;
        }
    }

    public static void getDeveloperAccess(Context context, Callback<DeveloperAccess> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        EXECUTOR.execute(() -> {
            try {
                JSONObject response = new JSONObject(request(appContext, "/api/developer/me", "GET", null, token));
                DeveloperAccess access = new DeveloperAccess(response.optString("status", "none"), response.optString("developerName", ""), response.optString("developerAccount", ""));
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(access, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void requestDeveloperAccess(Context context, Callback<DeveloperAccess> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        EXECUTOR.execute(() -> {
            try {
                JSONObject response = new JSONObject(request(appContext, "/api/developer/request", "POST", new JSONObject(), token));
                DeveloperAccess access = new DeveloperAccess(response.optString("status", "pending"), "", "");
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(access, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void getDeveloperApps(Context context, Callback<ArrayList<DeveloperApp>> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        EXECUTOR.execute(() -> {
            try {
                JSONArray array = new JSONArray(request(appContext, "/api/developer/apps", "GET", null, token));
                ArrayList<DeveloperApp> apps = new ArrayList<>();
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item == null) continue;
                    apps.add(new DeveloperApp(AppItem.fromJson(item), item.optBoolean("pendingUpdate", false),
                            item.optString("latestUpdateStatus", ""), item.optString("rejectionReason", ""),
                            item.optString("status", "approved"), item.optString("appealStatus", ""),
                            item.optString("appealId", ""), item.optString("appealMessage", ""),
                            item.optString("appealReviewReason", "")));
                }
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(apps, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void submitAppAppeal(Context context, String appId, String message, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        String path = "/api/developer/apps/" + Uri.encode(appId) + "/appeal";
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("message", message.trim());
                String response = request(appContext, path, "POST", body, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(response, null); });
            } catch (Exception e) {
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); });
            }
        });
    }

    public static void submitApp(Context context, String name, String category, String subcategory, String image, String apk, String description, Callback<String> callback) {
        submitApp(context, name, category, subcategory, image, apk, description, "", callback);
    }

    public static void submitApp(Context context, String name, String category, String subcategory, String image, String apk, String description, String whatsNew, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name.trim());
                body.put("category", category);
                body.put("subcategory", subcategory);
                body.put("image", image.trim());
                body.put("apk", apk.trim());
                body.put("description", description.trim());
                body.put("whatsNew", whatsNew == null ? "" : whatsNew.trim());
                String response = request(appContext, "/api/submissions", "POST", body, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(response, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void submitAppUpdate(Context context, AppItem app, String image, String apk, String description,
                                       String whatsNew, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("appId", app.id);
                body.put("name", app.name);
                body.put("category", app.category);
                body.put("subcategory", app.subcategory);
                body.put("image", image.trim());
                body.put("apk", apk.trim());
                body.put("description", description.trim());
                body.put("whatsNew", whatsNew == null ? "" : whatsNew.trim());
                String response = request(appContext, "/api/submissions", "POST", body, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(response, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void getApps(Context context, Callback<ArrayList<AppItem>> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                JSONArray array = new JSONArray(request(appContext, "/api/apps", "GET", null, null));
                ArrayList<AppItem> items = new ArrayList<>();
                for (int i = 0; i < array.length(); i++) items.add(AppItem.fromJson(array.getJSONObject(i)));
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(items, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void getReviews(Context context, String appId, Callback<ReviewSummary> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String path = "/api/apps/" + Uri.encode(appId) + "/reviews";
        EXECUTOR.execute(() -> {
            try {
                JSONObject response = new JSONObject(request(appContext, path, "GET", null, null));
                JSONArray array = response.optJSONArray("reviews");
                ArrayList<AppReview> reviews = new ArrayList<>();
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject review = array.optJSONObject(i);
                        if (review == null) continue;
                        reviews.add(new AppReview(review.optInt("rating", 0), review.optString("reviewerName", "Usuário"),
                                review.optString("comment", ""), review.optString("createdAt", "")));
                    }
                }
                ReviewSummary summary = new ReviewSummary((float) response.optDouble("averageRating", 0),
                        response.optInt("reviewCount", reviews.size()), reviews);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(summary, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void submitReview(Context context, String appId, int rating, String comment, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        String token = sessionToken(appContext);
        String path = "/api/apps/" + Uri.encode(appId) + "/reviews";
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("rating", rating);
                body.put("comment", comment.trim());
                String response = request(appContext, path, "POST", body, token);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(response, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void health(Context context, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                String result = request(appContext, "/api/health", "GET", null, null);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(result, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }

    public static void publish(Context context, String name, String category, String image, String apk, String description, String key, Callback<String> callback) {
        Activity loadingActivity = beginLoading(context);
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name.trim());
                body.put("category", category);
                body.put("image", image.trim());
                body.put("apk", apk.trim());
                body.put("description", description.trim());
                String response = request(appContext, "/api/apps", "POST", body, key);
                MAIN.post(() -> { endLoading(loadingActivity); callback.done(response, null); });
            } catch (Exception e) { MAIN.post(() -> { endLoading(loadingActivity); callback.done(null, e); }); }
        });
    }
}
