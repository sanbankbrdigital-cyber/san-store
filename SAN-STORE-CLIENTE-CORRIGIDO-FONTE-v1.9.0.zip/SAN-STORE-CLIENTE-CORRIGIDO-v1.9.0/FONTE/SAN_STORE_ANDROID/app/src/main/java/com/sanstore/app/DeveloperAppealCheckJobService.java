package com.sanstore.app;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Periodic Android notification check; Android controls exact execution time. */
public class DeveloperAppealCheckJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            DeveloperAppealNotifications.checkNow(this);
            jobFinished(params, false);
        }, "san-store-developer-appeal-check").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        return true;
    }
}
