package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SecurityInfoActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Segurança e licenças",
                "Transparência técnica do SAN STORE Cliente", true);

        addCard(content, "Versão e compatibilidade", versionDetails());
        addCard(content, "Aplicativo Android nativo",
                "Cliente desenvolvido em Java com Activities e componentes da plataforma Android. " +
                "Não utiliza WebView para exibir a loja. Compatibilidade mínima: Android 5.0 (API 21). " +
                "A versão-alvo do Android é exibida no bloco acima.");
        addCard(content, "Conexão e permissões",
                "O tráfego HTTP sem criptografia é bloqueado pelo aplicativo; a API é configurada para HTTPS. " +
                "As permissões declaradas são acesso à Internet e solicitação para iniciar a instalação de pacotes " +
                "pelo instalador do Android.");
        addCard(content, "Conta e instalação",
                "A senha não é guardada como senha no aplicativo. A sessão é validada pelo servidor e encerrada " +
                "no servidor quando você sai da conta. A instalação de um APK é encaminhada ao instalador do " +
                "Android e exige confirmação do usuário; o aplicativo não faz instalação silenciosa.");
        addCard(content, "Licenças dos componentes",
                "Esta versão não declara bibliotecas Android de terceiros como dependências de execução neste módulo. " +
                "O Android SDK e a plataforma Java mantêm as licenças de seus respectivos fornecedores. " +
                "Esta informação não é uma licença jurídica de uso do SAN STORE nem substitui os termos de distribuição.");
        addCard(content, "Sobre a verificação da Google Play",
                "Esta tela é informativa: não é auditoria, selo de segurança nem aprovação da Google Play, e não " +
                "garante segurança total. A análise oficial e as declarações do Play Console são separadas. " +
                "O responsável pela publicação deve preencher com precisão a seção Segurança dos dados (Data safety) " +
                "e as divulgações de privacidade aplicáveis, conforme o comportamento real do aplicativo.");

        Button guidance = StoreUi.button(this, "Orientação Segurança dos dados", false);
        guidance.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://support.google.com/googleplay/android-developer/answer/10787469?hl=en"));
            startActivity(intent);
        });
        content.addView(guidance, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));

        TextView note = StoreUi.text(this,
                "As informações técnicas descrevem esta versão do cliente; elas não substituem testes, revisão de segurança ou a análise da loja.",
                12, StoreUi.MUTED, false);
        note.setPadding(0, StoreUi.dp(this, 14), 0, 0);
        content.addView(note);
    }

    private void addCard(LinearLayout content, String title, String body) {
        StoreUi.section(this, content, title);
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 16), StoreUi.dp(this, 15),
                StoreUi.dp(this, 16), StoreUi.dp(this, 15));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        card.setElevation(StoreUi.dp(this, 6));
        TextView description = StoreUi.text(this, body, 13, StoreUi.MUTED, false);
        description.setLineSpacing(StoreUi.dp(this, 3), 1.0f);
        card.addView(description);
        content.addView(card);
    }

    private String versionDetails() {
        String version = "indisponível";
        long code = -1;
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            version = packageInfo.versionName;
            code = Build.VERSION.SDK_INT >= 28 ? packageInfo.getLongVersionCode() : packageInfo.versionCode;
        } catch (Exception ignored) {
        }
        ApplicationInfo applicationInfo = getApplicationInfo();
        int minSdk = Build.VERSION.SDK_INT >= 24 ? applicationInfo.minSdkVersion : 21;
        return "Versão instalada: " + version + " (código " + code + ").\n" +
                "Android mínimo: API " + minSdk + "; Android alvo: API " + applicationInfo.targetSdkVersion + ".";
    }
}
