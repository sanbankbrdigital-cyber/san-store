package com.sanstore.admin;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class AdminUi {
    public static final int BG = Color.rgb(9, 13, 22);
    public static final int CARD = Color.rgb(18, 26, 40);
    public static final int ALT = Color.rgb(27, 38, 57);
    public static final int TEXT = Color.rgb(245, 248, 255);
    public static final int MUTED = Color.rgb(165, 177, 198);
    public static final int BLUE = Color.rgb(123, 151, 255);
    public static final int GREEN = Color.rgb(104, 226, 184);
    public static final int GOLD = Color.rgb(255, 203, 126);
    private static final int BORDER = Color.rgb(43, 57, 79);

    private AdminUi() {}
    public static int dp(Activity a, float v) { return (int)(v * a.getResources().getDisplayMetrics().density + 0.5f); }
    public static LinearLayout vertical(Activity a) { LinearLayout l=new LinearLayout(a);l.setOrientation(LinearLayout.VERTICAL);return l; }
    public static LinearLayout horizontal(Activity a) { LinearLayout l=new LinearLayout(a);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    public static GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke!=0)d.setStroke(1,stroke);return d;}
    public static GradientDrawable gradient(int from,int to,int radius,int stroke){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{from,to});d.setCornerRadius(radius);if(stroke!=0)d.setStroke(1,stroke);return d;}
    public static TextView text(Activity a,String s,float size,int color,boolean bold){TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    public static TextView badge(Activity a,String s,int bg,int fg){TextView t=text(a,s,10,fg,true);t.setLetterSpacing(.06f);t.setPadding(dp(a,10),dp(a,6),dp(a,10),dp(a,6));t.setBackground(shape(bg,dp(a,24),0));return t;}
    public static LinearLayout screen(Activity a,String title,String subtitle,boolean back){
        a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);
        LinearLayout outer=vertical(a);outer.setBackgroundColor(BG);
        LinearLayout header=horizontal(a);header.setPadding(dp(a,20),dp(a,14),dp(a,20),dp(a,12));
        if(back){TextView b=text(a,"‹",32,TEXT,false);b.setGravity(Gravity.CENTER);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),shape(ALT,dp(a,16),BORDER),shape(Color.WHITE,dp(a,16),0)));header.addView(b,new LinearLayout.LayoutParams(dp(a,44),dp(a,44)));b.setOnClickListener(v->a.finish());}
        LinearLayout titles=vertical(a);if(back)titles.setPadding(dp(a,11),0,0,0);titles.addView(text(a,title,back?21:24,TEXT,true));
        if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=text(a,subtitle,12,MUTED,false);sub.setPadding(0,dp(a,3),0,0);titles.addView(sub);}
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));outer.addView(header);
        ScrollView scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content=vertical(a);content.setPadding(dp(a,20),dp(a,8),dp(a,20),dp(a,32));scroll.addView(content);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        outer.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,i.getSystemWindowInsetTop(),0,i.getSystemWindowInsetBottom());return i;});a.setContentView(outer);outer.requestApplyInsets();return content;
    }
    public static void section(Activity a,LinearLayout p,String title){TextView t=text(a,title,18,TEXT,true);t.setPadding(0,dp(a,20),0,dp(a,11));p.addView(t);}
    public static void label(Activity a,LinearLayout p,String title){TextView t=text(a,title,12,MUTED,true);t.setPadding(dp(a,2),dp(a,15),0,dp(a,7));p.addView(t);}
    public static EditText input(Activity a,String hint,boolean multiline){EditText e=new EditText(a);e.setSingleLine(!multiline);e.setTextColor(TEXT);e.setHintTextColor(Color.rgb(122,137,160));e.setHint(hint);e.setTextSize(14);e.setPadding(dp(a,15),dp(a,12),dp(a,15),dp(a,12));e.setBackground(shape(Color.rgb(14,20,32),dp(a,16),BORDER));if(multiline){e.setGravity(Gravity.TOP);e.setMinLines(3);e.setMaxLines(6);}LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT);p.bottomMargin=dp(a,4);e.setLayoutParams(p);return e;}
    public static Button button(Activity a,String title,boolean primary){Button b=new Button(a);b.setText(title);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setPadding(dp(a,16),dp(a,12),dp(a,16),dp(a,12));GradientDrawable fill=primary?gradient(0xff708dff,0xff5b73e8,dp(a,17),0):shape(ALT,dp(a,17),BORDER);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44ffffff),fill,shape(Color.WHITE,dp(a,17),0)));b.setMinHeight(dp(a,52));b.setElevation(dp(a,2));return b;}
    public static void gap(Activity a,LinearLayout p,int h){View v=new View(a);p.addView(v,new LinearLayout.LayoutParams(1,dp(a,h)));}
    public static LinearLayout card(Activity a){LinearLayout c=vertical(a);c.setPadding(dp(a,15),dp(a,15),dp(a,15),dp(a,15));c.setBackground(shape(CARD,dp(a,21),BORDER));c.setElevation(dp(a,2));return c;}
}
