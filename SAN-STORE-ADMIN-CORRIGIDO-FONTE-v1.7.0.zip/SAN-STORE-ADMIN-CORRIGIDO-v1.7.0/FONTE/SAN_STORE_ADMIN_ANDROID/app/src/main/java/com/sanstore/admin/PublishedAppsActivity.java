package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

public class PublishedAppsActivity extends Activity {
    private LinearLayout list;
    private TextView state;
    private Button refresh;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        list = AdminUi.screen(this, "Aplicativos na loja", "Bloqueie ou libere downloads", true);
        refresh = AdminUi.button(this, "Atualizar lista", false);
        list.addView(refresh);
        state = AdminUi.text(this, "Carregando…", 13, AdminUi.MUTED, false);
        state.setPadding(0, AdminUi.dp(this, 12), 0, 0);
        list.addView(state);
        refresh.setOnClickListener(view -> load());
        load();
    }

    private void load() {
        AdminApi.call(this, "GET", "/api/admin/apps", null, (code, object, items, error) -> {
            if (code != 200 || items == null) {
                state.setText(error != null ? error : AdminApi.message(object,
                        "Não foi possível carregar os aplicativos publicados."));
                return;
            }
            list.removeViews(2, Math.max(0, list.getChildCount() - 2));
            if (items.length() == 0) {
                state.setText("Ainda não há aplicativos publicados pela administração.");
                return;
            }
            int blockedCount = 0;
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item != null && item.optBoolean("blocked", false)) blockedCount++;
            }
            state.setText(items.length() + " aplicativo(s) · " + blockedCount + " bloqueado(s)");
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item != null) addAppCard(item);
            }
        });
    }

    private void addAppCard(JSONObject item) {
        String appId = item.optString("id", "");
        String name = item.optString("name", "Sem nome");
        boolean blocked = item.optBoolean("blocked", false);

        LinearLayout card = AdminUi.card(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = AdminUi.dp(this, 12);
        list.addView(card, cardParams);
        card.addView(AdminUi.text(this, name, 17, AdminUi.TEXT, true));

        String publisher = item.optString("developerName", "Publicador não informado");
        TextView meta = AdminUi.text(this,
                "Publicado por: " + publisher + " · " + item.optString("category", "App"),
                12, AdminUi.MUTED, false);
        meta.setPadding(0, AdminUi.dp(this, 5), 0, AdminUi.dp(this, 10));
        card.addView(meta);

        TextView statusBadge = AdminUi.badge(this,
                blocked ? "🔒 BLOQUEADO · DOWNLOAD SUSPENSO" : "● DISPONÍVEL PARA DOWNLOAD",
                blocked ? 0xff4b2830 : 0xff174137,
                blocked ? 0xffffc2ca : AdminUi.GREEN);
        card.addView(statusBadge);

        Button edit = AdminUi.button(this, "Editar dados do aplicativo/jogo", false);
        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50));
        editParams.topMargin = AdminUi.dp(this, 10);
        card.addView(edit, editParams);
        edit.setOnClickListener(view -> {
            Intent intent = new Intent(this, PublishedAppEditActivity.class);
            intent.putExtra("appId", appId);
            startActivity(intent);
        });

        if (blocked) {
            String reason = item.optString("blockReason", "").trim();
            if (!reason.isEmpty()) {
                TextView note = AdminUi.text(this, "Aviso exibido: " + reason, 12, AdminUi.MUTED, false);
                note.setPadding(0, AdminUi.dp(this, 8), 0, AdminUi.dp(this, 2));
                card.addView(note);
            }
        }

        Button action = AdminUi.button(this,
                blocked ? "Liberar downloads" : "Bloquear na SAN STORE", blocked);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50));
        actionParams.topMargin = AdminUi.dp(this, 12);
        card.addView(action, actionParams);
        action.setOnClickListener(view -> {
            if (blocked) confirmUnblock(appId, name);
            else requestBlockReason(appId, name);
        });
    }

    private void requestBlockReason(String appId, String appName) {
        LinearLayout form = AdminUi.vertical(this);
        form.setPadding(AdminUi.dp(this, 18), AdminUi.dp(this, 8),
                AdminUi.dp(this, 18), AdminUi.dp(this, 4));
        TextView explanation = AdminUi.text(this,
                "O app continuará aparecendo na loja com um cadeado, mas ninguém poderá iniciar um novo download pela SAN STORE.",
                13, AdminUi.MUTED, false);
        explanation.setPadding(0, 0, 0, AdminUi.dp(this, 10));
        form.addView(explanation);
        EditText reasonInput = AdminUi.input(this, "Motivo ou aviso para os usuários (opcional)", true);
        reasonInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
        form.addView(reasonInput);

        new AlertDialog.Builder(this)
                .setTitle("Bloquear “" + appName + "”? ")
                .setView(form)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Bloquear aplicativo", (dialog, which) ->
                        setBlocked(appId, true, reasonInput.getText().toString().trim()))
                .show();
    }

    private void confirmUnblock(String appId, String appName) {
        new AlertDialog.Builder(this)
                .setTitle("Liberar “" + appName + "”? ")
                .setMessage("O botão de download voltará a ficar disponível na SAN STORE.")
                .setNegativeButton("Manter bloqueado", null)
                .setPositiveButton("Liberar downloads", (dialog, which) -> setBlocked(appId, false, ""))
                .show();
    }

    private void setBlocked(String appId, boolean blocked, String reason) {
        if (appId == null || appId.isEmpty()) {
            Toast.makeText(this, "Não foi possível identificar este aplicativo.", Toast.LENGTH_LONG).show();
            return;
        }
        refresh.setEnabled(false);
        String path = "/api/admin/apps/" + appId + (blocked ? "/block" : "/unblock");
        JSONObject body = blocked ? AdminApi.json("reason", reason) : null;
        AdminApi.call(this, "POST", path, body, (code, object, array, error) -> {
            refresh.setEnabled(true);
            if (code != 200) {
                Toast.makeText(this, error != null ? error : AdminApi.message(object,
                        "Não foi possível atualizar o status do aplicativo."), Toast.LENGTH_LONG).show();
                return;
            }
            Toast.makeText(this, blocked ? "Aplicativo bloqueado na SAN STORE." :
                    "Downloads liberados novamente.", Toast.LENGTH_SHORT).show();
            load();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null) load();
    }
}
