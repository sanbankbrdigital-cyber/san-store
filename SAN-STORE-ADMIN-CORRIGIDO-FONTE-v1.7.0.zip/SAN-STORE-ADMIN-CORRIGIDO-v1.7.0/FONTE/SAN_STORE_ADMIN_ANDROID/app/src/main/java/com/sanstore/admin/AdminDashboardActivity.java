package com.sanstore.admin;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdminDashboardActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 7419;
    private static final long POLL_INTERVAL_MS = 45_000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView appealSummary;
    private Button appealsButton;
    private Button notificationToggle;
    private JSONObject queuedAppeal;
    private int queuedAppealCount;
    private boolean enableNotificationsAfterPermission;

    private final Runnable pollAppeals = new Runnable() {
        @Override public void run() {
            loadAppeals(true);
            handler.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AdminApi.call(this, "GET", "/api/admin/me", null, (code, object, array, error) -> {
            if (code != 200) {
                AppealNotifications.cancel(this);
                AdminApi.clear(this);
                startActivity(new Intent(this, AdminLoginActivity.class));
                finish();
                return;
            }
            String account = "Administrador";
            if (object != null && object.optJSONObject("user") != null) {
                account = object.optJSONObject("user").optString("account", "Administrador");
            }
            AppealNotifications.schedule(this);
            show(account);
        });
    }

    private void show(String account) {
        LinearLayout content = AdminUi.screen(this, "Painel SAN STORE", "Administração da loja · " + account, false);
        AdminUi.section(this, content, "Moderação e gestão");
        TextView info = AdminUi.text(this,
                "Revise publicações, apelações de apps bloqueados e pedidos de desenvolvedores.",
                13, AdminUi.MUTED, false);
        content.addView(info);
        AdminUi.gap(this, content, 14);

        appealSummary = AdminUi.text(this, "Verificando apelações…", 13, AdminUi.MUTED, true);
        appealSummary.setPadding(AdminUi.dp(this, 14), AdminUi.dp(this, 13),
                AdminUi.dp(this, 14), AdminUi.dp(this, 13));
        appealSummary.setBackground(AdminUi.shape(AdminUi.CARD, AdminUi.dp(this, 20), 0xff344767));
        content.addView(appealSummary);
        AdminUi.gap(this, content, 8);
        appealsButton = AdminUi.button(this, "Apelações de bloqueios", true);
        content.addView(appealsButton);
        appealsButton.setOnClickListener(view -> startActivity(new Intent(this, AppealsActivity.class)));
        AdminUi.gap(this, content, 8);
        notificationToggle = AdminUi.button(this, "", false);
        updateNotificationToggle();
        content.addView(notificationToggle);
        notificationToggle.setOnClickListener(view -> toggleNotifications());
        AdminUi.gap(this, content, 12);

        Button pending = AdminUi.button(this, "Publicações pendentes", false);
        content.addView(pending);
        AdminUi.gap(this, content, 12);
        Button published = AdminUi.button(this, "Aplicativos na loja · bloquear/liberar", false);
        content.addView(published);
        AdminUi.gap(this, content, 12);
        Button developers = AdminUi.button(this, "Desenvolvedores", false);
        content.addView(developers);
        AdminUi.gap(this, content, 26);
        Button logout = AdminUi.button(this, "Sair da conta", false);
        content.addView(logout);
        pending.setOnClickListener(view -> startActivity(new Intent(this, PendingSubmissionsActivity.class)));
        published.setOnClickListener(view -> startActivity(new Intent(this, PublishedAppsActivity.class)));
        developers.setOnClickListener(view -> startActivity(new Intent(this, DevelopersActivity.class)));
        logout.setOnClickListener(view -> new AlertDialog.Builder(this)
                .setTitle("Encerrar sessão?")
                .setMessage("O token será revogado no servidor e removido deste aparelho.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Sair", (dialog, which) -> {
                    AppealNotifications.cancel(this);
                    AdminApi.logout(this, () -> {
                        startActivity(new Intent(this, AdminLoginActivity.class));
                        finish();
                    });
                }).show());
        loadAppeals(true);
        handler.removeCallbacks(pollAppeals);
        handler.postDelayed(pollAppeals, POLL_INTERVAL_MS);
    }

    private void updateNotificationToggle() {
        if (notificationToggle == null) return;
        boolean enabled = AppealNotifications.isEnabled(this);
        boolean permitted = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (enabled && permitted) {
            notificationToggle.setText("🔔 Notificações nativas de apelações: ativadas");
        } else if (enabled) {
            notificationToggle.setText("🔔 Permitir notificações nativas de apelações");
        } else {
            notificationToggle.setText("🔕 Ativar notificações nativas de apelações");
        }
    }

    private void toggleNotifications() {
        boolean enabled = AppealNotifications.isEnabled(this);
        boolean permitted = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (enabled && permitted) {
            new AlertDialog.Builder(this)
                    .setTitle("Desativar notificações?")
                    .setMessage("Você deixará de receber avisos de novas apelações neste aparelho. O contador do painel continua disponível.")
                    .setNegativeButton("Manter ativadas", null)
                    .setPositiveButton("Desativar", (dialog, which) -> {
                        AppealNotifications.setEnabled(this, false);
                        updateNotificationToggle();
                    }).show();
            return;
        }
        if (!permitted) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setTitle("Notificações de apelação")
                    .setMessage("Permita notificações nativas para receber avisos quando um desenvolvedor pedir desbloqueio.")
                    .setPositiveButton("Permitir", (d, which) -> {
                        enableNotificationsAfterPermission = true;
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
                    });
            if (enabled) {
                dialog.setNeutralButton("Desativar", (d, which) -> {
                    AppealNotifications.setEnabled(this, false);
                    updateNotificationToggle();
                });
            } else {
                dialog.setNegativeButton("Agora não", null);
            }
            dialog.show();
            return;
        }
        AppealNotifications.setEnabled(this, true);
        updateNotificationToggle();
        loadAppeals(true);
    }

    private void loadAppeals(boolean notifyNew) {
        if (appealSummary == null || isFinishing()) return;
        AdminApi.call(this, "GET", "/api/admin/appeals?status=pending", null, (code, object, array, error) -> {
            if (isFinishing() || appealSummary == null) return;
            if (code != 200 || array == null) {
                appealSummary.setText("Não foi possível consultar as apelações. Toque para tentar novamente.");
                appealSummary.setOnClickListener(view -> loadAppeals(false));
                return;
            }
            appealSummary.setOnClickListener(null);
            int count = array.length();
            appealSummary.setText(count == 0 ? "✓  Nenhuma apelação pendente" :
                    "●  " + count + (count == 1 ? " apelação aguardando análise" : " apelações aguardando análise"));
            appealSummary.setTextColor(count == 0 ? AdminUi.GREEN : AdminUi.GOLD);
            appealsButton.setText(count == 0 ? "Apelações de bloqueios" : "Revisar apelações · " + count + " pendente(s)");
            if (!notifyNew || count == 0 || !AppealNotifications.isEnabled(this)) return;
            JSONObject latest = array.optJSONObject(0);
            if (latest == null) return;
            String appealId = latest.optString("id", "");
            if (appealId.isEmpty() || !AppealNotifications.isNew(this, appealId)) return;
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                queuedAppeal = latest;
                queuedAppealCount = count;
                if (!AppealNotifications.wasPermissionRequestedFor(this, appealId)) {
                    AppealNotifications.notePermissionRequest(this, appealId);
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
                }
                return;
            }
            postAppealNotification(latest, count);
        });
    }

    private void postAppealNotification(JSONObject appeal, int count) {
        String appealId = appeal.optString("id", "");
        if (AppealNotifications.markNew(this, appealId)) {
            AppealNotifications.show(this, appeal.optString("appName", "Aplicativo"),
                    appeal.optString("developerName", appeal.optString("developerAccount", "Desenvolvedor")), count);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_NOTIFICATIONS) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted) {
            if (enableNotificationsAfterPermission) AppealNotifications.setEnabled(this, true);
            updateNotificationToggle();
            if (queuedAppeal != null) postAppealNotification(queuedAppeal, queuedAppealCount);
            else loadAppeals(true);
        } else {
            if (enableNotificationsAfterPermission) AppealNotifications.setEnabled(this, false);
            updateNotificationToggle();
        }
        queuedAppeal = null;
        enableNotificationsAfterPermission = false;
    }

    @Override protected void onResume() {
        super.onResume();
        if (appealSummary != null) {
            handler.removeCallbacks(pollAppeals);
            loadAppeals(true);
            handler.postDelayed(pollAppeals, POLL_INTERVAL_MS);
        }
    }

    @Override protected void onPause() {
        handler.removeCallbacks(pollAppeals);
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(pollAppeals);
        super.onDestroy();
    }
}
