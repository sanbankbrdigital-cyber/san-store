package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class SubmissionReviewActivity extends Activity {
    private String id;
    private boolean isUpdate;
    private EditText name, category, image, apk, description, whatsNew;
    private TextView status, screenshotStatus;
    private Button save, approve, reject;
    private LinearLayout screenshotRow;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        id = getIntent().getStringExtra("id");
        if (id == null || id.isEmpty()) { finish(); return; }
        LinearLayout page = AdminUi.screen(this, "Revisar envio", "Confira as capturas antes de aprovar", true);
        status = AdminUi.text(this, "Carregando…", 12, AdminUi.MUTED, false);
        page.addView(status);
        name = field(page, "Nome do app/jogo", false);
        category = field(page, "Categoria: App ou Game", false);
        image = field(page, "URL HTTPS do ícone", false);
        apk = field(page, "URL HTTPS do APK", false);
        description = field(page, "Descrição", true);
        whatsNew = field(page, "Novidades desta versão", true);

        AdminUi.section(this, page, "Capturas de tela enviadas");
        screenshotStatus = AdminUi.text(this, "Carregando capturas…", 12, AdminUi.MUTED, false);
        page.addView(screenshotStatus);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        screenshotRow = AdminUi.horizontal(this);
        screenshotRow.setPadding(AdminUi.dp(this, 2), AdminUi.dp(this, 8), AdminUi.dp(this, 10), AdminUi.dp(this, 10));
        scroll.addView(screenshotRow, new HorizontalScrollView.LayoutParams(-2, -2));
        page.addView(scroll);

        AdminUi.gap(this, page, 12);
        save = AdminUi.button(this, "Salvar alterações", false); page.addView(save);
        AdminUi.gap(this, page, 10);
        approve = AdminUi.button(this, "Aprovar e publicar", true); page.addView(approve);
        AdminUi.gap(this, page, 10);
        reject = AdminUi.button(this, "Recusar publicação", false); page.addView(reject);
        save.setOnClickListener(view -> save());
        approve.setOnClickListener(view -> confirmApprove());
        reject.setOnClickListener(view -> askReject());
        setEnabled(false);
        load();
    }

    private EditText field(LinearLayout page, String label, boolean multiline) {
        AdminUi.label(this, page, label);
        EditText input = AdminUi.input(this, label, multiline);
        page.addView(input);
        return input;
    }

    private void setEnabled(boolean enabled) {
        if (name == null) return;
        name.setEnabled(enabled); category.setEnabled(enabled); image.setEnabled(enabled); apk.setEnabled(enabled);
        description.setEnabled(enabled); whatsNew.setEnabled(enabled);
        save.setEnabled(enabled); approve.setEnabled(enabled); reject.setEnabled(enabled);
    }

    private void load() {
        AdminApi.call(this, "GET", "/api/admin/submissions/" + id, null, (code, object, array, error) -> {
            if (code != 200 || object == null) {
                status.setText(error != null ? error : AdminApi.message(object, "Não foi possível abrir o envio."));
                return;
            }
            name.setText(object.optString("name"));
            category.setText(object.optString("category"));
            image.setText(object.optString("image"));
            apk.setText(object.optString("apk"));
            description.setText(object.optString("description"));
            whatsNew.setText(object.optString("whatsNew", ""));
            isUpdate = "update".equals(object.optString("submissionType", "new"));
            String submissionStatus = object.optString("status", "pending");
            status.setText((isUpdate ? "ATUALIZAÇÃO DO APP PUBLICADO" : "NOVA PUBLICAÇÃO") +
                    " · Status: " + submissionStatus + " · enviado por: " +
                    object.optString("developerName", object.optString("developerAccount", "Publicador não informado")));
            setEnabled("pending".equals(submissionStatus));
            loadScreenshots(object.optJSONArray("screenshots"));
            if (!"pending".equals(submissionStatus)) {
                save.setVisibility(View.GONE); approve.setVisibility(View.GONE); reject.setVisibility(View.GONE);
            }
        });
    }

    private void loadScreenshots(JSONArray screenshots) {
        screenshotRow.removeAllViews();
        if (screenshots == null || screenshots.length() == 0) {
            screenshotStatus.setText(isUpdate
                    ? "Esta atualização não substitui a galeria existente; as capturas atuais serão mantidas."
                    : "Este envio não possui capturas de tela.");
            return;
        }
        ArrayList<String> encoded = new ArrayList<>();
        for (int i = 0; i < screenshots.length(); i++) {
            String value = screenshots.optString(i, "");
            if (!value.isEmpty()) encoded.add(value);
        }
        screenshotStatus.setText(encoded.size() + " imagem(ns) PNG recebida(s); deslize para conferir.");
        new Thread(() -> {
            ArrayList<Bitmap> bitmaps = new ArrayList<>();
            for (String value : encoded) {
                Bitmap bitmap = AdminScreenshotDisplay.decode(value, 1200);
                if (bitmap != null) bitmaps.add(bitmap);
            }
            main.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                for (int i = 0; i < bitmaps.size(); i++) addScreenshot(bitmaps.get(i), i + 1);
                if (bitmaps.isEmpty()) screenshotStatus.setText("Não foi possível decodificar as capturas deste envio.");
            });
        }, "san-store-admin-screenshots").start();
    }

    private void addScreenshot(Bitmap bitmap, int number) {
        LinearLayout card = AdminUi.vertical(this);
        card.setPadding(AdminUi.dp(this, 5), AdminUi.dp(this, 5), AdminUi.dp(this, 5), AdminUi.dp(this, 5));
        card.setBackground(AdminUi.shape(AdminUi.CARD, AdminUi.dp(this, 18), 0));
        ImageView preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(AdminUi.shape(0xff111927, AdminUi.dp(this, 14), 0));
        preview.setClipToOutline(true);
        preview.setImageBitmap(bitmap);
        card.addView(preview, new LinearLayout.LayoutParams(AdminUi.dp(this, 180), AdminUi.dp(this, 300)));
        TextView label = AdminUi.text(this, "Captura " + number, 11, AdminUi.MUTED, false);
        label.setGravity(Gravity.CENTER);
        label.setPadding(0, AdminUi.dp(this, 4), 0, 0);
        card.addView(label);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.rightMargin = AdminUi.dp(this, 9);
        screenshotRow.addView(card, params);
        card.setOnClickListener(view -> {
            ImageView full = new ImageView(this);
            full.setAdjustViewBounds(true); full.setScaleType(ImageView.ScaleType.FIT_CENTER); full.setImageBitmap(bitmap);
            new AlertDialog.Builder(this).setTitle("Captura " + number).setView(full).setPositiveButton("Fechar", null).show();
        });
    }

    private JSONObject fields() {
        return AdminApi.json("name", name.getText().toString(), "category", category.getText().toString(),
                "image", image.getText().toString(), "apk", apk.getText().toString(),
                "description", description.getText().toString(), "whatsNew", whatsNew.getText().toString());
    }

    private void save() {
        save.setEnabled(false);
        AdminApi.call(this, "PUT", "/api/admin/submissions/" + id, fields(), (code, object, array, error) -> {
            save.setEnabled(true);
            if (code == 200) { Toast.makeText(this, "Alterações salvas.", Toast.LENGTH_SHORT).show(); load(); }
            else status.setText(error != null ? error : AdminApi.message(object, "Falha ao salvar (HTTP " + code + ")."));
        });
    }

    private void confirmApprove() {
        new AlertDialog.Builder(this)
                .setTitle(isUpdate ? "Aprovar atualização?" : "Aprovar e publicar?")
                .setMessage(isUpdate
                        ? "Os dados e as capturas aprovadas substituirão a versão atual; identificador e avaliações serão preservados."
                        : "Este app e as capturas ficarão visíveis no catálogo público após a aprovação.")
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Aprovar", (dialog, which) -> {
                    approve.setEnabled(false);
                    AdminApi.call(this, "POST", "/api/admin/submissions/" + id + "/approve", new JSONObject(), (code, object, array, error) -> {
                        approve.setEnabled(true);
                        if (code == 200) {
                            Toast.makeText(this, isUpdate ? "Atualização e capturas aprovadas." : "Publicação aprovada.", Toast.LENGTH_LONG).show();
                            finish();
                        } else status.setText(error != null ? error : AdminApi.message(object, "Falha ao aprovar (HTTP " + code + ")."));
                    });
                }).show();
    }

    private void askReject() {
        EditText reason = new EditText(this);
        reason.setHint("Motivo opcional");
        reason.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this)
                .setTitle(isUpdate ? "Recusar atualização" : "Recusar envio")
                .setMessage(isUpdate
                        ? "A versão atual e suas capturas continuarão publicadas."
                        : "A publicação ficará recusada e não aparecerá no catálogo.")
                .setView(reason).setNegativeButton("Cancelar", null)
                .setPositiveButton("Recusar", (dialog, which) -> {
                    reject.setEnabled(false);
                    AdminApi.call(this, "POST", "/api/admin/submissions/" + id + "/reject",
                            AdminApi.json("reason", reason.getText().toString()), (code, object, array, error) -> {
                                reject.setEnabled(true);
                                if (code == 200) {
                                    Toast.makeText(this, isUpdate ? "Atualização recusada; app publicado preservado." : "Envio recusado.", Toast.LENGTH_LONG).show();
                                    finish();
                                } else status.setText(error != null ? error : AdminApi.message(object, "Falha ao recusar (HTTP " + code + ")."));
                            });
                }).show();
    }
}
