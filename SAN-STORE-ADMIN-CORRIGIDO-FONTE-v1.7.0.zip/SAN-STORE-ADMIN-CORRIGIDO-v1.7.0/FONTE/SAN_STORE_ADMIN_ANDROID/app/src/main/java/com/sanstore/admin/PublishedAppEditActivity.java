package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class PublishedAppEditActivity extends Activity {
    private static final int REQUEST_SCREENSHOTS = 6501;
    private static final String[] TYPES = {"App", "Game"};
    private static final String[] CATEGORIES = {
            "Educação", "Finanças", "Ferramentas", "Redes sociais",
            "Entretenimento", "Saúde", "Produtividade"
    };

    private String appId;
    private EditText name, imageUrl, apkUrl, description, whatsNew;
    private Spinner type, subcategory;
    private TextView status, screenshotStatus;
    private Button save, selectScreenshots;
    private LinearLayout screenshotRow;
    private ArrayList<String> newScreenshots = new ArrayList<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        appId = getIntent().getStringExtra("appId");
        if (appId == null || appId.trim().isEmpty()) { finish(); return; }
        render();
        load();
    }

    private void render() {
        LinearLayout page = AdminUi.screen(this, "Editar app publicado", "Alterações são aplicadas diretamente na loja", true);
        status = AdminUi.text(this, "Carregando dados…", 12, AdminUi.MUTED, false);
        status.setPadding(0, 0, 0, AdminUi.dp(this, 4));
        page.addView(status);

        LinearLayout notice = AdminUi.card(this);
        TextView message = AdminUi.text(this,
                "O identificador público e as avaliações serão preservados. Os dados salvos aparecem na SAN STORE sem nova aprovação.",
                13, AdminUi.MUTED, false);
        notice.addView(message);
        LinearLayout.LayoutParams noticeParams = new LinearLayout.LayoutParams(-1, -2);
        noticeParams.topMargin = AdminUi.dp(this, 8);
        page.addView(notice, noticeParams);

        AdminUi.section(this, page, "Informações do aplicativo ou jogo");
        name = field(page, "Nome (2 a 60 caracteres)", false);

        AdminUi.label(this, page, "Tipo");
        type = spinner(TYPES);
        page.addView(type, new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 52)));

        AdminUi.label(this, page, "Categoria");
        subcategory = spinner(CATEGORIES);
        page.addView(subcategory, new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 52)));

        imageUrl = field(page, "URL HTTPS do ícone", false);
        apkUrl = field(page, "URL HTTPS do APK", false);
        description = field(page, "Descrição (5 a 350 caracteres)", true);
        whatsNew = field(page, "Novidades desta versão (até 500 caracteres)", true);

        AdminUi.section(this, page, "Capturas de tela atuais");
        screenshotStatus = AdminUi.text(this, "Carregando capturas…", 12, AdminUi.MUTED, false);
        page.addView(screenshotStatus);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        screenshotRow = AdminUi.horizontal(this);
        screenshotRow.setPadding(AdminUi.dp(this, 2), AdminUi.dp(this, 8), AdminUi.dp(this, 10), AdminUi.dp(this, 8));
        scroll.addView(screenshotRow, new HorizontalScrollView.LayoutParams(-2, -2));
        page.addView(scroll);

        AdminUi.section(this, page, "Substituir a galeria (opcional)");
        TextView helper = AdminUi.text(this,
                "Sem selecionar novas capturas, a galeria atual será mantida. Para substituir, escolha de 2 a 8 imagens; elas serão convertidas para PNG e Base64.",
                12, AdminUi.MUTED, false);
        page.addView(helper);
        selectScreenshots = AdminUi.button(this, "Selecionar novas capturas (2 a 8)", false);
        LinearLayout.LayoutParams selectParams = new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50));
        selectParams.topMargin = AdminUi.dp(this, 8);
        page.addView(selectScreenshots, selectParams);
        selectScreenshots.setOnClickListener(view -> AdminScreenshotPicker.open(this, REQUEST_SCREENSHOTS));
        save = AdminUi.button(this, "Salvar alterações na loja", true);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, AdminUi.dp(this, 54));
        saveParams.topMargin = AdminUi.dp(this, 18);
        page.addView(save, saveParams);
        save.setOnClickListener(view -> saveChanges());
    }

    private EditText field(LinearLayout page, String label, boolean multiline) {
        AdminUi.label(this, page, label);
        EditText input = AdminUi.input(this, label, multiline);
        if (label.startsWith("Nome")) input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});
        page.addView(input);
        return input;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values) {
            @Override public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView row = (TextView) super.getView(position, convertView, parent);
                row.setTextColor(AdminUi.TEXT);
                return row;
            }
            @Override public android.view.View getDropDownView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView row = (TextView) super.getDropDownView(position, convertView, parent);
                row.setTextColor(AdminUi.TEXT);
                row.setBackgroundColor(AdminUi.ALT);
                row.setPadding(AdminUi.dp(PublishedAppEditActivity.this, 14), AdminUi.dp(PublishedAppEditActivity.this, 12),
                        AdminUi.dp(PublishedAppEditActivity.this, 14), AdminUi.dp(PublishedAppEditActivity.this, 12));
                return row;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(AdminUi.shape(AdminUi.ALT, AdminUi.dp(this, 16), 0));
        spinner.setPadding(AdminUi.dp(this, 12), 0, AdminUi.dp(this, 12), 0);
        return spinner;
    }

    private void load() {
        AdminApi.call(this, "GET", "/api/admin/apps/" + appId, null, (code, object, array, error) -> {
            if (code != 200 || object == null) {
                status.setText(error != null ? error : AdminApi.message(object, "Não foi possível carregar o aplicativo."));
                save.setEnabled(false);
                return;
            }
            name.setText(object.optString("name", ""));
            imageUrl.setText(object.optString("image", ""));
            apkUrl.setText(object.optString("apk", ""));
            description.setText(object.optString("description", ""));
            whatsNew.setText(object.optString("whatsNew", ""));
            type.setSelection("Game".equals(object.optString("category", "App")) ? 1 : 0);
            String category = object.optString("subcategory", "");
            for (int i = 0; i < CATEGORIES.length; i++) {
                if (CATEGORIES[i].equals(category)) { subcategory.setSelection(i); break; }
            }
            String blocked = object.optBoolean("blocked", false) ? " · bloqueado" : " · disponível";
            status.setText("Publicado por " + object.optString("developerName", "Publicador") + blocked);
            showCurrentScreenshots(object.optJSONArray("screenshots"));
        });
    }

    private void showCurrentScreenshots(JSONArray screenshots) {
        screenshotRow.removeAllViews();
        ArrayList<String> encoded = new ArrayList<>();
        if (screenshots != null) {
            for (int i = 0; i < screenshots.length(); i++) {
                String value = screenshots.optString(i, "");
                if (!value.isEmpty()) encoded.add(value);
            }
        }
        if (encoded.isEmpty()) {
            screenshotStatus.setText("Este aplicativo ainda não possui capturas publicadas.");
            return;
        }
        screenshotStatus.setText(encoded.size() + " captura(s) publicadas. Deslize para visualizar.");
        new Thread(() -> {
            ArrayList<Bitmap> bitmaps = new ArrayList<>();
            for (String value : encoded) {
                Bitmap bitmap = AdminScreenshotDisplay.decode(value, 1200);
                if (bitmap != null) bitmaps.add(bitmap);
            }
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                for (int i = 0; i < bitmaps.size(); i++) addScreenshotPreview(bitmaps.get(i), i + 1);
            });
        }, "san-store-edit-screenshots").start();
    }

    private void addScreenshotPreview(Bitmap bitmap, int number) {
        LinearLayout card = AdminUi.vertical(this);
        card.setPadding(AdminUi.dp(this, 4), AdminUi.dp(this, 4), AdminUi.dp(this, 4), AdminUi.dp(this, 4));
        card.setBackground(AdminUi.shape(AdminUi.CARD, AdminUi.dp(this, 16), 0));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackground(AdminUi.shape(0xff111927, AdminUi.dp(this, 12), 0));
        image.setClipToOutline(true);
        image.setImageBitmap(bitmap);
        card.addView(image, new LinearLayout.LayoutParams(AdminUi.dp(this, 150), AdminUi.dp(this, 255)));
        TextView caption = AdminUi.text(this, "Captura " + number, 10, AdminUi.MUTED, false);
        caption.setGravity(Gravity.CENTER);
        card.addView(caption);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.rightMargin = AdminUi.dp(this, 8);
        screenshotRow.addView(card, params);
        card.setOnClickListener(view -> {
            ImageView full = new ImageView(this);
            full.setAdjustViewBounds(true); full.setScaleType(ImageView.ScaleType.FIT_CENTER); full.setImageBitmap(bitmap);
            new AlertDialog.Builder(this).setTitle("Captura " + number).setView(full).setPositiveButton("Fechar", null).show();
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        AdminScreenshotPicker.handleResult(this, requestCode, REQUEST_SCREENSHOTS, resultCode, data, (images, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                return;
            }
            newScreenshots = images;
            screenshotStatus.setText("Galeria nova pronta: " + images.size() + " capturas; será aplicada ao salvar.");
            screenshotStatus.setTextColor(AdminUi.GREEN);
        });
    }

    private void saveChanges() {
        String title = name.getText().toString().trim();
        String image = imageUrl.getText().toString().trim();
        String apk = apkUrl.getText().toString().trim();
        String descriptionText = description.getText().toString().trim();
        String whatsNewText = whatsNew.getText().toString().trim();
        if (title.length() < 2 || title.length() > 60 || !image.startsWith("https://") || !apk.startsWith("https://") ||
                descriptionText.length() < 5 || descriptionText.length() > 350 || whatsNewText.length() > 500) {
            status.setText("Confira nome, links HTTPS, descrição (5 a 350 caracteres) e novidades (até 500).");
            status.setTextColor(AdminUi.GOLD);
            return;
        }
        JSONObject body = AdminApi.json("name", title,
                "category", String.valueOf(type.getSelectedItem()),
                "subcategory", String.valueOf(subcategory.getSelectedItem()),
                "image", image, "apk", apk,
                "description", descriptionText, "whatsNew", whatsNewText);
        if (newScreenshots != null && !newScreenshots.isEmpty()) {
            JSONArray array = new JSONArray();
            for (String screenshot : newScreenshots) array.put(screenshot);
            try { body.put("screenshots", array); } catch (Exception ignored) { }
        }
        save.setEnabled(false);
        save.setText("Salvando…");
        AdminApi.call(this, "PUT", "/api/admin/apps/" + appId, body, (code, object, array, error) -> {
            if (isFinishing()) return;
            save.setEnabled(true);
            save.setText("Salvar alterações na loja");
            if (code != 200) {
                status.setText(error != null ? error : AdminApi.message(object, "Não foi possível salvar (HTTP " + code + ")."));
                status.setTextColor(AdminUi.GOLD);
                return;
            }
            Toast.makeText(this, "Alterações aplicadas na SAN STORE.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
