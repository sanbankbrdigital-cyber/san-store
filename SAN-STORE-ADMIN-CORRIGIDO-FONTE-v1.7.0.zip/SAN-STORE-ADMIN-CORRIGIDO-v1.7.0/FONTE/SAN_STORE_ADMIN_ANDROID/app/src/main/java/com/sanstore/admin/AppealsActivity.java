package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class AppealsActivity extends Activity {
    private LinearLayout content;
    private LinearLayout cards;
    private TextView state;
    private Button refresh;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        content = AdminUi.screen(this, "Apelações", "Revisão de apps bloqueados", true);
        refresh = AdminUi.button(this, "Atualizar apelações", false);
        content.addView(refresh);
        state = AdminUi.text(this, "Carregando…", 13, AdminUi.MUTED, false);
        state.setPadding(0, AdminUi.dp(this, 12), 0, AdminUi.dp(this, 10));
        content.addView(state);
        cards = AdminUi.vertical(this);
        content.addView(cards);
        refresh.setOnClickListener(view -> load());
        load();
    }

    private void load() {
        AdminApi.call(this, "GET", "/api/admin/appeals?status=pending", null, (code, object, array, error) -> {
            if (code != 200 || array == null) {
                state.setText(error != null ? error : AdminApi.message(object, "Não foi possível carregar as apelações."));
                return;
            }
            cards.removeAllViews();
            state.setText(array.length() == 0 ? "Nenhuma apelação pendente." :
                    array.length() + " apelação(ões) aguardando decisão");
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item != null) addAppealCard(item);
            }
        });
    }

    private void addAppealCard(JSONObject item) {
        String appealId = item.optString("id", "");
        String appName = item.optString("appName", "Aplicativo");
        String developer = item.optString("developerName", "Desenvolvedor") +
                " · @" + item.optString("developerAccount", "");
        String message = item.optString("message", "Sem justificativa informada.");

        LinearLayout card = AdminUi.card(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = AdminUi.dp(this, 13);
        cards.addView(card, cardParams);
        card.addView(AdminUi.badge(this, "PEDIDO DE DESBLOQUEIO", 0xff3a3022, AdminUi.GOLD));
        TextView title = AdminUi.text(this, appName, 18, AdminUi.TEXT, true);
        title.setPadding(0, AdminUi.dp(this, 10), 0, AdminUi.dp(this, 3));
        card.addView(title);
        card.addView(AdminUi.text(this, developer, 12, AdminUi.MUTED, false));

        TextView appealText = AdminUi.text(this, "Mensagem do desenvolvedor: “" + message + "”", 13, AdminUi.TEXT, false);
        appealText.setLineSpacing(AdminUi.dp(this, 2), 1f);
        appealText.setPadding(0, AdminUi.dp(this, 10), 0, AdminUi.dp(this, 12));
        card.addView(appealText);

        LinearLayout actions = AdminUi.horizontal(this);
        Button approve = AdminUi.button(this, "Aprovar · desbloquear", true);
        Button reject = AdminUi.button(this, "Recusar · remover", false);
        actions.addView(approve, new LinearLayout.LayoutParams(0, AdminUi.dp(this, 50), 1));
        LinearLayout.LayoutParams rejectParams = new LinearLayout.LayoutParams(0, AdminUi.dp(this, 50), 1);
        rejectParams.leftMargin = AdminUi.dp(this, 8);
        actions.addView(reject, rejectParams);
        card.addView(actions);
        approve.setOnClickListener(view -> confirmDecision(appealId, appName, true));
        reject.setOnClickListener(view -> confirmDecision(appealId, appName, false));
    }

    private void confirmDecision(String appealId, String appName, boolean approve) {
        if (approve) {
            new AlertDialog.Builder(this)
                    .setTitle("Aprovar apelação?")
                    .setMessage("O app “" + appName + "” será desbloqueado e voltará a permitir downloads na SAN STORE.")
                    .setNegativeButton("Voltar", null)
                    .setPositiveButton("Aprovar e desbloquear", (dialog, which) -> decide(appealId, true, ""))
                    .show();
            return;
        }
        LinearLayout form = AdminUi.vertical(this);
        form.setPadding(AdminUi.dp(this, 18), AdminUi.dp(this, 6),
                AdminUi.dp(this, 18), AdminUi.dp(this, 3));
        TextView warning = AdminUi.text(this,
                "A apelação será recusada e o app será removido do catálogo da SAN STORE. O registro fica preservado no histórico administrativo.",
                13, AdminUi.MUTED, false);
        form.addView(warning);
        EditText note = AdminUi.input(this, "Motivo da recusa (opcional)", true);
        note.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
        form.addView(note);
        new AlertDialog.Builder(this)
                .setTitle("Recusar e remover “" + appName + "”?")
                .setView(form)
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Recusar apelação", (dialog, which) -> decide(appealId, false, note.getText().toString().trim()))
                .show();
    }

    private void decide(String appealId, boolean approve, String reason) {
        if (appealId == null || appealId.isEmpty()) {
            Toast.makeText(this, "Não foi possível identificar esta apelação.", Toast.LENGTH_LONG).show();
            return;
        }
        refresh.setEnabled(false);
        String path = "/api/admin/appeals/" + Uri.encode(appealId) + (approve ? "/approve" : "/reject");
        JSONObject body = reason == null || reason.isEmpty() ? null : AdminApi.json("reviewReason", reason);
        AdminApi.call(this, "POST", path, body, (code, object, array, error) -> {
            refresh.setEnabled(true);
            if (code != 200) {
                Toast.makeText(this, error != null ? error : AdminApi.message(object,
                        "Não foi possível registrar a decisão."), Toast.LENGTH_LONG).show();
                return;
            }
            Toast.makeText(this, approve ? "Apelação aprovada; app desbloqueado." :
                    "Apelação recusada; app removido do catálogo.", Toast.LENGTH_LONG).show();
            load();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (cards != null) load();
    }
}
