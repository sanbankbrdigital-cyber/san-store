package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DeveloperActivity extends Activity {
    private LinearLayout content;
    private LinearLayout actions;
    private TextView accessStatus;
    private TextView publisherStatus;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
        refreshAccess();
    }

    private void render() {
        content = StoreUi.screen(this, "Desenvolvedor", "Publicações analisadas pelo administrador", true);

        LinearLayout hero = StoreUi.vertical(this);
        hero.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18));
        hero.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 24), 0xff354767));
        hero.setElevation(StoreUi.dp(this, 6));
        hero.addView(StoreUi.badge(this, "ÁREA DO DESENVOLVEDOR", 0xff2b3d61, 0xffd7e2ff));
        TextView info = StoreUi.text(this,
                "Peça acesso para publicar. Cada aplicativo ou jogo só entra no catálogo depois da aprovação do administrador.",
                14, StoreUi.TEXT, false);
        info.setLineSpacing(StoreUi.dp(this, 3), 1f);
        info.setPadding(0, StoreUi.dp(this, 12), 0, 0);
        hero.addView(info);
        content.addView(hero);

        StoreUi.section(this, content, "Status de desenvolvedor");
        accessStatus = StoreUi.text(this, "Verificando acesso…", 13, StoreUi.MUTED, false);
        accessStatus.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 13), StoreUi.dp(this, 14), StoreUi.dp(this, 13));
        accessStatus.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 17), 0xff2b3a53));
        accessStatus.setElevation(StoreUi.dp(this, 4));
        content.addView(accessStatus);

        StoreUi.section(this, content, "Publicador exibido na loja");
        publisherStatus = StoreUi.text(this, "Carregando nome público…", 13, StoreUi.MUTED, false);
        publisherStatus.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 13), StoreUi.dp(this, 14), StoreUi.dp(this, 13));
        publisherStatus.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 17), 0xff2b3a53));
        publisherStatus.setElevation(StoreUi.dp(this, 4));
        content.addView(publisherStatus);

        actions = StoreUi.vertical(this);
        StoreUi.gap(this, content, 10);
        content.addView(actions);

        Button settings = StoreUi.button(this, "⚙  Configurar conexão da API", false);
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52));
        settingsParams.topMargin = StoreUi.dp(this, 16);
        content.addView(settings, settingsParams);
    }

    private void refreshAccess() {
        ApiClient.getDeveloperAccess(this, (access, error) -> {
            if (isFinishing()) return;
            actions.removeAllViews();
            if (error != null) {
                publisherStatus.setText("Não foi possível consultar o publicador desta conta.");
                accessStatus.setText("Não foi possível consultar o acesso. Tente novamente.");
                accessStatus.setTextColor(StoreUi.GOLD);
                Button retry = StoreUi.button(this, "Tentar novamente", false);
                retry.setOnClickListener(v -> refreshAccess());
                actions.addView(retry, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));
                return;
            }
            String publisher = access.developerName == null || access.developerName.trim().isEmpty()
                    ? access.developerAccount : access.developerName;
            publisherStatus.setText(publisher == null || publisher.trim().isEmpty()
                    ? "O administrador ainda não definiu o nome público desta conta."
                    : "Os aplicativos desta conta aparecem como: " + publisher.trim());
            switch (access.status) {
                case "active":
                    accessStatus.setText("✓  Acesso aprovado. Você pode enviar publicações para análise.");
                    accessStatus.setTextColor(StoreUi.GREEN);
                    Button add = StoreUi.button(this, "＋  Enviar aplicativo ou jogo", true);
                    add.setOnClickListener(v -> startActivity(new Intent(this, PublishAppActivity.class)));
                    actions.addView(add, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
                    break;
                case "pending":
                    accessStatus.setText("◷  Solicitação em análise. O administrador vai liberar o acesso.");
                    accessStatus.setTextColor(StoreUi.GOLD);
                    break;
                case "suspended":
                    accessStatus.setText("Acesso de desenvolvedor suspenso. Fale com o administrador da loja.");
                    accessStatus.setTextColor(StoreUi.GOLD);
                    break;
                default:
                    accessStatus.setText("Ainda não há acesso de desenvolvedor nesta conta.");
                    accessStatus.setTextColor(StoreUi.MUTED);
                    Button request = StoreUi.button(this, "Solicitar acesso de desenvolvedor", true);
                    request.setOnClickListener(v -> requestAccess(request));
                    actions.addView(request, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
                    break;
            }
        });
    }

    private void requestAccess(Button button) {
        button.setEnabled(false);
        button.setText("Enviando solicitação…");
        ApiClient.requestDeveloperAccess(this, (access, error) -> {
            if (isFinishing()) return;
            if (error != null) {
                button.setEnabled(true);
                button.setText("Tentar solicitar novamente");
                accessStatus.setText(error.getMessage());
                accessStatus.setTextColor(StoreUi.GOLD);
            } else {
                refreshAccess();
            }
        });
    }
}
