package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class RegisterActivity extends Activity {
    private EditText account;
    private EditText emailLocal;
    private EditText password;
    private EditText confirmPassword;
    private TextView status;
    private Button createButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Criar conta", "Leva só um momento", true);

        LinearLayout intro = StoreUi.vertical(this);
        intro.setPadding(StoreUi.dp(this, 17), StoreUi.dp(this, 17), StoreUi.dp(this, 17), StoreUi.dp(this, 17));
        intro.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 22), 0xff354767));
        intro.addView(StoreUi.badge(this, "BEM-VINDO À SAN STORE", 0xff2b3d61, 0xffd7e2ff));
        TextView note = StoreUi.text(this, "Crie sua conta para entrar e explorar a loja.", 14, StoreUi.TEXT, true);
        note.setPadding(0, StoreUi.dp(this, 10), 0, 0);
        intro.addView(note);
        content.addView(intro);

        StoreUi.label(this, "Nome da conta");
        account = StoreUi.input(this, "ex.: meuusuario", false);
        account.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        account.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        content.addView(account);

        StoreUi.label(this, "E-mail da conta");
        LinearLayout emailRow = StoreUi.horizontal(this);
        emailLocal = StoreUi.input(this, "nome de e-mail", false);
        emailLocal.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        emailLocal.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
        LinearLayout.LayoutParams localParams = new LinearLayout.LayoutParams(0, -2, 1);
        emailRow.addView(emailLocal, localParams);
        TextView domain = StoreUi.text(this, "@sanstore.com", 13, StoreUi.BLUE, true);
        domain.setGravity(Gravity.CENTER);
        domain.setPadding(StoreUi.dp(this, 10), StoreUi.dp(this, 13), StoreUi.dp(this, 4), StoreUi.dp(this, 13));
        emailRow.addView(domain, new LinearLayout.LayoutParams(-2, -2));
        content.addView(emailRow);
        TextView emailHint = StoreUi.text(this, "O endereço da conta termina sempre em @sanstore.com.", 11, StoreUi.MUTED, false);
        emailHint.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 3), 0, 0);
        content.addView(emailHint);

        StoreUi.label(this, "Senha (8 a 10 caracteres)");
        password = passwordInput("Crie uma senha forte");
        content.addView(password);
        StoreUi.label(this, "Confirmar senha");
        confirmPassword = passwordInput("Digite a senha novamente");
        content.addView(confirmPassword);
        TextView rules = StoreUi.text(this, "Use pelo menos uma maiúscula, uma minúscula, um número e um símbolo.", 11, StoreUi.MUTED, false);
        rules.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 2), 0, 0);
        content.addView(rules);

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 10), 0, StoreUi.dp(this, 5));
        content.addView(status);

        createButton = StoreUi.button(this, "Criar conta e entrar", true);
        createButton.setOnClickListener(v -> createAccount());
        LinearLayout.LayoutParams createParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54));
        createParams.topMargin = StoreUi.dp(this, 7);
        content.addView(createButton, createParams);

        TextView privacy = StoreUi.text(this, "A senha é protegida no servidor e não fica salva neste aparelho.", 11, StoreUi.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setPadding(0, StoreUi.dp(this, 13), 0, 0);
        content.addView(privacy);
    }

    private EditText passwordInput(String hint) {
        EditText input = StoreUi.input(this, hint, false);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        return input;
    }

    private void createAccount() {
        String accountValue = account.getText().toString().trim().toLowerCase(Locale.ROOT);
        String local = emailLocal.getText().toString().trim().toLowerCase(Locale.ROOT);
        String email = local + "@sanstore.com";
        String pass = password.getText().toString();
        String confirm = confirmPassword.getText().toString();

        if (!accountValue.matches("[a-z0-9][a-z0-9._-]{2,19}")) {
            showError("A conta deve ter 3 a 20 caracteres: letras sem acento, números, ponto, hífen ou sublinhado.");
            return;
        }
        if (!local.matches("[a-z0-9][a-z0-9._+-]{0,63}")) {
            showError("Digite um nome válido antes de @sanstore.com.");
            return;
        }
        if (!passwordValid(pass)) {
            showError("A senha precisa ter 8 a 10 caracteres, com maiúscula, minúscula, número e símbolo.");
            return;
        }
        if (!pass.equals(confirm)) {
            showError("As senhas não conferem.");
            return;
        }

        createButton.setEnabled(false);
        createButton.setText("Criando conta…");
        status.setText("Enviando cadastro com segurança…");
        status.setTextColor(StoreUi.MUTED);
        ApiClient.register(this, accountValue, email, pass, (session, error) -> {
            if (isFinishing()) return;
            createButton.setEnabled(true);
            createButton.setText("Criar conta e entrar");
            if (error != null) { showError(error.getMessage()); return; }
            openStore();
        });
    }

    private boolean passwordValid(String value) {
        if (value == null || value.length() < 8 || value.length() > 10) return false;
        boolean upper = false, lower = false, digit = false, special = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= 'A' && c <= 'Z') upper = true;
            else if (c >= 'a' && c <= 'z') lower = true;
            else if (c >= '0' && c <= '9') digit = true;
            else special = true;
        }
        return upper && lower && digit && special;
    }

    private void showError(String message) {
        status.setText(message == null || message.isEmpty() ? "Não foi possível criar a conta. Tente novamente." : message);
        status.setTextColor(0xffffbd74);
    }

    private void openStore() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
