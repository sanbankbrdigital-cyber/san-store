package com.sanstore.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class StoreUi {
    public static final int BG = Color.rgb(9, 13, 22);
    public static final int CARD = Color.rgb(18, 26, 40);
    public static final int CARD_ALT = Color.rgb(27, 38, 57);
    public static final int TEXT = Color.rgb(245, 248, 255);
    public static final int MUTED = Color.rgb(165, 177, 198);
    public static final int BLUE = Color.rgb(123, 151, 255);
    public static final int GREEN = Color.rgb(104, 226, 184);
    public static final int GOLD = Color.rgb(255, 203, 126);
    private static final int NAV_BG = 0xffeef2f7;
    private static final int NAV_ACTIVE_BG = 0xffc9e8fc;
    private static final int NAV_ACTIVE = 0xff075f95;
    private static final int NAV_INACTIVE = 0xff515b66;
    private static final int BORDER = Color.rgb(43, 57, 79);
    private static final ExecutorService IMAGES = Executors.newFixedThreadPool(3);
    private static final Map<Activity, LoadingState> LOADERS = new WeakHashMap<>();

    private static final class LoadingState {
        int requests;
        Dialog dialog;
    }

    private StoreUi() {}

    public static void showLoading(Activity activity) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        synchronized (LOADERS) {
            LoadingState state = LOADERS.get(activity);
            if (state == null) {
                state = new LoadingState();
                state.dialog = createLoadingDialog(activity);
                LOADERS.put(activity, state);
            }
            state.requests++;
            if (!state.dialog.isShowing()) {
                state.dialog.show();
                Window window = state.dialog.getWindow();
                if (window != null) {
                    window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                    WindowManager.LayoutParams params = window.getAttributes();
                    int available = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 48);
                    params.width = Math.min(dp(activity, 340), available);
                    params.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    params.gravity = Gravity.CENTER;
                    params.dimAmount = 0.42f;
                    window.setAttributes(params);
                }
            }
        }
    }

    public static void hideLoading(Activity activity) {
        if (activity == null) return;
        synchronized (LOADERS) {
            LoadingState state = LOADERS.get(activity);
            if (state == null) return;
            state.requests--;
            if (state.requests <= 0) {
                try {
                    if (state.dialog != null && state.dialog.isShowing()) state.dialog.dismiss();
                } catch (RuntimeException ignored) {
                }
                LOADERS.remove(activity);
            }
        }
    }

    private static Dialog createLoadingDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout card = vertical(activity);
        card.setPadding(dp(activity, 21), dp(activity, 20), dp(activity, 21), dp(activity, 18));
        card.setBackground(shape(CARD, dp(activity, 24), BORDER));
        card.setElevation(dp(activity, 10));

        LinearLayout header = horizontal(activity);
        ProgressBar spinner = new ProgressBar(activity);
        spinner.setIndeterminate(true);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        spinner.setContentDescription("Carregando");
        header.addView(spinner, new LinearLayout.LayoutParams(dp(activity, 34), dp(activity, 34)));

        LinearLayout copy = vertical(activity);
        copy.setPadding(dp(activity, 14), 0, 0, 0);
        copy.addView(text(activity, "Por favor, aguarde", 16, TEXT, true));
        TextView subtitle = text(activity, "Carregando os dados da loja…", 12, MUTED, false);
        subtitle.setPadding(0, dp(activity, 4), 0, 0);
        copy.addView(subtitle);
        header.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(header);

        ProgressBar bar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        bar.setProgressTintList(ColorStateList.valueOf(BLUE));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(activity, 6));
        barParams.topMargin = dp(activity, 16);
        card.addView(bar, barParams);

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return dialog;
    }

    public static int dp(Activity a, float value) {
        return (int) (value * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(1, stroke);
        return d;
    }

    public static GradientDrawable gradient(int from, int to, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{from, to});
        d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(1, stroke);
        return d;
    }

    private static RippleDrawable ripple(int color, int radius, int stroke, int rippleColor) {
        GradientDrawable content = shape(color, radius, stroke);
        GradientDrawable mask = shape(Color.WHITE, radius, 0);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    public static LinearLayout vertical(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout horizontal(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static TextView text(Activity a, String value, float size, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        else t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setIncludeFontPadding(true);
        return t;
    }

    public static TextView badge(Activity a, String value, int background, int foreground) {
        TextView t = text(a, value, 10, foreground, true);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(a, 10), dp(a, 6), dp(a, 10), dp(a, 6));
        t.setBackground(shape(background, dp(a, 30), 0));
        return t;
    }

    public static LinearLayout screen(Activity a, String title, String subtitle, boolean back) {
        return screenInternal(a, title, subtitle, back, null);
    }

    public static LinearLayout screenWithBottomNav(Activity a, String title, String subtitle, boolean back, String selectedTab) {
        return screenInternal(a, title, subtitle, back, selectedTab);
    }

    private static LinearLayout screenInternal(Activity a, String title, String subtitle, boolean back, String selectedTab) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(selectedTab != null && Build.VERSION.SDK_INT >= 26 ? NAV_BG : BG);
        if (Build.VERSION.SDK_INT >= 26) {
            int systemUi = a.getWindow().getDecorView().getSystemUiVisibility();
            if (selectedTab != null) systemUi |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            else systemUi &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            a.getWindow().getDecorView().setSystemUiVisibility(systemUi);
        }
        LinearLayout outer = vertical(a);
        outer.setBackgroundColor(BG);

        LinearLayout header = horizontal(a);
        header.setPadding(dp(a, 20), dp(a, 15), dp(a, 20), dp(a, 12));
        if (back) {
            TextView b = text(a, "‹", 32, TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setContentDescription("Voltar");
            b.setBackground(ripple(CARD_ALT, dp(a, 18), BORDER, 0x33ffffff));
            header.addView(b, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));
            b.setOnClickListener(v -> a.finish());
        }

        LinearLayout titles = vertical(a);
        if (back) titles.setPadding(dp(a, 12), 0, 0, 0);
        TextView heading = text(a, title, back ? 21 : 24, TEXT, true);
        heading.setMaxLines(1);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(heading);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView sub = text(a, subtitle, 12, MUTED, false);
            sub.setPadding(0, dp(a, 3), 0, 0);
            sub.setMaxLines(2);
            titles.addView(sub);
        }
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        outer.addView(header);

        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content = vertical(a);
        content.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), dp(a, 32));
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (selectedTab != null) {
            outer.addView(bottomNavigation(a, selectedTab), new LinearLayout.LayoutParams(-1, dp(a, 66)));
        }

        outer.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        a.setContentView(outer);
        outer.requestApplyInsets();
        return content;
    }

    private static LinearLayout bottomNavigation(Activity a, String selectedTab) {
        LinearLayout nav = vertical(a);
        nav.setBackgroundColor(NAV_BG);
        View divider = new View(a);
        divider.setBackgroundColor(0xffd8e0e9);
        nav.addView(divider, new LinearLayout.LayoutParams(-1, dp(a, 1)));

        LinearLayout row = horizontal(a);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(a, 12), dp(a, 4), dp(a, 12), dp(a, 4));
        nav.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
        addNavigationTab(a, row, selectedTab, "apps", "Apps", 0);
        addNavigationTab(a, row, selectedTab, "games", "Jogos", 1);
        addNavigationTab(a, row, selectedTab, "profile", "Perfil", 2);
        return nav;
    }

    private static void addNavigationTab(Activity a, LinearLayout row, String selectedTab,
                                         String tab, String label, int iconType) {
        boolean selected = tab.equals(selectedTab);
        LinearLayout item = vertical(a);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(a, 4), dp(a, 3), dp(a, 4), dp(a, 2));
        item.setBackground(selected ? shape(NAV_ACTIVE_BG, dp(a, 23), 0) : new ColorDrawable(Color.TRANSPARENT));
        item.setClickable(true);
        item.setFocusable(true);
        item.setContentDescription(label);

        BottomIcon icon = new BottomIcon(a, iconType, selected ? NAV_ACTIVE : NAV_INACTIVE);
        item.addView(icon, new LinearLayout.LayoutParams(dp(a, 24), dp(a, 24)));
        TextView caption = text(a, label, 11, selected ? NAV_ACTIVE : NAV_INACTIVE, selected);
        caption.setGravity(Gravity.CENTER);
        caption.setPadding(0, dp(a, 1), 0, 0);
        item.addView(caption);
        row.addView(item, new LinearLayout.LayoutParams(0, dp(a, 54), 1));
        item.setOnClickListener(v -> openNavigationTab(a, tab));
    }

    private static void openNavigationTab(Activity activity, String tab) {
        Class<?> target;
        if ("games".equals(tab)) target = GamesActivity.class;
        else if ("profile".equals(tab)) target = AccountActivity.class;
        else target = AppsActivity.class;
        if (activity.getClass() == target) return;
        Intent intent = new Intent(activity, target);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivity(intent);
    }

    private static final class BottomIcon extends View {
        private final int kind;
        private final int color;
        private final float density;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        BottomIcon(Activity activity, int kind, int color) {
            super(activity);
            this.kind = kind;
            this.color = color;
            this.density = activity.getResources().getDisplayMetrics().density;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.save();
            canvas.translate(getWidth() / 2f - 12f * density, getHeight() / 2f - 12f * density);
            paint.setColor(color);
            paint.setStrokeWidth(2f * density);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            if (kind == 0) {
                paint.setStyle(Paint.Style.FILL);
                for (int y = 0; y < 2; y++) for (int x = 0; x < 2; x++) {
                    float left = (3 + x * 10) * density;
                    float top = (3 + y * 10) * density;
                    canvas.drawRoundRect(new RectF(left, top, left + 7 * density, top + 7 * density),
                            1.8f * density, 1.8f * density, paint);
                }
            } else if (kind == 1) {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawRoundRect(new RectF(2.5f * density, 6.5f * density, 21.5f * density, 18.5f * density),
                        5.5f * density, 5.5f * density, paint);
                canvas.drawLine(6 * density, 12.5f * density, 10 * density, 12.5f * density, paint);
                canvas.drawLine(8 * density, 10.5f * density, 8 * density, 14.5f * density, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(16 * density, 11.5f * density, 1.15f * density, paint);
                canvas.drawCircle(18.7f * density, 14.3f * density, 1.15f * density, paint);
            } else {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(12 * density, 7.5f * density, 3.4f * density, paint);
                Path shoulders = new Path();
                shoulders.moveTo(4 * density, 21 * density);
                shoulders.cubicTo(4.8f * density, 16.5f * density, 8 * density, 14.6f * density,
                        12 * density, 14.6f * density);
                shoulders.cubicTo(16 * density, 14.6f * density, 19.2f * density, 16.5f * density,
                        20 * density, 21 * density);
                canvas.drawPath(shoulders, paint);
            }
            canvas.restore();
        }
    }

    public static TextView label(Activity a, String value) {
        TextView t = text(a, value, 12, MUTED, true);
        t.setLetterSpacing(0.025f);
        t.setPadding(dp(a, 2), dp(a, 17), 0, dp(a, 8));
        return t;
    }

    public static EditText input(Activity a, String hint, boolean multiline) {
        EditText e = new EditText(a);
        e.setSingleLine(!multiline);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(122, 137, 160));
        e.setHint(hint);
        e.setTextSize(14);
        e.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        e.setBackground(shape(Color.rgb(14, 20, 32), dp(a, 16), BORDER));
        e.setSelectAllOnFocus(false);
        if (multiline) {
            e.setGravity(Gravity.TOP);
            e.setMinLines(3);
            e.setMaxLines(6);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(a, 5);
        e.setLayoutParams(p);
        return e;
    }

    public static Button button(Activity a, String title, boolean primary) {
        Button b = new Button(a);
        b.setText(title);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setLetterSpacing(0.015f);
        b.setPadding(dp(a, 18), dp(a, 12), dp(a, 18), dp(a, 12));
        if (primary) {
            b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44ffffff),
                    gradient(0xff708dff, 0xff5b73e8, dp(a, 17), 0),
                    shape(Color.WHITE, dp(a, 17), 0)));
        } else {
            b.setBackground(ripple(CARD_ALT, dp(a, 17), BORDER, 0x33ffffff));
        }
        b.setMinHeight(dp(a, 52));
        b.setElevation(dp(a, 2));
        return b;
    }

    public static void gap(Activity a, LinearLayout into, int height) {
        View v = new View(a);
        into.addView(v, new LinearLayout.LayoutParams(1, dp(a, height)));
    }

    public static void section(Activity a, LinearLayout into, String title) {
        TextView t = text(a, title, 18, TEXT, true);
        t.setPadding(0, dp(a, 22), 0, dp(a, 12));
        into.addView(t);
    }

    public static View appCard(Activity a, AppItem app, Runnable onClick) {
        LinearLayout card = vertical(a);
        card.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));
        card.setBackground(ripple(CARD, dp(a, 24), BORDER, 0x24ffffff));
        card.setElevation(dp(a, 3));
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription("Abrir detalhes de " + app.name);

        LinearLayout row = horizontal(a);
        ImageView icon = new ImageView(a);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(shape(Color.rgb(36, 49, 73), dp(a, 20), 0));
        icon.setClipToOutline(true);
        icon.setImageDrawable(a.getDrawable(android.R.drawable.sym_def_app_icon));
        icon.setTag(app.image);
        loadImage(icon, app.image);
        row.addView(icon, new LinearLayout.LayoutParams(dp(a, 68), dp(a, 68)));

        LinearLayout info = vertical(a);
        info.setPadding(dp(a, 14), 0, 0, 0);
        TextView name = text(a, app.name, 16, TEXT, true);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(name);
        TextView publisher = text(a, "Por " + app.developerName, 11, MUTED, false);
        publisher.setMaxLines(1);
        publisher.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams publisherParams = new LinearLayout.LayoutParams(-1, -2);
        publisherParams.topMargin = dp(a, 4);
        info.addView(publisher, publisherParams);
        if (app.subcategory != null && !app.subcategory.trim().isEmpty() && !"Sem categoria".equalsIgnoreCase(app.subcategory)) {
            TextView subcategory = badge(a, app.subcategory, 0xff1b3b4a, 0xffa5e1e8);
            LinearLayout.LayoutParams subcategoryParams = new LinearLayout.LayoutParams(-2, -2);
            subcategoryParams.topMargin = dp(a, 5);
            info.addView(subcategory, subcategoryParams);
        }

        LinearLayout tags = horizontal(a);
        TextView category = badge(a, "Game".equals(app.category) ? "JOGO" : "APLICATIVO", 0xff222f4a, BLUE);
        tags.addView(category);
        if (app.featured) {
            TextView featured = badge(a, "DESTAQUE", 0xff3a3022, GOLD);
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-2, -2);
            fp.leftMargin = dp(a, 6);
            tags.addView(featured, fp);
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(a, 8);
        info.addView(tags, tp);
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(row);

        TextView desc = text(a, app.description, 13, MUTED, false);
        desc.setMaxLines(3);
        desc.setEllipsize(TextUtils.TruncateAt.END);
        desc.setLineSpacing(dp(a, 2), 1f);
        desc.setPadding(0, dp(a, 14), 0, dp(a, 13));
        card.addView(desc);

        TextView open = text(a, "Ver detalhes   ›", 13, BLUE, true);
        open.setGravity(Gravity.CENTER_VERTICAL);
        open.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
        open.setBackground(shape(0xff1b2840, dp(a, 14), 0));
        card.addView(open, new LinearLayout.LayoutParams(-2, -2));
        card.setOnClickListener(v -> onClick.run());

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(a, 14);
        card.setLayoutParams(p);
        return card;
    }

    public static void loadImage(ImageView target, String src) {
        if (src == null || !src.startsWith("https://")) return;
        IMAGES.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(src).openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(9000);
                c.setInstanceFollowRedirects(true);
                Bitmap bitmap = BitmapFactory.decodeStream(c.getInputStream());
                if (bitmap != null) target.post(() -> {
                    if (src.equals(target.getTag())) target.setImageBitmap(bitmap);
                });
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    public static android.content.Intent appIntent(Activity a, Class<?> target, AppItem x) {
        android.content.Intent i = new android.content.Intent(a, target);
        i.putExtra("id", x.id);
        i.putExtra("name", x.name);
        i.putExtra("category", x.category);
        i.putExtra("image", x.image);
        i.putExtra("apk", x.apk);
        i.putExtra("description", x.description);
        i.putExtra("featured", x.featured);
        i.putExtra("developerName", x.developerName);
        i.putExtra("subcategory", x.subcategory);
        return i;
    }

    public static void openDetails(Activity a, AppItem x) {
        a.startActivity(appIntent(a, AppDetailsActivity.class, x));
    }

    public static AppItem fromIntent(android.content.Intent i) {
        return new AppItem(i.getStringExtra("id"), i.getStringExtra("name"), i.getStringExtra("category"),
                i.getStringExtra("image"), i.getStringExtra("apk"), i.getStringExtra("description"),
                i.getBooleanExtra("featured", false), i.getStringExtra("developerName"), i.getStringExtra("subcategory"));
    }
}
