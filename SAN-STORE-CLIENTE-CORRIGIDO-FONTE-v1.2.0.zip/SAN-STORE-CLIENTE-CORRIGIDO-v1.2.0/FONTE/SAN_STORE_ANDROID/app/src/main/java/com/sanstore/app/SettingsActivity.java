package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URL;

public class SettingsActivity extends Activity {
    private EditText endpoint; private TextView status; private Button save,test;
    @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout content=StoreUi.screen(this,"Configurações","Conexão da loja com o catálogo MongoDB",true);StoreUi.label(this,"Endereço HTTPS da API *");endpoint=StoreUi.input(this,"https://san-store-dnrd.onrender.com",false);endpoint.setText(ApiClient.baseUrl(this));content.addView(endpoint);StoreUi.gap(this,content,8);content.addView(StoreUi.text(this,"Informe o domínio do servidor Node.js da SAN STORE. O aplicativo chama /api/apps e /api/health automaticamente. A URI e a senha do MongoDB permanecem apenas no servidor.",13,StoreUi.MUTED,false));StoreUi.gap(this,content,18);save=StoreUi.button(this,"Salvar endereço",true);save.setOnClickListener(v->save());content.addView(save,new LinearLayout.LayoutParams(-1,StoreUi.dp(this,52)));StoreUi.gap(this,content,10);test=StoreUi.button(this,"Testar conexão",false);test.setOnClickListener(v->test());content.addView(test,new LinearLayout.LayoutParams(-1,StoreUi.dp(this,52)));StoreUi.gap(this,content,14);status=StoreUi.text(this,"",13,StoreUi.MUTED,false);content.addView(status);}
    private String valid(){String value=endpoint.getText().toString().trim().replaceAll("/+$","");try{URL u=new URL(value);if(!"https".equalsIgnoreCase(u.getProtocol())||u.getHost().isEmpty())return null;return value;}catch(Exception e){return null;}}
    private void save(){String value=valid();if(value==null){Toast.makeText(this,"Digite um endereço HTTPS válido.",Toast.LENGTH_LONG).show();return;}ApiClient.saveBaseUrl(this,value);status.setText("Endereço salvo neste aparelho.");status.setTextColor(StoreUi.GREEN);Toast.makeText(this,"Configuração salva.",Toast.LENGTH_SHORT).show();}
    private void test(){String value=valid();if(value==null){Toast.makeText(this,"Digite um endereço HTTPS válido.",Toast.LENGTH_LONG).show();return;}ApiClient.saveBaseUrl(this,value);test.setEnabled(false);status.setText("Testando conexão...");status.setTextColor(StoreUi.MUTED);ApiClient.health(this,(data,error)->{test.setEnabled(true);if(error==null){status.setText("Conexão com a API e o MongoDB confirmada.");status.setTextColor(StoreUi.GREEN);}else{status.setText("Não conectou: "+error.getMessage());status.setTextColor(0xffffb86b);}});}
}
