package com.sanstore.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class SearchActivity extends Activity {
    private static final int REQUEST_VOICE_SEARCH = 4711;
    private static final int REQUEST_AUDIO_PERMISSION = 4712;
    private final ArrayList<AppItem> apps = new ArrayList<>();
    private LinearLayout list;
    private EditText search;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout searchBar = buildSearchBar();
        LinearLayout content = StoreUi.screenWithFixedToolbar(this, "Buscar",
                "Encontre aplicativos e jogos", true, searchBar);
        list = StoreUi.vertical(this);
        content.addView(list);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render(); }
            @Override public void afterTextChanged(Editable editable) { }
        });
        search.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (keyboard != null) keyboard.hideSoftInputFromWindow(search.getWindowToken(), 0);
                search.clearFocus();
                return true;
            }
            return false;
        });

        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            apps.clear();
            if (error == null) apps.addAll(items);
            else apps.add(AppItem.sanbank());
            render();
        });
    }

    private LinearLayout buildSearchBar() {
        LinearLayout bar = StoreUi.horizontal(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(StoreUi.dp(this, 13), StoreUi.dp(this, 5), StoreUi.dp(this, 6), StoreUi.dp(this, 5));
        bar.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 28), 0xff2b394f));
        bar.setElevation(StoreUi.dp(this, 5));

        TextView searchIcon = StoreUi.text(this, "⌕", 25, StoreUi.MUTED, false);
        searchIcon.setGravity(Gravity.CENTER);
        searchIcon.setContentDescription("Pesquisar");
        bar.addView(searchIcon, new LinearLayout.LayoutParams(StoreUi.dp(this, 32), -1));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(StoreUi.TEXT);
        search.setHintTextColor(StoreUi.MUTED);
        search.setHint("Buscar apps e jogos");
        search.setContentDescription("Buscar aplicativos e jogos");
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(StoreUi.dp(this, 5), StoreUi.dp(this, 8), StoreUi.dp(this, 6), StoreUi.dp(this, 8));
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        bar.addView(search, new LinearLayout.LayoutParams(0, -1, 1));

        ImageView microphone = new ImageView(this);
        microphone.setImageResource(android.R.drawable.ic_btn_speak_now);
        microphone.setColorFilter(Color.WHITE);
        microphone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        microphone.setPadding(StoreUi.dp(this, 12), StoreUi.dp(this, 12),
                StoreUi.dp(this, 12), StoreUi.dp(this, 12));
        microphone.setContentDescription("Pesquisar por voz");
        microphone.setClickable(true);
        microphone.setFocusable(true);
        microphone.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55ffffff),
                StoreUi.gradient(0xff708dff, 0xff5b73e8, StoreUi.dp(this, 24), 0),
                StoreUi.shape(Color.WHITE, StoreUi.dp(this, 24), 0)));
        microphone.setOnClickListener(view -> requestVoiceSearch());
        bar.addView(microphone, new LinearLayout.LayoutParams(StoreUi.dp(this, 48), StoreUi.dp(this, 48)));
        return bar;
    }

    private void requestVoiceSearch() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                new AlertDialog.Builder(this)
                        .setTitle("Permitir pesquisa por voz")
                        .setMessage("O microfone só será usado quando você tocar no botão de voz. A busca por texto continua disponível sem essa permissão.")
                        .setNegativeButton("Agora não", null)
                        .setPositiveButton("Continuar", (dialog, which) -> requestPermissions(
                                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION))
                        .show();
            } else {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
            }
            return;
        }
        launchVoiceSearch();
    }

    private void launchVoiceSearch() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga o nome do app ou jogo");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            startActivityForResult(intent, REQUEST_VOICE_SEARCH);
        } catch (ActivityNotFoundException unavailable) {
            Toast.makeText(this, "A pesquisa por voz não está disponível neste aparelho.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_AUDIO_PERMISSION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchVoiceSearch();
        } else {
            Toast.makeText(this, "Sem acesso ao microfone, você ainda pode pesquisar digitando.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VOICE_SEARCH || resultCode != RESULT_OK || data == null) return;
        ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (matches != null && !matches.isEmpty()) {
            search.setText(matches.get(0));
            search.setSelection(search.getText().length());
        }
    }

    private void render() {
        if (list == null || search == null) return;
        list.removeAllViews();
        String query = search.getText().toString().trim().toLowerCase(new Locale("pt", "BR"));
        int count = 0;
        for (AppItem app : apps) {
            String haystack = (app.name + " " + app.description + " " + app.category)
                    .toLowerCase(new Locale("pt", "BR"));
            if (query.isEmpty() || haystack.contains(query)) {
                count++;
                list.addView(StoreUi.appCard(this, app, () -> StoreUi.openDetails(this, app)));
            }
        }
        if (count == 0) {
            TextView empty = StoreUi.text(this, "Nenhum aplicativo encontrado.", 14, StoreUi.MUTED, false);
            empty.setPadding(StoreUi.dp(this, 4), StoreUi.dp(this, 20), StoreUi.dp(this, 4), 0);
            list.addView(empty);
        }
    }
}
