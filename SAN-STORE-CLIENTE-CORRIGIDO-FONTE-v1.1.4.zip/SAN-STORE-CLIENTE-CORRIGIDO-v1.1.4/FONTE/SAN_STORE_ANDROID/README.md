# SAN STORE Android nativa

Aplicativo Android nativo em Java — sem WebView e sem HTML/CSS/JavaScript na interface. As telas usam Activities próprias: `MainActivity` (início), `AppsActivity`, `GamesActivity`, `SearchActivity`, `AppDetailsActivity`, `AppDownloadActivity` (progresso/cancelamento e instalador Android), `DeveloperActivity`, `PublishAppActivity` e `SettingsActivity`. Cada tela usa controles nativos do Android.

## Compatibilidade

- `minSdk 21` — Android 5.0+
- `targetSdk 37` e `compileSdk 37` — configuração solicitada para Android 17
- Java 17, Android Gradle Plugin 8.13.0
- Package: `com.sanstore.app`

## MongoDB e API

O aplicativo Android **não** conecta diretamente ao MongoDB. Ele usa a API Node.js da SAN STORE, que mantém a URI e a senha do MongoDB no servidor. A API deve oferecer `GET /api/apps`, `GET /api/health` e `POST /api/apps`, conforme o projeto `san-store-mongodb`.

1. A API da SAN STORE já vem configurada por padrão como `https://san-store-dnrd.onrender.com`.
2. Se trocar de hospedagem, abra **Configurações do servidor**, informe outro domínio HTTPS e toque em **Testar conexão**.
3. No servidor, configure `MONGODB_URI`, `MONGODB_DB` e `APP_PUBLISH_KEY` em variáveis privadas; nunca no APK ou no GitHub.
4. A área de desenvolvedor envia a chave de publicação ao servidor apenas para autorizar o cadastro; o app não a salva.
5. O serviço gratuito pode demorar alguns segundos na primeira chamada após inatividade.

O card do SANBANK BR DIGITAL já está incluído como destaque e também é inicializado no MongoDB pelo backend.

## Abrir e gerar APK no Android Studio

1. Use Android Studio com JDK 17 e instale as plataformas Android SDK 37 e Build Tools compatíveis.
2. Abra a pasta `SAN_STORE_ANDROID` como projeto Gradle e aguarde a sincronização.
3. Para teste, use **Build > Build APK(s)**. O APK de depuração fica em `app/build/outputs/apk/debug/` e pode ser instalado em aparelhos Android 5.0 ou superior.
4. Para distribuição, gere um APK de release assinado com sua própria chave em **Build > Generate Signed Bundle / APK**. Não compartilhe a chave privada nem as senhas.

O app solicita somente as permissões necessárias: `INTERNET` para catálogo/imagens e `REQUEST_INSTALL_PACKAGES` para encaminhar APK ao instalador do Android. O download usa o Download Manager e não precisa de acesso amplo ao armazenamento. No Android 8.0+, o app abre a tela do sistema para permitir instalações pela SAN STORE; no Android 5.0–7.1, explica como ativar **Configurações > Segurança > Fontes desconhecidas**. O Android exige essa autorização manual e a SAN STORE não consegue concedê-la automaticamente.
