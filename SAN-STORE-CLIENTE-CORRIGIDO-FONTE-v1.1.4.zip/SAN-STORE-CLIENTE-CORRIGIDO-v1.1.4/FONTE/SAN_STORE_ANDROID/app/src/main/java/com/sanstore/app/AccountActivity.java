package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AccountActivity extends Activity {
    private Button logout;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Minha conta", "Dados da sua conta SAN STORE", true);

        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18));
        card.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 23), 0xff354767));
        card.addView(StoreUi.badge(this, "SESSÃO ATIVA", 0xff174137, StoreUi.GREEN));

        TextView account = StoreUi.text(this, ApiClient.sessionAccount(this), 21, StoreUi.TEXT, true);
        account.setPadding(0, StoreUi.dp(this, 14), 0, 0);
        card.addView(account);

        TextView email = StoreUi.text(this, ApiClient.sessionEmail(this), 14, 0xffc2cde2, false);
        email.setPadding(0, StoreUi.dp(this, 5), 0, 0);
        card.addView(email);
        content.addView(card);

        StoreUi.section(this, content, "Segurança");
        content.addView(StoreUi.text(this,
                "A senha não é guardada no aplicativo. Ao sair, a sessão deste aparelho será encerrada no servidor.",
                13, StoreUi.MUTED, false));

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 12), 0, StoreUi.dp(this, 4));
        content.addView(status);

        logout = StoreUi.button(this, "Sair da conta", false);
        logout.setOnClickListener(v -> signOut());
        content.addView(logout, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void signOut() {
        logout.setEnabled(false);
        logout.setText("Encerrando sessão…");
        ApiClient.logout(this, (done, error) -> {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
