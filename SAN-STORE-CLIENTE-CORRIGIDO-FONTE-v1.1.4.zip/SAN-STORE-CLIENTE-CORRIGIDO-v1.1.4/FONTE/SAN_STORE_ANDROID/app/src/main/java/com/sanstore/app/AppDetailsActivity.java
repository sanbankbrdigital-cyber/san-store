package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class AppDetailsActivity extends Activity {
    private AppItem item;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        item = StoreUi.fromIntent(getIntent());
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Detalhes do app", "Informações do aplicativo", true);
        LinearLayout hero = StoreUi.horizontal(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15));
        hero.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 24), 0xff2b3a53));
        hero.setElevation(StoreUi.dp(this, 3));

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(StoreUi.shape(0xff263046, StoreUi.dp(this, 22), 0));
        icon.setClipToOutline(true);
        icon.setImageDrawable(getDrawable(android.R.drawable.sym_def_app_icon));
        icon.setTag(item.image);
        StoreUi.loadImage(icon, item.image);
        hero.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(this, 90), StoreUi.dp(this, 90)));

        TextView title = StoreUi.text(this, item.name, 21, StoreUi.TEXT, true);
        title.setPadding(StoreUi.dp(this, 15), 0, 0, 0);
        hero.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(hero);

        StoreUi.gap(this, content, 17);
        content.addView(StoreUi.text(this, "Game".equals(item.category) ? "JOGO" : "APLICATIVO", 12, StoreUi.BLUE, true));
        StoreUi.section(this, content, "Publicador");
        content.addView(StoreUi.text(this, "Publicado por " + item.developerName, 14, StoreUi.MUTED, false));
        StoreUi.section(this, content, "Sobre este aplicativo");
        TextView description = StoreUi.text(this, item.description, 15, StoreUi.MUTED, false);
        description.setLineSpacing(StoreUi.dp(this, 3), 1f);
        content.addView(description);

        StoreUi.section(this, content, "Download e instalação");
        content.addView(StoreUi.text(this,
                "O download e a confirmação de instalação serão feitos em uma tela nativa própria. O Android mantém a confirmação final sob seu controle.",
                13, StoreUi.MUTED, false));
        StoreUi.gap(this, content, 15);
        Button download = StoreUi.button(this, "↓  Abrir atividade de download", true);
        download.setOnClickListener(v -> startActivity(StoreUi.appIntent(this, AppDownloadActivity.class, item)));
        content.addView(download, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }
}
