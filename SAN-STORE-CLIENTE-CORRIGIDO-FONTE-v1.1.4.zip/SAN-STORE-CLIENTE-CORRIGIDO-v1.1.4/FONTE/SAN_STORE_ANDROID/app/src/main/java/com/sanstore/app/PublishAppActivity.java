package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PublishAppActivity extends Activity {
    private EditText name, image, apk, description;
    private Spinner category;
    private Button submit;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Nova publicação", "Envio para análise administrativa", true);

        LinearLayout note = StoreUi.vertical(this);
        note.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        note.setBackground(StoreUi.shape(0xff202c45, StoreUi.dp(this, 19), 0xff354767));
        note.addView(StoreUi.badge(this, "PUBLICAÇÃO SOB REVISÃO", 0xff2b3d61, 0xffd7e2ff));
        TextView explanation = StoreUi.text(this, "O app não aparecerá na loja até ser aprovado pelo administrador.", 12, StoreUi.MUTED, false);
        explanation.setPadding(0, StoreUi.dp(this, 8), 0, 0);
        note.addView(explanation);
        content.addView(note);

        StoreUi.label(this, "Nome do app ou jogo");
        name = StoreUi.input(this, "Ex.: Meu aplicativo", false);
        content.addView(name);

        StoreUi.label(this, "Categoria");
        category = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Aplicativo", "Jogo"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);
        category.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 16), 0xff2b3a53));
        category.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 6), StoreUi.dp(this, 14), StoreUi.dp(this, 6));
        content.addView(category, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));

        StoreUi.label(this, "Link HTTPS público do ícone");
        image = StoreUi.input(this, "https://.../icone.webp", false);
        content.addView(image);
        StoreUi.label(this, "Link HTTPS público do APK");
        apk = StoreUi.input(this, "https://.../aplicativo.apk", false);
        content.addView(apk);
        StoreUi.label(this, "Descrição");
        description = StoreUi.input(this, "Descreva o que o app faz", true);
        content.addView(description);

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 9), 0, StoreUi.dp(this, 7));
        content.addView(status);
        submit = StoreUi.button(this, "Enviar para aprovação", true);
        submit.setOnClickListener(v -> submit());
        content.addView(submit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void submit() {
        String n = name.getText().toString().trim();
        String im = image.getText().toString().trim();
        String ap = apk.getText().toString().trim();
        String desc = description.getText().toString().trim();
        if (n.length() < 2 || n.length() > 60 || desc.length() < 5 || desc.length() > 350 ||
                !im.startsWith("https://") || !ap.startsWith("https://")) {
            status.setText("Preencha os campos e use links HTTPS válidos.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        submit.setEnabled(false);
        submit.setText("Enviando…");
        status.setText("Enviando para análise do administrador…");
        status.setTextColor(StoreUi.MUTED);
        String value = category.getSelectedItemPosition() == 1 ? "Game" : "App";
        ApiClient.submitApp(this, n, value, im, ap, desc, (response, error) -> {
            if (isFinishing()) return;
            submit.setEnabled(true);
            submit.setText("Enviar para aprovação");
            if (error != null) {
                status.setText(error.getMessage());
                status.setTextColor(StoreUi.GOLD);
                return;
            }
            Toast.makeText(this, "Enviado. O app só será publicado após aprovação.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
