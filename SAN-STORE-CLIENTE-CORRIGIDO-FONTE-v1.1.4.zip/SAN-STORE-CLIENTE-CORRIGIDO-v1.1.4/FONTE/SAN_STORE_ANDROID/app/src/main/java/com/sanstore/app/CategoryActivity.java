package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

/** Shared native screen logic; each category has its own concrete Activity. */
public abstract class CategoryActivity extends Activity {
    private String category;
    private LinearLayout list;
    private TextView status;

    protected abstract String categoryKey();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        category = categoryKey();
        render();
        load();
    }

    private void render() {
        String title = "Game".equals(category) ? "Jogos" : "Aplicativos";
        LinearLayout content = StoreUi.screen(this, title, "Explore por categoria", true);
        status = StoreUi.text(this, "Carregando catálogo...", 12, StoreUi.MUTED, false);
        content.addView(status);
        list = StoreUi.vertical(this);
        StoreUi.gap(this, content, 12);
        content.addView(list);
    }

    private void load() {
        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            ArrayList<AppItem> source = items;
            if (error != null) {
                source = new ArrayList<>();
                source.add(AppItem.sanbank());
                status.setText("Servidor indisponível · mostrando conteúdo de demonstração");
            } else {
                status.setText(items.size() + " itens no catálogo");
            }
            list.removeAllViews();
            int count = 0;
            for (AppItem item : source) {
                if (category.equals(item.category)) {
                    count++;
                    list.addView(StoreUi.appCard(this, item, () -> StoreUi.openDetails(this, item)));
                }
            }
            if (count == 0) list.addView(StoreUi.text(this, "Ainda não há itens nesta categoria.", 14, StoreUi.MUTED, false));
        });
    }
}
