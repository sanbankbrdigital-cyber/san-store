package com.sanstore.app;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

final class ProfilePhotoCodec {
    static final class EncodedPhoto {
        final String dataUrl;
        final Bitmap preview;
        EncodedPhoto(String dataUrl, Bitmap preview) { this.dataUrl = dataUrl; this.preview = preview; }
    }

    private ProfilePhotoCodec() { }

    static EncodedPhoto fromUri(Context context, Uri uri) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Não foi possível abrir a foto selecionada.");
            BitmapFactory.decodeStream(input, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("O arquivo selecionado não é uma imagem válida.");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        while (bounds.outWidth / options.inSampleSize > 1400 || bounds.outHeight / options.inSampleSize > 1400) options.inSampleSize *= 2;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap source;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Não foi possível abrir a foto selecionada.");
            source = BitmapFactory.decodeStream(input, null, options);
        }
        if (source == null) throw new IllegalArgumentException("Não foi possível ler essa imagem.");

        Bitmap candidate = source;
        int maxDimension = 560;
        while (true) {
            int max = Math.max(candidate.getWidth(), candidate.getHeight());
            if (max > maxDimension) {
                float ratio = maxDimension / (float) max;
                Bitmap scaled = Bitmap.createScaledBitmap(candidate,
                        Math.max(1, Math.round(candidate.getWidth() * ratio)),
                        Math.max(1, Math.round(candidate.getHeight() * ratio)), true);
                if (candidate != source && candidate != scaled) candidate.recycle();
                candidate = scaled;
            }
            for (int quality = 82; quality >= 52; quality -= 10) {
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                candidate.compress(Bitmap.CompressFormat.JPEG, quality, output);
                byte[] bytes = output.toByteArray();
                if (bytes.length <= 400 * 1024) {
                    String encoded = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
                    if (candidate != source) source.recycle();
                    return new EncodedPhoto(encoded, candidate);
                }
            }
            if (maxDimension <= 320) break;
            maxDimension -= 80;
        }
        if (candidate != source) candidate.recycle();
        source.recycle();
        throw new IllegalArgumentException("A foto ficou grande demais. Escolha outra imagem.");
    }

    static Bitmap decode(String dataUrl) {
        if (dataUrl == null || !dataUrl.startsWith("data:image/jpeg;base64,")) return null;
        try {
            byte[] bytes = Base64.decode(dataUrl.substring("data:image/jpeg;base64,".length()), Base64.DEFAULT);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        } catch (RuntimeException ignored) { return null; }
    }
}
