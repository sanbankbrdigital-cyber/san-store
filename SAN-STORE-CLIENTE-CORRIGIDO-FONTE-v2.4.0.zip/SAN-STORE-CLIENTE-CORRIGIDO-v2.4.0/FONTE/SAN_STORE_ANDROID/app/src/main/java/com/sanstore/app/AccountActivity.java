package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class AccountActivity extends Activity {
    private static final int REQUEST_PROFILE_PHOTO = 7211;
    private Button logout;
    private TextView status;
    private TextView photoStatus;
    private ImageView avatarImage;
    private TextView avatarFallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
        loadProfilePhoto();
    }

    private void render() {
        LinearLayout content = StoreUi.screenWithBottomNav(this, "Minha conta", "Dados da sua conta SAN STORE", true, "profile");

        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18));
        card.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 23), 0xff354767));
        card.setElevation(StoreUi.dp(this, 6));
        card.addView(StoreUi.badge(this, "SESSÃO ATIVA", 0xff174137, StoreUi.GREEN));

        LinearLayout identity = StoreUi.horizontal(this);
        identity.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams identityParams = new LinearLayout.LayoutParams(-1, -2);
        identityParams.topMargin = StoreUi.dp(this, 14);
        card.addView(identity, identityParams);
        FrameLayout avatar = new FrameLayout(this);
        avatarFallback = StoreUi.text(this, "👤", 34, StoreUi.BLUE, true);
        avatarFallback.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff2f4b79, 0xff182943});
        circle.setShape(GradientDrawable.OVAL);
        circle.setStroke(StoreUi.dp(this, 1), 0xff7390bb);
        avatarFallback.setBackground(circle);
        avatar.addView(avatarFallback, new FrameLayout.LayoutParams(-1, -1));
        avatarImage = new ImageView(this);
        avatarImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable photoOutline = new GradientDrawable();
        photoOutline.setShape(GradientDrawable.OVAL);
        photoOutline.setColor(0xff1b2a41);
        photoOutline.setStroke(StoreUi.dp(this, 1), 0xff8aa8d3);
        avatarImage.setBackground(photoOutline);
        avatarImage.setClipToOutline(true);
        avatarImage.setVisibility(ImageView.GONE);
        avatar.addView(avatarImage, new FrameLayout.LayoutParams(-1, -1));
        identity.addView(avatar, new LinearLayout.LayoutParams(StoreUi.dp(this, 78), StoreUi.dp(this, 78)));

        LinearLayout identityText = StoreUi.vertical(this);
        identityText.setPadding(StoreUi.dp(this, 13), 0, 0, 0);
        identityText.addView(StoreUi.text(this, ApiClient.sessionAccount(this), 20, StoreUi.TEXT, true));
        identityText.addView(StoreUi.text(this, ApiClient.sessionEmail(this), 13, 0xffc2cde2, false));
        identity.addView(identityText, new LinearLayout.LayoutParams(0, -2, 1));

        Button choosePhoto = StoreUi.button(this, "＋  Alterar foto do perfil", false);
        LinearLayout.LayoutParams photoParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48));
        photoParams.topMargin = StoreUi.dp(this, 13);
        card.addView(choosePhoto, photoParams);
        choosePhoto.setOnClickListener(v -> choosePhoto());
        photoStatus = StoreUi.text(this, "Foto privada, visível na sua conta.", 11, StoreUi.MUTED, false);
        photoStatus.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 6), 0, 0);
        card.addView(photoStatus);
        content.addView(card);

        StoreUi.section(this, content, "Aparência");
        LinearLayout appearance = StoreUi.vertical(this);
        appearance.setPadding(StoreUi.dp(this, 16), StoreUi.dp(this, 13), StoreUi.dp(this, 16), StoreUi.dp(this, 13));
        appearance.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        appearance.setElevation(StoreUi.dp(this, 6));
        Switch themeToggle = new Switch(this);
        themeToggle.setText("Tema claro");
        themeToggle.setTextColor(StoreUi.TEXT);
        themeToggle.setTextSize(14);
        themeToggle.setChecked(StoreUi.isLightTheme(this));
        themeToggle.setThumbTintList(ColorStateList.valueOf(StoreUi.BLUE));
        themeToggle.setTrackTintList(ColorStateList.valueOf(StoreUi.isLightTheme(this) ? 0xffa8c9e8 : 0xff53627a));
        appearance.addView(themeToggle, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48)));
        TextView themeHelp = StoreUi.text(this, "Ative para usar o tema claro; desative para o tema escuro.", 12, StoreUi.MUTED, false);
        themeHelp.setPadding(0, StoreUi.dp(this, 2), 0, 0);
        appearance.addView(themeHelp);
        content.addView(appearance);
        themeToggle.setOnCheckedChangeListener((button, light) -> {
            StoreUi.saveLightTheme(this, light);
            Toast.makeText(this, light ? "Tema claro ativado" : "Tema escuro ativado", Toast.LENGTH_SHORT).show();
            recreate();
        });

        StoreUi.section(this, content, "Segurança");
        content.addView(StoreUi.text(this,
                "A senha não é guardada no aplicativo. Se pedir uma nova senha, ela só muda após aprovação do administrador.",
                13, StoreUi.MUTED, false));
        Button securityInfo = StoreUi.button(this, "Segurança, licenças e versão", false);
        securityInfo.setOnClickListener(v -> startActivity(new Intent(this, SecurityInfoActivity.class)));
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52));
        infoParams.topMargin = StoreUi.dp(this, 12);
        content.addView(securityInfo, infoParams);

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 12), 0, StoreUi.dp(this, 4));
        content.addView(status);

        logout = StoreUi.button(this, "Sair da conta", false);
        logout.setOnClickListener(v -> signOut());
        content.addView(logout, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void choosePhoto() {
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("image/*");
        try { startActivityForResult(picker, REQUEST_PROFILE_PHOTO); }
        catch (Exception error) { Toast.makeText(this, "Não foi possível abrir a galeria de fotos.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PROFILE_PHOTO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        photoStatus.setText("Preparando a foto…");
        photoStatus.setTextColor(StoreUi.BLUE);
        new Thread(() -> {
            try {
                ProfilePhotoCodec.EncodedPhoto prepared = ProfilePhotoCodec.fromUri(getApplicationContext(), uri);
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    photoStatus.setText("Salvando foto do perfil…");
                    ApiClient.updateProfilePhoto(this, prepared.dataUrl, (saved, error) -> {
                        if (isFinishing()) return;
                        if (error != null) {
                            photoStatus.setText(error.getMessage());
                            photoStatus.setTextColor(StoreUi.GOLD);
                            return;
                        }
                        avatarImage.setImageBitmap(prepared.preview);
                        avatarImage.setVisibility(ImageView.VISIBLE);
                        avatarFallback.setVisibility(TextView.GONE);
                        photoStatus.setText("Foto do perfil atualizada.");
                        photoStatus.setTextColor(StoreUi.GREEN);
                    });
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    photoStatus.setText(error.getMessage() == null ? "Não foi possível preparar essa foto." : error.getMessage());
                    photoStatus.setTextColor(StoreUi.GOLD);
                });
            }
        }, "san-store-profile-photo").start();
    }

    private void loadProfilePhoto() {
        ApiClient.getProfilePhoto(this, (photo, error) -> {
            if (isFinishing() || error != null || photo == null || photo.isEmpty()) return;
            Bitmap bitmap = ProfilePhotoCodec.decode(photo);
            if (bitmap == null) return;
            avatarImage.setImageBitmap(bitmap);
            avatarImage.setVisibility(ImageView.VISIBLE);
            avatarFallback.setVisibility(TextView.GONE);
        });
    }

    private void signOut() {
        logout.setEnabled(false);
        logout.setText("Encerrando sessão…");
        ApiClient.logout(this, (done, error) -> {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
