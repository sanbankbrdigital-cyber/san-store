package com.sanstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppDetailsActivity extends Activity {
    private AppItem item;
    private RatingBar ratingInput;
    private EditText reviewInput;
    private Button submitButton;
    private LinearLayout screenshotSection;
    private LinearLayout screenshotRow;
    private TextView screenshotCount;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService screenshotWorker = Executors.newSingleThreadExecutor();
    private TextView ratingSummary;
    private RatingBar averageRating;
    private LinearLayout reviewsList;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        item = StoreUi.fromIntent(getIntent());
        render();
        addShareButton();
        loadReviews();
        loadScreenshots();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Detalhes do app", "Informações e avaliações", true);
        LinearLayout hero = StoreUi.horizontal(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15), StoreUi.dp(this, 15));
        hero.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 24), 0xff2b3a53));
        hero.setElevation(StoreUi.dp(this, 6));

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(StoreUi.shape(0xff263046, StoreUi.dp(this, 22), 0));
        icon.setClipToOutline(true);
        icon.setImageDrawable(getDrawable(android.R.drawable.sym_def_app_icon));
        icon.setTag(item.image);
        StoreUi.loadImage(icon, item.image);
        hero.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(this, 90), StoreUi.dp(this, 90)));

        TextView title = StoreUi.text(this, item.name, 21, StoreUi.TEXT, true);
        title.setPadding(StoreUi.dp(this, 15), 0, 0, 0);
        hero.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(hero);

        StoreUi.gap(this, content, 17);
        content.addView(StoreUi.text(this, "Game".equals(item.category) ? "JOGO" : "APLICATIVO", 12, StoreUi.BLUE, true));
        if (item.subcategory != null && !item.subcategory.trim().isEmpty()) {
            TextView subcategory = StoreUi.badge(this, item.subcategory, 0xff1b3b4a, 0xffa5e1e8);
            LinearLayout.LayoutParams subcategoryParams = new LinearLayout.LayoutParams(-2, -2);
            subcategoryParams.topMargin = StoreUi.dp(this, 6);
            content.addView(subcategory, subcategoryParams);
        }
        if (item.blocked) {
            LinearLayout blockedNotice = StoreUi.vertical(this);
            blockedNotice.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14),
                    StoreUi.dp(this, 15), StoreUi.dp(this, 14));
            blockedNotice.setBackground(StoreUi.shape(0xff4b2830, StoreUi.dp(this, 22), 0xff874957));
            blockedNotice.addView(StoreUi.text(this, "🔒 Aplicativo bloqueado na SAN STORE", 15,
                    0xffffd0d5, true));
            String reason = item.blockReason == null || item.blockReason.trim().isEmpty()
                    ? "O administrador suspendeu os downloads deste app." : item.blockReason.trim();
            TextView reasonText = StoreUi.text(this, reason, 13, 0xffffe6e9, false);
            reasonText.setPadding(0, StoreUi.dp(this, 6), 0, 0);
            blockedNotice.addView(reasonText);
            LinearLayout.LayoutParams noticeParams = new LinearLayout.LayoutParams(-1, -2);
            noticeParams.topMargin = StoreUi.dp(this, 15);
            content.addView(blockedNotice, noticeParams);
            Button unavailable = StoreUi.button(this, "🔒  Download indisponível", false);
            unavailable.setEnabled(false);
            content.addView(unavailable, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
        } else {
            Button install = StoreUi.button(this, "Instalar", true);
            LinearLayout.LayoutParams installParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54));
            installParams.topMargin = StoreUi.dp(this, 15);
            content.addView(install, installParams);
            install.setOnClickListener(v -> startActivity(StoreUi.appIntent(this, AppDownloadActivity.class, item)));
        }

        screenshotSection = StoreUi.vertical(this);
        screenshotSection.setVisibility(View.GONE);
        screenshotSection.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 13),
                StoreUi.dp(this, 14), StoreUi.dp(this, 6));
        screenshotSection.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337,
                StoreUi.dp(this, 24), 0xff617a9d));
        screenshotSection.setElevation(StoreUi.dp(this, 6));
        LinearLayout screenshotHeader = StoreUi.horizontal(this);
        TextView galleryIcon = StoreUi.text(this, "▧", 20, 0xffd7e2ff, true);
        galleryIcon.setGravity(Gravity.CENTER);
        galleryIcon.setBackground(StoreUi.shape(0xff2b3d61, StoreUi.dp(this, 14), 0));
        screenshotHeader.addView(galleryIcon, new LinearLayout.LayoutParams(StoreUi.dp(this, 42), StoreUi.dp(this, 42)));
        LinearLayout galleryTitles = StoreUi.vertical(this);
        galleryTitles.setPadding(StoreUi.dp(this, 10), 0, 0, 0);
        galleryTitles.addView(StoreUi.text(this, "Capturas de tela", 16, StoreUi.TEXT, true));
        galleryTitles.addView(StoreUi.text(this, "TOQUE PARA AMPLIAR · DESLIZE", 9, StoreUi.BLUE, true));
        screenshotHeader.addView(galleryTitles, new LinearLayout.LayoutParams(0, -2, 1));
        screenshotCount = StoreUi.badge(this, "GALERIA", 0xff263d5e, 0xffd7e2ff);
        screenshotHeader.addView(screenshotCount);
        screenshotSection.addView(screenshotHeader);
        HorizontalScrollView screenshotScroll = new HorizontalScrollView(this);
        screenshotScroll.setHorizontalScrollBarEnabled(false);
        screenshotRow = StoreUi.horizontal(this);
        screenshotRow.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 11), StoreUi.dp(this, 10), StoreUi.dp(this, 12));
        screenshotScroll.addView(screenshotRow, new HorizontalScrollView.LayoutParams(-2, -2));
        screenshotSection.addView(screenshotScroll);
        LinearLayout.LayoutParams screenshotSectionParams = new LinearLayout.LayoutParams(-1, -2);
        screenshotSectionParams.topMargin = StoreUi.dp(this, 12);
        content.addView(screenshotSection, screenshotSectionParams);

        StoreUi.section(this, content, "Publicador");
        content.addView(StoreUi.text(this, "Publicado por " + item.developerName, 14, StoreUi.MUTED, false));
        StoreUi.section(this, content, "Sobre este aplicativo");
        TextView description = StoreUi.text(this, item.description, 15, StoreUi.MUTED, false);
        description.setLineSpacing(StoreUi.dp(this, 3), 1f);
        content.addView(description);
        if (item.whatsNew != null && !item.whatsNew.trim().isEmpty()) {
            StoreUi.section(this, content, "Novidades desta versão");
            TextView whatsNew = StoreUi.text(this, item.whatsNew, 14, StoreUi.MUTED, false);
            whatsNew.setLineSpacing(StoreUi.dp(this, 3), 1f);
            content.addView(whatsNew);
        }

        StoreUi.section(this, content, "Avaliações dos usuários");
        LinearLayout scoreCard = StoreUi.horizontal(this);
        scoreCard.setGravity(Gravity.CENTER_VERTICAL);
        scoreCard.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 12), StoreUi.dp(this, 14), StoreUi.dp(this, 12));
        scoreCard.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        scoreCard.setElevation(StoreUi.dp(this, 6));
        averageRating = ratingBar(true);
        averageRating.setRating(0f);
        scoreCard.addView(averageRating, new LinearLayout.LayoutParams(-2, -2));
        ratingSummary = StoreUi.text(this, "Carregando avaliações…", 13, StoreUi.MUTED, true);
        ratingSummary.setPadding(StoreUi.dp(this, 10), 0, 0, 0);
        scoreCard.addView(ratingSummary, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(scoreCard);

        LinearLayout reviewForm = StoreUi.vertical(this);
        reviewForm.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        reviewForm.setBackground(StoreUi.shape(0xff151e2d, StoreUi.dp(this, 20), 0xff2b3a53));
        reviewForm.setElevation(StoreUi.dp(this, 6));
        LinearLayout.LayoutParams formParams = new LinearLayout.LayoutParams(-1, -2);
        formParams.topMargin = StoreUi.dp(this, 12);
        content.addView(reviewForm, formParams);
        reviewForm.addView(StoreUi.text(this, "Deixe sua avaliação", 15, StoreUi.TEXT, true));
        ratingInput = ratingBar(false);
        ratingInput.setRating(5f);
        LinearLayout.LayoutParams inputRatingParams = new LinearLayout.LayoutParams(-2, -2);
        inputRatingParams.topMargin = StoreUi.dp(this, 6);
        reviewForm.addView(ratingInput, inputRatingParams);
        reviewInput = StoreUi.input(this, "Conte o que achou do aplicativo", true);
        reviewForm.addView(reviewInput);
        submitButton = StoreUi.button(this, "Publicar avaliação", true);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48));
        sendParams.topMargin = StoreUi.dp(this, 7);
        reviewForm.addView(submitButton, sendParams);
        submitButton.setOnClickListener(v -> submitReview());

        StoreUi.section(this, content, "Comentários recentes");
        reviewsList = StoreUi.vertical(this);
        content.addView(reviewsList);

        StoreUi.section(this, content, "Instalação segura");
        content.addView(StoreUi.text(this,
                "O Android abrirá a confirmação final da instalação para você.",
                13, StoreUi.MUTED, false));
    }

    private void addShareButton() {
        View decor = getWindow().getDecorView();
        if (!(decor instanceof FrameLayout)) return;
        FrameLayout root = (FrameLayout) decor;
        FrameLayout action = new FrameLayout(this);
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff263b60, 0xff17243b});
        fill.setShape(GradientDrawable.OVAL);
        fill.setStroke(StoreUi.dp(this, 1.5f), 0xff42e8b8);
        GradientDrawable mask = new GradientDrawable();
        mask.setShape(GradientDrawable.OVAL);
        mask.setColor(0xffffffff);
        action.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55ffffff), fill, mask));
        action.setElevation(StoreUi.dp(this, 5));
        action.setContentDescription("Compartilhar página do aplicativo");
        action.setFocusable(true);
        action.addView(new ShareGlyphView(this), new FrameLayout.LayoutParams(StoreUi.dp(this, 24), StoreUi.dp(this, 24), Gravity.CENTER));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(StoreUi.dp(this, 48), StoreUi.dp(this, 48),
                Gravity.TOP | Gravity.RIGHT);
        params.topMargin = statusBarHeight() + StoreUi.dp(this, 9);
        params.rightMargin = StoreUi.dp(this, 17);
        root.addView(action, params);
        action.setOnClickListener(v -> shareAppPage());
    }

    private void shareAppPage() {
        String page = ApiClient.baseUrl(this) + "/store/" + Uri.encode(item.id);
        StringBuilder message = new StringBuilder("Confira ").append(item.name).append(" na SAN STORE!");
        if (item.description != null && !item.description.trim().isEmpty()) {
            message.append("\n\n").append(item.description.trim());
        }
        message.append("\n\nVeja a página e as informações do aplicativo: ").append(page);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, item.name + " · SAN STORE");
        send.putExtra(Intent.EXTRA_TEXT, message.toString());
        startActivity(Intent.createChooser(send, "Compartilhar aplicativo"));
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private static final class ShareGlyphView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ShareGlyphView(Activity activity) { super(activity); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scale = Math.min(getWidth(), getHeight()) / 40f;
            canvas.save();
            canvas.translate((getWidth() - 40f * scale) / 2f, (getHeight() - 40f * scale) / 2f);
            canvas.scale(scale, scale);
            paint.setColor(0xfff4fffc);
            paint.setStrokeWidth(3f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawLine(13, 20, 27, 11, paint);
            canvas.drawLine(13, 20, 27, 29, paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(11, 20, 4.2f, paint);
            canvas.drawCircle(29, 10, 4.2f, paint);
            canvas.drawCircle(29, 30, 4.2f, paint);
            canvas.restore();
        }
    }

    private void loadScreenshots() {
        ApiClient.getScreenshots(this, item.id, (encoded, error) -> {
            if (isFinishing() || error != null || encoded == null || encoded.isEmpty()) return;
            screenshotWorker.execute(() -> {
                ArrayList<Bitmap> decoded = new ArrayList<>();
                for (String value : encoded) {
                    Bitmap bitmap = ScreenshotDisplay.decode(value, 1200);
                    if (bitmap != null) decoded.add(bitmap);
                }
                mainHandler.post(() -> {
                    if (isFinishing() || isDestroyed() || decoded.isEmpty()) return;
                    screenshotRow.removeAllViews();
                    screenshotCount.setText(decoded.size() + (decoded.size() == 1 ? " IMAGEM" : " IMAGENS"));
                    for (int i = 0; i < decoded.size(); i++) addScreenshotCard(decoded.get(i), i + 1);
                    screenshotSection.setVisibility(View.VISIBLE);
                });
            });
        });
    }

    private void addScreenshotCard(Bitmap bitmap, int number) {
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 5), StoreUi.dp(this, 5), StoreUi.dp(this, 5), StoreUi.dp(this, 5));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff354767));
        card.setElevation(StoreUi.dp(this, 5));
        ImageView preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(StoreUi.shape(0xff111927, StoreUi.dp(this, 15), 0));
        preview.setClipToOutline(true);
        preview.setImageBitmap(bitmap);
        card.addView(preview, new LinearLayout.LayoutParams(StoreUi.dp(this, 190), StoreUi.dp(this, 320)));
        TextView caption = StoreUi.text(this, "Captura " + number, 11, StoreUi.MUTED, false);
        caption.setGravity(Gravity.CENTER);
        caption.setPadding(0, StoreUi.dp(this, 4), 0, 0);
        card.addView(caption);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.rightMargin = StoreUi.dp(this, 10);
        screenshotRow.addView(card, params);
        card.setOnClickListener(view -> showScreenshot(bitmap, number));
    }

    private void showScreenshot(Bitmap bitmap, int number) {
        ImageView image = new ImageView(this);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageBitmap(bitmap);
        image.setMaxWidth(getResources().getDisplayMetrics().widthPixels - StoreUi.dp(this, 36));
        new AlertDialog.Builder(this).setTitle("Captura " + number)
                .setView(image).setPositiveButton("Fechar", null).show();
    }

    @Override protected void onDestroy() {
        screenshotWorker.shutdown();
        super.onDestroy();
    }

    private RatingBar ratingBar(boolean indicator) {
        RatingBar bar = new RatingBar(this);
        bar.setNumStars(5);
        bar.setStepSize(1f);
        bar.setIsIndicator(indicator);
        bar.setProgressTintList(ColorStateList.valueOf(StoreUi.GOLD));
        boolean lightTheme = StoreUi.isLightTheme(this);
        bar.setSecondaryProgressTintList(ColorStateList.valueOf(lightTheme ? 0xffdeca98 : 0xff75603a));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(lightTheme ? 0xffd7e0eb : 0xff3a465a));
        return bar;
    }

    private void loadReviews() {
        ApiClient.getReviews(this, item.id, (summary, error) -> {
            if (isFinishing()) return;
            reviewsList.removeAllViews();
            if (error != null || summary == null) {
                ratingSummary.setText("As avaliações não estão disponíveis agora.");
                reviewsList.addView(StoreUi.text(this, "Tente atualizar esta tela daqui a pouco.", 13, StoreUi.MUTED, false));
                return;
            }
            averageRating.setRating(summary.averageRating);
            ratingSummary.setText(String.format(Locale.getDefault(), "%.1f / 5  ·  %d avaliação(ões)",
                    summary.averageRating, summary.reviewCount));
            if (summary.reviews.isEmpty()) {
                TextView empty = StoreUi.text(this, "Ainda não há avaliações. Seja a primeira pessoa a avaliar!", 13, StoreUi.MUTED, false);
                empty.setPadding(StoreUi.dp(this, 3), StoreUi.dp(this, 2), 0, 0);
                reviewsList.addView(empty);
                return;
            }
            for (ApiClient.AppReview review : summary.reviews) addReviewCard(review);
        });
    }

    private void addReviewCard(ApiClient.AppReview review) {
        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 12), StoreUi.dp(this, 14), StoreUi.dp(this, 12));
        card.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 18), 0xff2b3a53));
        card.setElevation(StoreUi.dp(this, 6));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = StoreUi.dp(this, 9);
        reviewsList.addView(card, cardParams);

        LinearLayout heading = StoreUi.horizontal(this);
        heading.addView(StoreUi.text(this, review.reviewerName, 13, StoreUi.TEXT, true),
                new LinearLayout.LayoutParams(0, -2, 1));
        TextView stars = StoreUi.text(this, String.format(Locale.getDefault(), "★ %.1f", (float) review.rating),
                12, StoreUi.GOLD, true);
        heading.addView(stars);
        card.addView(heading);

        if (review.createdAt != null && review.createdAt.length() >= 10) {
            TextView date = StoreUi.text(this, review.createdAt.substring(0, 10), 10, StoreUi.MUTED, false);
            date.setPadding(0, StoreUi.dp(this, 3), 0, StoreUi.dp(this, 4));
            card.addView(date);
        }
        TextView comment = StoreUi.text(this, review.comment, 13, StoreUi.MUTED, false);
        comment.setLineSpacing(StoreUi.dp(this, 2), 1f);
        card.addView(comment);
    }

    private void submitReview() {
        String comment = reviewInput.getText().toString().trim();
        if (ApiClient.sessionToken(this).isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Entre na sua conta")
                    .setMessage("Você precisa entrar para publicar uma avaliação.")
                    .setNegativeButton("Agora não", null)
                    .setPositiveButton("Entrar", (dialog, which) -> startActivity(new Intent(this, LoginActivity.class)))
                    .show();
            return;
        }
        if (comment.length() < 3 || comment.length() > 500) {
            Toast.makeText(this, "Escreva uma avaliação de 3 a 500 caracteres.", Toast.LENGTH_LONG).show();
            return;
        }
        submitButton.setEnabled(false);
        ApiClient.submitReview(this, item.id, Math.round(ratingInput.getRating()), comment, (response, error) -> {
            if (isFinishing()) return;
            submitButton.setEnabled(true);
            if (error != null) {
                Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }
            reviewInput.setText("");
            Toast.makeText(this, "Sua avaliação foi publicada.", Toast.LENGTH_SHORT).show();
            loadReviews();
        });
    }
}
