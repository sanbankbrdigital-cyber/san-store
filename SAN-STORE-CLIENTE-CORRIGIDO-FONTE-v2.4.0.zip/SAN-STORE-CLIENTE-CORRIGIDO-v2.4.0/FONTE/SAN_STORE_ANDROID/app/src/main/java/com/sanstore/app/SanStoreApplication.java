package com.sanstore.app;

import android.app.Activity;
import android.app.Application;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

public final class SanStoreApplication extends Application {
    private final Handler main = new Handler(Looper.getMainLooper());
    private ConnectivityManager connectivity;
    private Activity foregroundActivity;
    private FrameLayout foregroundRoot;
    private OfflineNoticeView notice;
    private boolean offlineVisible;
    private final Runnable connectivityPoll = new Runnable() {
        @Override public void run() {
            if (foregroundActivity == null) return;
            refreshConnectivity();
            main.postDelayed(this, 4000);
        }
    };
    private final ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        @Override public void onAvailable(Network network) { queueConnectivityRefresh(); }
        @Override public void onLost(Network network) { queueConnectivityRefresh(); }
        @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) { queueConnectivityRefresh(); }
    };

    @Override public void onCreate() {
        super.onCreate();
        connectivity = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        registerNetworkMonitor();
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity activity, Bundle state) { }
            @Override public void onActivityStarted(Activity activity) { }
            @Override public void onActivityResumed(Activity activity) {
                StoreUi.refreshThemeIfChanged(activity);
                if (foregroundActivity != activity) removeNoticeImmediately();
                foregroundActivity = activity;
                main.removeCallbacks(connectivityPoll);
                refreshConnectivity();
                main.postDelayed(connectivityPoll, 4000);
            }
            @Override public void onActivityPaused(Activity activity) {
                if (foregroundActivity == activity) {
                    foregroundActivity = null;
                    main.removeCallbacks(connectivityPoll);
                    removeNoticeImmediately();
                }
            }
            @Override public void onActivityStopped(Activity activity) { }
            @Override public void onActivitySaveInstanceState(Activity activity, Bundle state) { }
            @Override public void onActivityDestroyed(Activity activity) {
                StoreUi.forgetTheme(activity);
                if (foregroundActivity == activity) {
                    foregroundActivity = null;
                    removeNoticeImmediately();
                }
            }
        });
    }

    private void registerNetworkMonitor() {
        if (connectivity == null || Build.VERSION.SDK_INT < 21) return;
        try {
            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            connectivity.registerNetworkCallback(request, networkCallback);
        } catch (RuntimeException ignored) { }
    }

    private void queueConnectivityRefresh() {
        main.post(this::refreshConnectivity);
    }

    private void refreshConnectivity() {
        if (foregroundActivity == null || foregroundActivity.isFinishing()) return;
        boolean online = hasValidatedInternet();
        if (online) hideNotice(); else showNotice();
    }

    private boolean hasValidatedInternet() {
        if (connectivity == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Network active = connectivity.getActiveNetwork();
                if (active == null) return false;
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(active);
                return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            }
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private void showNotice() {
        if (offlineVisible && notice != null && notice.getParent() == foregroundRoot) return;
        if (!(foregroundActivity.getWindow().getDecorView() instanceof FrameLayout)) return;
        FrameLayout root = (FrameLayout) foregroundActivity.getWindow().getDecorView();
        if (notice != null && notice.getParent() instanceof FrameLayout) {
            ((FrameLayout) notice.getParent()).removeView(notice);
        }
        offlineVisible = true;
        foregroundRoot = root;
        notice = new OfflineNoticeView(foregroundActivity);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        int side = dp(12);
        params.leftMargin = side;
        params.rightMargin = side;
        params.topMargin = statusBarHeight() + dp(8);
        root.addView(notice, params);
        notice.animateIn();
    }

    private void hideNotice() {
        offlineVisible = false;
        if (notice == null) return;
        OfflineNoticeView old = notice;
        notice = null;
        old.animateOut(() -> {
            if (old.getParent() instanceof FrameLayout) ((FrameLayout) old.getParent()).removeView(old);
        });
    }

    private void removeNoticeImmediately() {
        offlineVisible = false;
        if (notice != null && notice.getParent() instanceof FrameLayout) {
            ((FrameLayout) notice.getParent()).removeView(notice);
        }
        notice = null;
        foregroundRoot = null;
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
