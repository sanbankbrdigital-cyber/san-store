package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ForgotPasswordActivity extends Activity {
    private EditText email;
    private EditText newPassword;
    private EditText confirmPassword;
    private TextView status;
    private Button submit;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Recuperar senha", "Solicitação para o administrador", true);
        LinearLayout notice = StoreUi.vertical(this);
        notice.setPadding(StoreUi.dp(this, 16), StoreUi.dp(this, 15), StoreUi.dp(this, 16), StoreUi.dp(this, 15));
        notice.setBackground(StoreUi.gradient(0xff243959, 0xff172337, StoreUi.dp(this, 21), 0xff526d94));
        notice.setElevation(StoreUi.dp(this, 5));
        notice.addView(StoreUi.badge(this, "ALTERAÇÃO PROTEGIDA", 0xff2b3d61, 0xffd7e2ff));
        TextView explanation = StoreUi.text(this,
                "A solicitação será analisada no SAN STORE Admin. Sua senha atual continua funcionando até a aprovação; se for recusada, nada muda.",
                13, StoreUi.MUTED, false);
        explanation.setLineSpacing(StoreUi.dp(this, 3), 1f);
        explanation.setPadding(0, StoreUi.dp(this, 9), 0, 0);
        notice.addView(explanation);
        content.addView(notice);

        StoreUi.section(this, content, "Dados para localizar sua conta");
        StoreUi.label(this, "E-mail cadastrado na SAN STORE");
        email = StoreUi.input(this, "seuemail@sanstore.com", false);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        content.addView(email);

        StoreUi.label(this, "Nova senha desejada");
        newPassword = StoreUi.input(this, "8 a 10 caracteres", false);
        newPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        newPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        content.addView(newPassword);

        StoreUi.label(this, "Confirme a nova senha");
        confirmPassword = StoreUi.input(this, "Digite novamente", false);
        confirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirmPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        content.addView(confirmPassword);

        TextView rules = StoreUi.text(this, "Use maiúscula, minúscula, número e símbolo. A nova senha só entra em vigor se o administrador aprovar.",
                12, StoreUi.MUTED, false);
        rules.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 8), 0, StoreUi.dp(this, 5));
        content.addView(rules);
        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 8), 0, StoreUi.dp(this, 8));
        content.addView(status);
        submit = StoreUi.button(this, "Enviar solicitação", true);
        submit.setOnClickListener(v -> submitRequest());
        content.addView(submit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void submitRequest() {
        String address = email.getText().toString().trim().toLowerCase();
        String password = newPassword.getText().toString();
        if (!address.matches("^[a-z0-9][a-z0-9._+-]{0,63}@sanstore\\.com$")) {
            showError("Digite o e-mail @sanstore.com cadastrado na sua conta.");
            return;
        }
        if (!validPassword(password)) {
            showError("A senha deve ter 8 a 10 caracteres, com maiúscula, minúscula, número e símbolo.");
            return;
        }
        if (!password.equals(confirmPassword.getText().toString())) {
            showError("As senhas não conferem.");
            return;
        }
        setBusy(true);
        status.setText("Enviando solicitação para análise…");
        status.setTextColor(StoreUi.MUTED);
        ApiClient.requestPasswordReset(this, address, password, (message, error) -> {
            if (isFinishing()) return;
            setBusy(false);
            if (error != null) { showError(error.getMessage()); return; }
            status.setText(message + " A senha atual continua válida até a decisão.");
            status.setTextColor(StoreUi.GREEN);
            submit.setText("Solicitação enviada");
            submit.setEnabled(false);
            newPassword.setText("");
            confirmPassword.setText("");
        });
    }

    private boolean validPassword(String value) {
        if (value == null || value.length() < 8 || value.length() > 10) return false;
        boolean upper = false, lower = false, digit = false, special = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= 'A' && c <= 'Z') upper = true;
            else if (c >= 'a' && c <= 'z') lower = true;
            else if (c >= '0' && c <= '9') digit = true;
            else special = true;
        }
        return upper && lower && digit && special;
    }

    private void setBusy(boolean busy) {
        submit.setEnabled(!busy);
        submit.setText(busy ? "Enviando…" : "Enviar solicitação");
    }

    private void showError(String message) {
        status.setText(message == null || message.trim().isEmpty() ? "Não foi possível enviar. Tente novamente." : message);
        status.setTextColor(StoreUi.GOLD);
    }
}
