package com.sanstore.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Rounded SAN STORE panel for selecting and previewing screenshot galleries. */
public final class ScreenshotPanel {
    private static final ExecutorService DECODER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private final Activity activity;
    private final TextView count;
    private final TextView status;
    private final LinearLayout previews;
    public final LinearLayout view;
    public final Button chooseButton;

    public ScreenshotPanel(Activity activity, String title, String description, String buttonText) {
        this.activity = activity;
        view = StoreUi.vertical(activity);
        view.setPadding(StoreUi.dp(activity, 14), StoreUi.dp(activity, 14),
                StoreUi.dp(activity, 14), StoreUi.dp(activity, 14));
        view.setBackground(StoreUi.gradient(0xff223451, 0xff172337, StoreUi.dp(activity, 23), 0xff617a9d));
        view.setElevation(StoreUi.dp(activity, 6));

        LinearLayout heading = StoreUi.horizontal(activity);
        TextView icon = StoreUi.text(activity, "▧", 20, 0xffd7e2ff, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(StoreUi.shape(0xff2b3d61, StoreUi.dp(activity, 14), 0));
        heading.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(activity, 42), StoreUi.dp(activity, 42)));
        LinearLayout titles = StoreUi.vertical(activity);
        titles.setPadding(StoreUi.dp(activity, 10), 0, 0, 0);
        titles.addView(StoreUi.text(activity, title, 15, StoreUi.TEXT, true));
        TextView detail = StoreUi.text(activity, "GALERIA VISUAL · PNG", 9, StoreUi.BLUE, true);
        detail.setPadding(0, StoreUi.dp(activity, 2), 0, 0);
        titles.addView(detail);
        heading.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        count = StoreUi.badge(activity, "0 / 8", 0xff263d5e, 0xffd7e2ff);
        heading.addView(count);
        view.addView(heading);

        TextView help = StoreUi.text(activity, description, 12, StoreUi.MUTED, false);
        help.setLineSpacing(StoreUi.dp(activity, 2), 1f);
        help.setPadding(0, StoreUi.dp(activity, 10), 0, StoreUi.dp(activity, 10));
        view.addView(help);

        status = StoreUi.text(activity, "Suas capturas aparecerão aqui.", 11, StoreUi.MUTED, false);
        status.setPadding(StoreUi.dp(activity, 2), 0, 0, StoreUi.dp(activity, 7));
        view.addView(status);

        HorizontalScrollView scroll = new HorizontalScrollView(activity);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        previews = StoreUi.horizontal(activity);
        previews.setPadding(StoreUi.dp(activity, 2), StoreUi.dp(activity, 2), StoreUi.dp(activity, 8), StoreUi.dp(activity, 7));
        scroll.addView(previews, new HorizontalScrollView.LayoutParams(-2, -2));
        view.addView(scroll);
        addEmptyPreview();

        chooseButton = StoreUi.button(activity, buttonText, true);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(activity, 50));
        buttonParams.topMargin = StoreUi.dp(activity, 6);
        view.addView(chooseButton, buttonParams);
    }

    public void setProcessing() {
        status.setText("Convertendo e preparando suas capturas…");
        status.setTextColor(StoreUi.BLUE);
        count.setText("… / 8");
    }

    public void showCurrent(ArrayList<String> images) {
        showImages(images, "publicadas", StoreUi.MUTED);
    }

    public void showSelected(ArrayList<String> images) {
        showImages(images, "prontas para enviar", StoreUi.GREEN);
    }

    public void setMessage(String message, int color) {
        status.setText(message);
        status.setTextColor(color);
    }

    private void showImages(ArrayList<String> images, String qualifier, int color) {
        if (images == null || images.isEmpty()) {
            count.setText("0 / 8");
            status.setText("Suas capturas aparecerão aqui.");
            status.setTextColor(StoreUi.MUTED);
            previews.removeAllViews();
            addEmptyPreview();
            return;
        }
        ArrayList<String> safe = new ArrayList<>(images);
        count.setText(safe.size() + " / 8");
        status.setText(safe.size() + (safe.size() == 1 ? " captura " : " capturas ") + qualifier + " · deslize para ver");
        status.setTextColor(color);
        DECODER.execute(() -> {
            ArrayList<Bitmap> decoded = new ArrayList<>();
            for (String encoded : safe) {
                Bitmap bitmap = ScreenshotDisplay.decode(encoded, 520);
                if (bitmap != null) decoded.add(bitmap);
            }
            MAIN.post(() -> {
                if (activity.isFinishing() || activity.isDestroyed()) return;
                previews.removeAllViews();
                if (decoded.isEmpty()) { addEmptyPreview(); return; }
                for (int i = 0; i < decoded.size(); i++) addPreview(decoded.get(i), i + 1);
            });
        });
    }

    private void addPreview(Bitmap bitmap, int number) {
        LinearLayout tile = StoreUi.vertical(activity);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(StoreUi.dp(activity, 4), StoreUi.dp(activity, 4), StoreUi.dp(activity, 4), StoreUi.dp(activity, 4));
        tile.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(activity, 17), 0xff617a9d));
        tile.setElevation(StoreUi.dp(activity, 3));
        ImageView image = new ImageView(activity);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackground(StoreUi.shape(0xff111927, StoreUi.dp(activity, 12), 0));
        image.setClipToOutline(true);
        image.setImageBitmap(bitmap);
        tile.addView(image, new LinearLayout.LayoutParams(StoreUi.dp(activity, 78), StoreUi.dp(activity, 138)));
        TextView label = StoreUi.text(activity, "TELA " + number, 9, StoreUi.MUTED, true);
        label.setGravity(Gravity.CENTER);
        label.setPadding(0, StoreUi.dp(activity, 3), 0, 0);
        tile.addView(label);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.rightMargin = StoreUi.dp(activity, 8);
        previews.addView(tile, params);
    }

    private void addEmptyPreview() {
        LinearLayout empty = StoreUi.vertical(activity);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(StoreUi.dp(activity, 12), StoreUi.dp(activity, 10),
                StoreUi.dp(activity, 12), StoreUi.dp(activity, 10));
        empty.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(activity, 16), 0xff405570));
        TextView placeholder = StoreUi.text(activity, "▧", 24, StoreUi.BLUE, true);
        placeholder.setGravity(Gravity.CENTER);
        empty.addView(placeholder);
        TextView text = StoreUi.text(activity, "Prévia das telas", 10, StoreUi.MUTED, false);
        text.setGravity(Gravity.CENTER);
        empty.addView(text);
        previews.addView(empty, new LinearLayout.LayoutParams(StoreUi.dp(activity, 130), StoreUi.dp(activity, 144)));
    }
}
