package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.animation.AlphaAnimation;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ViewFlipper;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout content;
    private ViewFlipper carousel;
    private TextView carouselCaption;
    private TextView connection;
    private ArrayList<AppItem> apps = new ArrayList<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        StoreUi.prepareTheme(this);
        LinearLayout searchShortcut = buildPinnedSearchShortcut();
        content = StoreUi.screenWithBottomNavAndFixedToolbar(this, "SAN STORE", "Sua loja digital",
                false, "apps", searchShortcut);

        LinearLayout hero = StoreUi.vertical(this);
        hero.setPadding(StoreUi.dp(this, 19), StoreUi.dp(this, 19), StoreUi.dp(this, 19), StoreUi.dp(this, 20));
        hero.setBackground(StoreUi.gradient(0xff263b6d, 0xff17243d, StoreUi.dp(this, 26), 0xff344b78));
        hero.setElevation(StoreUi.dp(this, 8));

        LinearLayout brand = StoreUi.horizontal(this);
        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setImageResource(R.drawable.san_store_wordmark);
        logo.setBackground(StoreUi.shape(0xffffffff, StoreUi.dp(this, 14), 0));
        logo.setClipToOutline(true);
        brand.addView(logo, new LinearLayout.LayoutParams(StoreUi.dp(this, 205), StoreUi.dp(this, 116)));
        hero.addView(brand);

        TextView title = StoreUi.text(this, "Seu próximo app\ncomeça aqui.", 27, StoreUi.TEXT, true);
        title.setLineSpacing(StoreUi.dp(this, 1), 1f);
        title.setPadding(0, StoreUi.dp(this, 17), 0, 0);
        hero.addView(title);

        TextView subtitle = StoreUi.text(this, "Descubra aplicativos e jogos em um só lugar.", 14, 0xffc2cde2, false);
        subtitle.setPadding(0, StoreUi.dp(this, 9), 0, 0);
        hero.addView(subtitle);

        TextView trust = StoreUi.badge(this, "DOWNLOAD PELO ANDROID", 0x263d5b96, 0xffdce5ff);
        LinearLayout.LayoutParams trustParams = new LinearLayout.LayoutParams(-2, -2);
        trustParams.topMargin = StoreUi.dp(this, 15);
        hero.addView(trust, trustParams);
        content.addView(hero);

        connection = StoreUi.text(this, "Conectando ao catálogo…", 12, StoreUi.GOLD, true);
        connection.setPadding(StoreUi.dp(this, 13), StoreUi.dp(this, 10), StoreUi.dp(this, 13), StoreUi.dp(this, 10));
        connection.setBackground(StoreUi.shape(0xff211f1c, StoreUi.dp(this, 14), 0xff4b4030));
        connection.setElevation(StoreUi.dp(this, 4));
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = StoreUi.dp(this, 15);
        content.addView(connection, statusParams);

        LinearLayout accountCard = StoreUi.horizontal(this);
        accountCard.setPadding(StoreUi.dp(this, 12), StoreUi.dp(this, 11), StoreUi.dp(this, 13), StoreUi.dp(this, 11));
        accountCard.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        accountCard.setElevation(StoreUi.dp(this, 6));
        String accountName = ApiClient.sessionAccount(this);
        String initial = accountName.isEmpty() ? "S" : accountName.substring(0, 1).toUpperCase();
        TextView avatar = StoreUi.text(this, initial, 17, StoreUi.TEXT, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(StoreUi.gradient(0xff718dff, 0xff4f67ce, StoreUi.dp(this, 18), 0));
        accountCard.addView(avatar, new LinearLayout.LayoutParams(StoreUi.dp(this, 42), StoreUi.dp(this, 42)));
        LinearLayout accountInfo = StoreUi.vertical(this);
        accountInfo.setPadding(StoreUi.dp(this, 11), 0, StoreUi.dp(this, 5), 0);
        accountInfo.addView(StoreUi.text(this, accountName.isEmpty() ? "Conta ativa" : accountName, 14, StoreUi.TEXT, true));
        TextView accountEmail = StoreUi.text(this, ApiClient.sessionEmail(this), 11, StoreUi.MUTED, false);
        accountEmail.setSingleLine(true);
        accountEmail.setEllipsize(android.text.TextUtils.TruncateAt.END);
        accountInfo.addView(accountEmail);
        accountCard.addView(accountInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView manageAccount = StoreUi.text(this, "Minha conta  ›", 12, StoreUi.BLUE, true);
        manageAccount.setGravity(Gravity.CENTER);
        manageAccount.setPadding(StoreUi.dp(this, 8), StoreUi.dp(this, 8), 0, StoreUi.dp(this, 8));
        accountCard.addView(manageAccount, new LinearLayout.LayoutParams(-2, -2));
        accountCard.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        LinearLayout.LayoutParams accountCardParams = new LinearLayout.LayoutParams(-1, -2);
        accountCardParams.topMargin = StoreUi.dp(this, 11);
        content.addView(accountCard, accountCardParams);

        StoreUi.section(this, content, "Explore por categoria");
        LinearLayout categories = StoreUi.horizontal(this);
        addCategory(categories, "▣  Aplicativos", false, () -> category("App"));
        addCategory(categories, "◈  Jogos", true, () -> category("Game"));
        content.addView(categories);

        StoreUi.section(this, content, "Categorias populares");
        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setOverScrollMode(HorizontalScrollView.OVER_SCROLL_NEVER);
        LinearLayout categoryChips = StoreUi.horizontal(this);
        for (String value : AppCategories.VALUES) addSubcategoryChip(categoryChips, value);
        categoryScroll.addView(categoryChips, new HorizontalScrollView.LayoutParams(-2, -2));
        content.addView(categoryScroll, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 42)));

        StoreUi.section(this, content, "Mais opções");
        Button developer = StoreUi.button(this, "Área do desenvolvedor", false);
        developer.setOnClickListener(v -> startActivity(new Intent(this, DeveloperActivity.class)));
        content.addView(developer, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));
        Button downloads = StoreUi.button(this, "↓  Meus downloads", false);
        downloads.setOnClickListener(v -> startActivity(new Intent(this, DownloadsActivity.class)));
        LinearLayout.LayoutParams downloadsParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50));
        downloadsParams.topMargin = StoreUi.dp(this, 9);
        content.addView(downloads, downloadsParams);

        StoreUi.section(this, content, "Destaques da loja");
        carousel = new ViewFlipper(this);
        carousel.setFlipInterval(5_000);
        AlphaAnimation carouselIn = new AlphaAnimation(0f, 1f);
        carouselIn.setDuration(430L);
        carouselIn.setInterpolator(new DecelerateInterpolator());
        AlphaAnimation carouselOut = new AlphaAnimation(1f, 0f);
        carouselOut.setDuration(320L);
        carouselOut.setInterpolator(new DecelerateInterpolator());
        carousel.setInAnimation(carouselIn);
        carousel.setOutAnimation(carouselOut);
        carousel.setAutoStart(false);
        content.addView(carousel, new LinearLayout.LayoutParams(-1, -2));
        carouselCaption = StoreUi.text(this, "Apps publicados · troca automática a cada 5 segundos", 11, StoreUi.MUTED, false);
        carouselCaption.setGravity(Gravity.CENTER);
        carouselCaption.setPadding(0, StoreUi.dp(this, 8), 0, StoreUi.dp(this, 10));
        content.addView(carouselCaption);

        Button allApps = StoreUi.button(this, "Ver todos os aplicativos", false);
        allApps.setOnClickListener(v -> startActivity(new Intent(this, AppsActivity.class)));
        content.addView(allApps, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50)));
    }

    private LinearLayout buildPinnedSearchShortcut() {
        LinearLayout bar = StoreUi.horizontal(this);
        bar.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 4), StoreUi.dp(this, 14), StoreUi.dp(this, 4));
        bar.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 27), 0xff2b394f));
        bar.setElevation(StoreUi.dp(this, 5));
        bar.setClickable(true);
        bar.setFocusable(true);
        bar.setContentDescription("Abrir pesquisa de aplicativos e jogos");

        TextView icon = StoreUi.text(this, "⌕", 25, StoreUi.BLUE, false);
        icon.setGravity(Gravity.CENTER);
        bar.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(this, 32), -1));
        TextView hint = StoreUi.text(this, "Buscar aplicativos e jogos", 14, StoreUi.MUTED, false);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(0, -2, 1);
        hintParams.leftMargin = StoreUi.dp(this, 8);
        bar.addView(hint, hintParams);
        TextView arrow = StoreUi.text(this, "›", 25, StoreUi.MUTED, false);
        arrow.setGravity(Gravity.CENTER);
        bar.addView(arrow, new LinearLayout.LayoutParams(StoreUi.dp(this, 28), -1));
        StoreUi.setTouchFeedback(bar);
        bar.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        return bar;
    }

    private void addSubcategoryChip(LinearLayout row, String value) {
        TextView chip = StoreUi.text(this, value, 12, 0xffd7e2ff, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(StoreUi.dp(this, 13), 0, StoreUi.dp(this, 13), 0);
        chip.setBackground(StoreUi.shape(0xff1b2840, StoreUi.dp(this, 20), 0xff344767));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, StoreUi.dp(this, 36));
        params.rightMargin = StoreUi.dp(this, 8);
        row.addView(chip, params);
        chip.setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseCategoryActivity.class);
            intent.putExtra("subcategory", value);
            startActivity(intent);
        });
    }

    private void addCategory(LinearLayout row, String label, boolean alternate, Runnable action) {
        Button button = StoreUi.button(this, label, !alternate);
        button.setGravity(Gravity.CENTER);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, StoreUi.dp(this, 54), 1);
        if (row.getChildCount() > 0) params.leftMargin = StoreUi.dp(this, 9);
        row.addView(button, params);
    }

    private void refresh() {
        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            if (error == null) {
                apps = items;
                if (connection != null) {
                    connection.setText("●  Catálogo conectado");
                    connection.setTextColor(StoreUi.GREEN);
                    connection.setBackground(StoreUi.shape(0xff142a29, StoreUi.dp(this, 14), 0xff2c554e));
                    connection.setElevation(StoreUi.dp(this, 4));
                }
            } else {
                apps = new ArrayList<>();
                apps.add(AppItem.sanbank());
                if (connection != null) {
                    connection.setText("●  Catálogo temporariamente indisponível · destaque local");
                    connection.setTextColor(StoreUi.GOLD);
                }
            }
            renderList();
        });
    }

    private void renderList() {
        if (carousel == null) return;
        carousel.stopFlipping();
        carousel.removeAllViews();
        if (apps.isEmpty()) apps.add(AppItem.sanbank());

        ArrayList<AppItem> slides = new ArrayList<>();
        for (AppItem item : apps) {
            if (item.featured && slides.size() < 6) slides.add(item);
        }
        for (AppItem item : apps) {
            if (slides.size() >= 6) break;
            if (!slides.contains(item)) slides.add(item);
        }

        for (AppItem item : slides) {
            carousel.addView(StoreUi.appCard(this, item, () -> StoreUi.openDetails(this, item)),
                    new FrameLayout.LayoutParams(-1, -2));
        }
        carousel.setDisplayedChild(0);
        if (carouselCaption != null) {
            carouselCaption.setText(slides.size() > 1
                    ? slides.size() + " destaques · troca automática a cada 5 segundos"
                    : "Um destaque da SAN STORE");
        }
        if (slides.size() > 1) carousel.startFlipping();
    }

    private void category(String value) {
        startActivity(new Intent(this, "Game".equals(value) ? GamesActivity.class : AppsActivity.class));
    }

    @Override protected void onPause() {
        if (carousel != null) carousel.stopFlipping();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null) refresh();
    }
}
