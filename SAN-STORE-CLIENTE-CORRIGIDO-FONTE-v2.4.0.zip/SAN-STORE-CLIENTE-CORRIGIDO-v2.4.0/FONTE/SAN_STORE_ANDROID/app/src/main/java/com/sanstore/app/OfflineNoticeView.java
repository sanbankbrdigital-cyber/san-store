package com.sanstore.app;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Persistent, non-blocking offline banner with a gently floating astronaut. */
public final class OfflineNoticeView extends LinearLayout {
    private final AstronautView astronaut;
    private AnimatorSet floatAnimation;

    public OfflineNoticeView(Context context) {
        super(context);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        int pad = dp(context, 12);
        setPadding(pad, pad, pad, pad);
        setBackground(cardBackground(context));
        setElevation(dp(context, 12));
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription("SAN STORE: sem conexão com a internet. O aviso desaparecerá quando a conexão voltar.");

        FrameLayout space = new FrameLayout(context);
        GradientDrawable spaceBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff253e66, 0xff15243d});
        spaceBg.setCornerRadius(dp(context, 17));
        spaceBg.setStroke(dp(context, 1), 0xff536c92);
        space.setBackground(spaceBg);
        space.setClipToOutline(true);
        astronaut = new AstronautView(context);
        space.addView(astronaut, new FrameLayout.LayoutParams(-1, -1));
        addView(space, new LayoutParams(dp(context, 58), dp(context, 58)));

        LinearLayout words = new LinearLayout(context);
        words.setOrientation(VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        words.setPadding(dp(context, 11), dp(context, 1), dp(context, 4), dp(context, 1));
        TextView eyebrow = label(context, "SAN STORE   ·   OFFLINE", 9, 0xff92d9ff, true);
        words.addView(eyebrow);
        TextView title = label(context, "Sem conexão com a internet", 14, 0xfff4f7ff, true);
        title.setPadding(0, dp(context, 3), 0, 0);
        words.addView(title);
        TextView message = label(context, "Este aviso some quando a internet voltar.", 10, 0xffb9c6dc, false);
        message.setPadding(0, dp(context, 2), 0, 0);
        words.addView(message);
        addView(words, new LayoutParams(0, -2, 1f));

        TextView status = label(context, "SEM\nREDE", 8, 0xffffd58c, true);
        status.setGravity(Gravity.CENTER);
        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(0x332b4263);
        statusBg.setCornerRadius(dp(context, 12));
        statusBg.setStroke(dp(context, 1), 0x6696b8e2);
        status.setBackground(statusBg);
        status.setPadding(dp(context, 6), dp(context, 5), dp(context, 6), dp(context, 5));
        addView(status, new LayoutParams(-2, -2));
    }

    public void animateIn() {
        animate().cancel();
        setAlpha(0f);
        setTranslationY(-dp(getContext(), 12));
        animate().alpha(1f).translationY(0f).setDuration(280)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    public void animateOut(Runnable end) {
        animate().cancel();
        animate().alpha(0f).translationY(-dp(getContext(), 12)).setDuration(210)
                .setInterpolator(new AccelerateDecelerateInterpolator()).withEndAction(end).start();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ObjectAnimator drift = ObjectAnimator.ofFloat(astronaut, View.TRANSLATION_Y, 0f, -dp(getContext(), 3), 0f);
        ObjectAnimator tilt = ObjectAnimator.ofFloat(astronaut, View.ROTATION, -4f, 4f, -4f);
        drift.setDuration(2300);
        tilt.setDuration(3100);
        drift.setRepeatCount(ObjectAnimator.INFINITE);
        tilt.setRepeatCount(ObjectAnimator.INFINITE);
        drift.setInterpolator(new AccelerateDecelerateInterpolator());
        tilt.setInterpolator(new AccelerateDecelerateInterpolator());
        floatAnimation = new AnimatorSet();
        floatAnimation.playTogether(drift, tilt);
        floatAnimation.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (floatAnimation != null) floatAnimation.cancel();
        floatAnimation = null;
        super.onDetachedFromWindow();
    }

    private static GradientDrawable cardBackground(Context context) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff253858, 0xff172338, 0xff18243a});
        drawable.setCornerRadius(dp(context, 22));
        drawable.setStroke(dp(context, 1), 0xff6a83a9);
        return drawable;
    }

    private static TextView label(Context context, String text, float size, int color, boolean bold) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(false);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setMaxLines(2);
        return view;
    }

    private static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private static final class AstronautView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF shape = new RectF();
        private final Path path = new Path();

        AstronautView(Context context) { super(context); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scale = Math.min(getWidth(), getHeight()) / 100f;
            canvas.save();
            canvas.translate((getWidth() - 100f * scale) / 2f, (getHeight() - 100f * scale) / 2f);
            canvas.scale(scale, scale);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xffffd87b); canvas.drawCircle(13, 18, 2.2f, paint);
            paint.setColor(0xffb9eaff); canvas.drawCircle(86, 24, 1.8f, paint);
            paint.setColor(0xffffd87b); canvas.drawCircle(84, 82, 1.7f, paint);
            drawSparkle(canvas, 76, 13, 4, 0xffa9c9ff);
            drawSparkle(canvas, 17, 78, 3, 0xffa9c9ff);

            // Floating tether and pack
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(0xff91b7e5);
            path.reset(); path.moveTo(27, 67); path.cubicTo(17, 72, 20, 88, 10, 87); canvas.drawPath(path, paint);
            paint.setStyle(Paint.Style.FILL);
            shape.set(23, 53, 35, 72); paint.setColor(0xff9db6d9); canvas.drawRoundRect(shape, 4, 4, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f); paint.setColor(0xffe5efff); canvas.drawRoundRect(shape, 4, 4, paint);

            // Arms, legs and suit
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(8f); paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(0xffedf4ff);
            canvas.drawLine(37, 61, 27, 69, paint); canvas.drawLine(63, 61, 73, 54, paint);
            canvas.drawLine(43, 78, 39, 88, paint); canvas.drawLine(57, 78, 62, 87, paint);
            paint.setStyle(Paint.Style.FILL);
            shape.set(34, 53, 66, 82); paint.setColor(0xffeef4ff); canvas.drawRoundRect(shape, 9, 9, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.8f); paint.setColor(0xff9eb4d3); canvas.drawRoundRect(shape, 9, 9, paint);
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xff54b9dd); canvas.drawCircle(50, 66, 3.2f, paint);
            paint.setColor(0xff84d5ee); canvas.drawCircle(50, 74, 1.7f, paint);

            // Helmet and reflective visor
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xfff5f8ff); canvas.drawCircle(50, 37, 24, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setColor(0xff9eb4d3); canvas.drawCircle(50, 37, 24, paint);
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xff304c72);
            shape.set(34, 30, 66, 47); canvas.drawRoundRect(shape, 9, 9, paint);
            paint.setColor(0xff77dafa); shape.set(39, 33, 48, 35); canvas.drawRoundRect(shape, 2, 2, paint);
            paint.setColor(0xffe7f5ff); shape.set(46, 54, 54, 57); canvas.drawRoundRect(shape, 2, 2, paint);
            canvas.restore();
        }

        private void drawSparkle(Canvas canvas, float x, float y, float radius, int color) {
            paint.setStyle(Paint.Style.FILL); paint.setColor(color);
            path.reset(); path.moveTo(x, y-radius); path.quadTo(x+1, y-1, x+radius, y);
            path.quadTo(x+1, y+1, x, y+radius); path.quadTo(x-1, y+1, x-radius, y);
            path.quadTo(x-1, y-1, x, y-radius); canvas.drawPath(path, paint);
        }
    }
}
