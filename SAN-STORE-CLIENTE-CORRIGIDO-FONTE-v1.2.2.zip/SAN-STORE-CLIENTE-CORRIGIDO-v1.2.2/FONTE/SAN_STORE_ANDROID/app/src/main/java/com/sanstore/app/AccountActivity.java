package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class AccountActivity extends Activity {
    private Button logout;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screenWithBottomNav(this, "Minha conta", "Dados da sua conta SAN STORE", true, "profile");

        LinearLayout card = StoreUi.vertical(this);
        card.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18), StoreUi.dp(this, 18));
        card.setBackground(StoreUi.gradient(0xff202f4c, 0xff172337, StoreUi.dp(this, 23), 0xff354767));
        card.addView(StoreUi.badge(this, "SESSÃO ATIVA", 0xff174137, StoreUi.GREEN));

        TextView account = StoreUi.text(this, ApiClient.sessionAccount(this), 21, StoreUi.TEXT, true);
        account.setPadding(0, StoreUi.dp(this, 14), 0, 0);
        card.addView(account);

        TextView email = StoreUi.text(this, ApiClient.sessionEmail(this), 14, 0xffc2cde2, false);
        email.setPadding(0, StoreUi.dp(this, 5), 0, 0);
        card.addView(email);
        content.addView(card);

        StoreUi.section(this, content, "Aparência");
        LinearLayout appearance = StoreUi.vertical(this);
        appearance.setPadding(StoreUi.dp(this, 16), StoreUi.dp(this, 13), StoreUi.dp(this, 16), StoreUi.dp(this, 13));
        appearance.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        Switch themeToggle = new Switch(this);
        themeToggle.setText("Tema claro");
        themeToggle.setTextColor(StoreUi.TEXT);
        themeToggle.setTextSize(14);
        themeToggle.setChecked(StoreUi.isLightTheme(this));
        themeToggle.setThumbTintList(ColorStateList.valueOf(StoreUi.BLUE));
        themeToggle.setTrackTintList(ColorStateList.valueOf(StoreUi.isLightTheme(this) ? 0xffa8c9e8 : 0xff53627a));
        appearance.addView(themeToggle, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48)));
        TextView themeHelp = StoreUi.text(this, "Ative para usar o tema claro; desative para o tema escuro.", 12, StoreUi.MUTED, false);
        themeHelp.setPadding(0, StoreUi.dp(this, 2), 0, 0);
        appearance.addView(themeHelp);
        content.addView(appearance);
        themeToggle.setOnCheckedChangeListener((button, light) -> {
            StoreUi.saveLightTheme(this, light);
            Toast.makeText(this, light ? "Tema claro ativado" : "Tema escuro ativado", Toast.LENGTH_SHORT).show();
            recreate();
        });

        StoreUi.section(this, content, "Segurança");
        content.addView(StoreUi.text(this,
                "A senha não é guardada no aplicativo. Ao sair, a sessão deste aparelho será encerrada no servidor.",
                13, StoreUi.MUTED, false));

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 12), 0, StoreUi.dp(this, 4));
        content.addView(status);

        logout = StoreUi.button(this, "Sair da conta", false);
        logout.setOnClickListener(v -> signOut());
        content.addView(logout, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void signOut() {
        logout.setEnabled(false);
        logout.setText("Encerrando sessão…");
        ApiClient.logout(this, (done, error) -> {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
