package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout content;
    private android.widget.ViewFlipper carousel;
    private TextView carouselCaption;
    private TextView connection;
    private TextView allAppsSummary;
    private LinearLayout catalogFilters;
    private LinearLayout allAppsList;
    private String catalogFilter = "all";
    private boolean catalogLoaded;
    private boolean catalogError;
    private int catalogShown = 20;
    private ArrayList<AppItem> apps = new ArrayList<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        render();
    }

    private void render() {
        StoreUi.prepareTheme(this);
        LinearLayout searchShortcut = buildPinnedSearchShortcut();
        content = StoreUi.screenWithBottomNavAndFixedToolbar(this, "SAN STORE", "Sua loja digital",
                false, "apps", searchShortcut);

        LinearLayout hero = StoreUi.vertical(this);
        hero.setPadding(StoreUi.dp(this, 19), StoreUi.dp(this, 19), StoreUi.dp(this, 19), StoreUi.dp(this, 20));
        hero.setBackground(StoreUi.gradient(0xff263b6d, 0xff17243d, StoreUi.dp(this, 26), 0xff344b78));
        hero.setElevation(StoreUi.dp(this, 8));
        LinearLayout brand = StoreUi.horizontal(this);
        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setImageResource(R.drawable.san_store_wordmark);
        logo.setBackground(StoreUi.shape(0xffffffff, StoreUi.dp(this, 14), 0));
        logo.setClipToOutline(true);
        brand.addView(logo, new LinearLayout.LayoutParams(StoreUi.dp(this, 205), StoreUi.dp(this, 116)));
        hero.addView(brand);
        TextView title = StoreUi.text(this, "Seu próximo app\ncomeça aqui.", 27, StoreUi.TEXT, true);
        title.setLineSpacing(StoreUi.dp(this, 1), 1f);
        title.setPadding(0, StoreUi.dp(this, 17), 0, 0);
        hero.addView(title);
        TextView subtitle = StoreUi.text(this, "Descubra aplicativos e jogos em um só lugar.", 14, 0xffc2cde2, false);
        subtitle.setPadding(0, StoreUi.dp(this, 9), 0, 0);
        hero.addView(subtitle);
        TextView trust = StoreUi.badge(this, "DOWNLOAD PELO ANDROID", 0x263d5b96, 0xffdce5ff);
        LinearLayout.LayoutParams trustParams = new LinearLayout.LayoutParams(-2, -2);
        trustParams.topMargin = StoreUi.dp(this, 15);
        hero.addView(trust, trustParams);
        content.addView(hero);

        connection = StoreUi.text(this, "Conectando ao catálogo…", 12, StoreUi.GOLD, true);
        connection.setPadding(StoreUi.dp(this, 13), StoreUi.dp(this, 10), StoreUi.dp(this, 13), StoreUi.dp(this, 10));
        connection.setBackground(StoreUi.shape(0xff211f1c, StoreUi.dp(this, 14), 0xff4b4030));
        connection.setElevation(StoreUi.dp(this, 4));
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = StoreUi.dp(this, 15);
        content.addView(connection, statusParams);

        LinearLayout accountCard = StoreUi.horizontal(this);
        accountCard.setPadding(StoreUi.dp(this, 12), StoreUi.dp(this, 11), StoreUi.dp(this, 13), StoreUi.dp(this, 11));
        accountCard.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        accountCard.setElevation(StoreUi.dp(this, 6));
        String accountName = ApiClient.sessionAccount(this);
        String initial = accountName.isEmpty() ? "S" : accountName.substring(0, 1).toUpperCase();
        TextView avatar = StoreUi.text(this, initial, 17, StoreUi.TEXT, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(StoreUi.gradient(0xff718dff, 0xff4f67ce, StoreUi.dp(this, 18), 0));
        accountCard.addView(avatar, new LinearLayout.LayoutParams(StoreUi.dp(this, 42), StoreUi.dp(this, 42)));
        LinearLayout accountInfo = StoreUi.vertical(this);
        accountInfo.setPadding(StoreUi.dp(this, 11), 0, StoreUi.dp(this, 5), 0);
        accountInfo.addView(StoreUi.text(this, accountName.isEmpty() ? "Conta ativa" : accountName, 14, StoreUi.TEXT, true));
        TextView accountEmail = StoreUi.text(this, ApiClient.sessionEmail(this), 11, StoreUi.MUTED, false);
        accountEmail.setSingleLine(true);
        accountEmail.setEllipsize(android.text.TextUtils.TruncateAt.END);
        accountInfo.addView(accountEmail);
        accountCard.addView(accountInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView manageAccount = StoreUi.text(this, "Minha conta  ›", 12, StoreUi.BLUE, true);
        manageAccount.setGravity(Gravity.CENTER);
        manageAccount.setPadding(StoreUi.dp(this, 8), StoreUi.dp(this, 8), 0, StoreUi.dp(this, 8));
        accountCard.addView(manageAccount, new LinearLayout.LayoutParams(-2, -2));
        accountCard.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        LinearLayout.LayoutParams accountCardParams = new LinearLayout.LayoutParams(-1, -2);
        accountCardParams.topMargin = StoreUi.dp(this, 11);
        content.addView(accountCard, accountCardParams);

        renderCatalogSection(content);

        StoreUi.section(this, content, "Explore por categoria");
        LinearLayout categories = StoreUi.horizontal(this);
        addCategory(categories, "▣  Aplicativos", false, () -> category("App"));
        addCategory(categories, "◈  Jogos", true, () -> category("Game"));
        content.addView(categories);

        StoreUi.section(this, content, "Categorias populares");
        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setOverScrollMode(HorizontalScrollView.OVER_SCROLL_NEVER);
        LinearLayout categoryChips = StoreUi.horizontal(this);
        for (String value : AppCategories.VALUES) addSubcategoryChip(categoryChips, value);
        categoryScroll.addView(categoryChips, new HorizontalScrollView.LayoutParams(-2, -2));
        content.addView(categoryScroll, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 42)));

        StoreUi.section(this, content, "Destaques da loja");
        carousel = new android.widget.ViewFlipper(this);
        carousel.setFlipInterval(5_000);
        carousel.setAutoStart(false);
        content.addView(carousel, new LinearLayout.LayoutParams(-1, -2));
        carouselCaption = StoreUi.text(this, "Destaques da SAN STORE", 11, StoreUi.MUTED, false);
        carouselCaption.setGravity(Gravity.CENTER);
        carouselCaption.setPadding(0, StoreUi.dp(this, 8), 0, StoreUi.dp(this, 10));
        content.addView(carouselCaption);

        StoreUi.section(this, content, "Mais opções");
        Button developer = StoreUi.button(this, "Área do desenvolvedor", false);
        developer.setOnClickListener(v -> startActivity(new Intent(this, DeveloperActivity.class)));
        content.addView(developer, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));
        Button downloads = StoreUi.button(this, "↓  Meus downloads", false);
        downloads.setOnClickListener(v -> startActivity(new Intent(this, DownloadsActivity.class)));
        LinearLayout.LayoutParams downloadsParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 50));
        downloadsParams.topMargin = StoreUi.dp(this, 9);
        content.addView(downloads, downloadsParams);
    }

    private void renderCatalogSection(LinearLayout parent) {
        StoreUi.section(this, parent, "Todos os aplicativos e jogos");
        TextView subtitle = StoreUi.text(this, "Catálogo completo · toque em um app para ver detalhes", 12, StoreUi.MUTED, false);
        subtitle.setPadding(StoreUi.dp(this, 2), 0, 0, StoreUi.dp(this, 9));
        parent.addView(subtitle);
        catalogFilters = StoreUi.horizontal(this);
        catalogFilters.setPadding(0, 0, 0, StoreUi.dp(this, 5));
        parent.addView(catalogFilters);
        addCatalogFilter("Todos", "all");
        addCatalogFilter("Apps", "App");
        addCatalogFilter("Jogos", "Game");
        allAppsSummary = StoreUi.text(this, "Carregando catálogo…", 12, StoreUi.MUTED, false);
        allAppsSummary.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 8), 0, StoreUi.dp(this, 10));
        parent.addView(allAppsSummary);
        allAppsList = StoreUi.vertical(this);
        parent.addView(allAppsList);
    }

    private void addCatalogFilter(String title, String value) {
        TextView chip = StoreUi.text(this, title, 12, "all".equals(catalogFilter) && "all".equals(value) || catalogFilter.equals(value)
                ? 0xffdff6f0 : StoreUi.MUTED, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 8), StoreUi.dp(this, 14), StoreUi.dp(this, 8));
        chip.setBackground(StoreUi.shape(catalogFilter.equals(value) ? 0xff174137 : StoreUi.CARD_ALT,
                StoreUi.dp(this, 18), catalogFilter.equals(value) ? 0xff3c8b76 : 0xff344767));
        chip.setClickable(true);
        chip.setFocusable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, StoreUi.dp(this, 36));
        params.rightMargin = StoreUi.dp(this, 8);
        catalogFilters.addView(chip, params);
        chip.setOnClickListener(v -> {
            catalogFilter = value;
            catalogShown = 20;
            renderCatalogFilters();
            renderAllApps();
        });
    }

    private void renderCatalogFilters() {
        if (catalogFilters == null) return;
        catalogFilters.removeAllViews();
        addCatalogFilter("Todos", "all");
        addCatalogFilter("Apps", "App");
        addCatalogFilter("Jogos", "Game");
    }

    private void renderAllApps() {
        if (allAppsList == null) return;
        allAppsList.removeAllViews();
        int visible = 0;
        int rendered = 0;
        for (AppItem item : apps) {
            if (!"all".equals(catalogFilter) && !catalogFilter.equals(item.category)) continue;
            visible++;
            if (rendered < catalogShown) {
                allAppsList.addView(StoreUi.appCard(this, item, () -> StoreUi.openDetails(this, item)));
                rendered++;
            }
        }
        if (allAppsSummary == null) return;
        if (!catalogLoaded) {
            allAppsSummary.setText("Carregando catálogo…");
        } else if (catalogError) {
            allAppsSummary.setText("Não foi possível carregar o catálogo. Verifique sua conexão e tente novamente.");
            TextView retry = StoreUi.text(this, "↻  Tentar novamente", 13, StoreUi.BLUE, true);
            retry.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 2), 0, StoreUi.dp(this, 12));
            retry.setClickable(true);
            retry.setFocusable(true);
            allAppsList.addView(retry);
            retry.setOnClickListener(v -> { catalogLoaded = false; renderAllApps(); refresh(); });
        } else if (visible == 0) {
            String emptyType = "all".equals(catalogFilter) ? "aplicativos ou jogos" : "Game".equals(catalogFilter) ? "jogo" : "aplicativo";
            allAppsSummary.setText("Nenhum " + emptyType + " disponível nesta categoria ainda.");
            TextView empty = StoreUi.text(this, "Os itens publicados aparecerão aqui.", 13, StoreUi.MUTED, false);
            empty.setPadding(StoreUi.dp(this, 2), StoreUi.dp(this, 2), 0, StoreUi.dp(this, 12));
            allAppsList.addView(empty);
        } else {
            String suffix = "all".equals(catalogFilter) ? "itens" : "Game".equals(catalogFilter) ? "jogos" : "apps";
            allAppsSummary.setText(visible + " " + suffix + " na loja" + (rendered < visible ? " · exibindo " + rendered : ""));
            if (rendered < visible) {
                Button more = StoreUi.button(this, "Mostrar mais (" + (visible - rendered) + ")", false);
                LinearLayout.LayoutParams moreParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 48));
                moreParams.topMargin = StoreUi.dp(this, 8);
                allAppsList.addView(more, moreParams);
                more.setOnClickListener(v -> { catalogShown += 20; renderAllApps(); });
            }
        }
    }

    private LinearLayout buildPinnedSearchShortcut() {
        LinearLayout bar = StoreUi.horizontal(this);
        bar.setPadding(StoreUi.dp(this, 14), StoreUi.dp(this, 4), StoreUi.dp(this, 14), StoreUi.dp(this, 4));
        bar.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 27), 0xff2b394f));
        bar.setElevation(StoreUi.dp(this, 5));
        bar.setClickable(true);
        bar.setFocusable(true);
        bar.setContentDescription("Abrir pesquisa de aplicativos e jogos");
        TextView icon = StoreUi.text(this, "⌕", 25, StoreUi.BLUE, false);
        icon.setGravity(Gravity.CENTER);
        bar.addView(icon, new LinearLayout.LayoutParams(StoreUi.dp(this, 32), -1));
        TextView hint = StoreUi.text(this, "Buscar aplicativos e jogos", 14, StoreUi.MUTED, false);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(0, -2, 1);
        hintParams.leftMargin = StoreUi.dp(this, 8);
        bar.addView(hint, hintParams);
        TextView arrow = StoreUi.text(this, "›", 25, StoreUi.MUTED, false);
        arrow.setGravity(Gravity.CENTER);
        bar.addView(arrow, new LinearLayout.LayoutParams(StoreUi.dp(this, 28), -1));
        StoreUi.setTouchFeedback(bar);
        bar.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        return bar;
    }

    private void addSubcategoryChip(LinearLayout row, String value) {
        TextView chip = StoreUi.text(this, value, 12, 0xffd7e2ff, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(StoreUi.dp(this, 13), 0, StoreUi.dp(this, 13), 0);
        chip.setBackground(StoreUi.shape(0xff1b2840, StoreUi.dp(this, 20), 0xff344767));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, StoreUi.dp(this, 36));
        params.rightMargin = StoreUi.dp(this, 8);
        row.addView(chip, params);
        chip.setOnClickListener(v -> {
            Intent intent = new Intent(this, BrowseCategoryActivity.class);
            intent.putExtra("subcategory", value);
            startActivity(intent);
        });
    }

    private void addCategory(LinearLayout row, String label, boolean alternate, Runnable action) {
        Button button = StoreUi.button(this, label, !alternate);
        button.setGravity(Gravity.CENTER);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, StoreUi.dp(this, 54), 1);
        if (row.getChildCount() > 0) params.leftMargin = StoreUi.dp(this, 9);
        row.addView(button, params);
    }

    private void refresh() {
        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            catalogLoaded = true;
            catalogError = error != null;
            if (error == null) {
                apps = items == null ? new ArrayList<>() : items;
                if (connection != null) {
                    connection.setText("●  Catálogo conectado · " + apps.size() + " itens");
                    connection.setTextColor(StoreUi.GREEN);
                    connection.setBackground(StoreUi.shape(0xff142a29, StoreUi.dp(this, 14), 0xff2c554e));
                }
            } else {
                apps = new ArrayList<>();
                if (connection != null) {
                    connection.setText("●  Catálogo temporariamente indisponível · verifique sua conexão");
                    connection.setTextColor(StoreUi.GOLD);
                }
            }
            renderList();
        });
    }

    private void renderList() {
        if (carousel == null) return;
        carousel.stopFlipping();
        carousel.removeAllViews();
        ArrayList<AppItem> slides = new ArrayList<>();
        for (AppItem item : apps) if (item.featured && slides.size() < 6) slides.add(item);
        for (AppItem item : apps) {
            if (slides.size() >= 6) break;
            if (!slides.contains(item)) slides.add(item);
        }
        for (AppItem item : slides) {
            carousel.addView(StoreUi.appCard(this, item, () -> StoreUi.openDetails(this, item)),
                    new android.widget.FrameLayout.LayoutParams(-1, -2));
        }
        if (!slides.isEmpty()) carousel.setDisplayedChild(0);
        if (carouselCaption != null) {
            carouselCaption.setText(slides.size() > 1
                    ? slides.size() + " destaques · troca automática a cada 5 segundos"
                    : slides.isEmpty() ? "Nenhum destaque disponível" : "Destaque da SAN STORE");
        }
        if (slides.size() > 1) carousel.startFlipping();
        renderAllApps();
    }

    private void category(String value) {
        startActivity(new Intent(this, "Game".equals(value) ? GamesActivity.class : AppsActivity.class));
    }

    @Override protected void onPause() {
        if (carousel != null) carousel.stopFlipping();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null) refresh();
    }
}
