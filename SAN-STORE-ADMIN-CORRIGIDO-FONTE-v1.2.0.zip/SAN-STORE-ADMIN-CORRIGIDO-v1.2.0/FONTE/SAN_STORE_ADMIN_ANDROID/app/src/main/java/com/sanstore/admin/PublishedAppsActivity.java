package com.sanstore.admin;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import org.json.JSONObject;

public class PublishedAppsActivity extends Activity {
    private LinearLayout list;
    private TextView state;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        list = AdminUi.screen(this, "Aplicativos na loja", "Confira quem publicou cada item", true);
        Button refresh = AdminUi.button(this, "Atualizar lista", false);
        list.addView(refresh);
        state = AdminUi.text(this, "Carregando…", 13, AdminUi.MUTED, false);
        state.setPadding(0, AdminUi.dp(this, 12), 0, 0);
        list.addView(state);
        refresh.setOnClickListener(v -> load());
        load();
    }

    private void load() {
        AdminApi.call(this, "GET", "/api/admin/submissions?status=approved", null, (code, object, items, error) -> {
            if (code != 200 || items == null) {
                state.setText(error != null ? error : AdminApi.message(object, "Não foi possível carregar os aplicativos publicados."));
                return;
            }
            list.removeViews(2, Math.max(0, list.getChildCount() - 2));
            if (items.length() == 0) {
                state.setText("Ainda não há aplicativos publicados pela administração.");
                return;
            }
            state.setText(items.length() + " aplicativo(s) aprovado(s)");
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                LinearLayout card = AdminUi.card(this);
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
                cardParams.topMargin = AdminUi.dp(this, 12);
                list.addView(card, cardParams);
                card.addView(AdminUi.text(this, item.optString("name", "Sem nome"), 17, AdminUi.TEXT, true));
                String publisher = item.optString("developerName", "").trim();
                if (publisher.isEmpty()) publisher = item.optString("developerAccount", "Publicador não informado");
                TextView meta = AdminUi.text(this,
                        "Publicado por: " + publisher + " · " + item.optString("category", "App"),
                        12, AdminUi.MUTED, false);
                meta.setPadding(0, AdminUi.dp(this, 6), 0, 0);
                card.addView(meta);
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null) load();
    }
}
