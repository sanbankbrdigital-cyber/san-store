package com.sanstore.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdminDashboardActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AdminApi.call(this, "GET", "/api/admin/me", null, (code, object, array, error) -> {
            if (code != 200) {
                AdminApi.clear(this);
                startActivity(new Intent(this, AdminLoginActivity.class));
                finish();
                return;
            }
            String account = "Administrador";
            if (object != null && object.optJSONObject("user") != null) {
                account = object.optJSONObject("user").optString("account", "Administrador");
            }
            show(account);
        });
    }

    private void show(String account) {
        LinearLayout content = AdminUi.screen(this, "Painel SAN STORE", "Administração da loja · " + account, false);
        AdminUi.section(this, content, "Moderação e gestão");
        TextView info = AdminUi.text(this,
                "Novos envios permanecem privados até a aprovação. Confira também quem publicou cada aplicativo que já está na loja.",
                13, AdminUi.MUTED, false);
        content.addView(info);
        AdminUi.gap(this, content, 18);

        Button pending = AdminUi.button(this, "Publicações pendentes", true);
        content.addView(pending);
        AdminUi.gap(this, content, 12);

        Button published = AdminUi.button(this, "Aplicativos publicados · ver publicador", false);
        content.addView(published);
        AdminUi.gap(this, content, 12);

        Button developers = AdminUi.button(this, "Desenvolvedores", false);
        content.addView(developers);
        AdminUi.gap(this, content, 26);

        Button logout = AdminUi.button(this, "Sair da conta", false);
        content.addView(logout);
        pending.setOnClickListener(v -> startActivity(new Intent(this, PendingSubmissionsActivity.class)));
        published.setOnClickListener(v -> startActivity(new Intent(this, PublishedAppsActivity.class)));
        developers.setOnClickListener(v -> startActivity(new Intent(this, DevelopersActivity.class)));
        logout.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Encerrar sessão?")
                .setMessage("O token será revogado no servidor e removido deste aparelho.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Sair", (dialog, which) -> AdminApi.logout(this, () -> {
                    startActivity(new Intent(this, AdminLoginActivity.class));
                    finish();
                })).show());
    }
}
