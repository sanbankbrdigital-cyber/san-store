package com.sanstore.app;

import org.json.JSONObject;

public class AppItem {
    public String id;
    public String name;
    public String category;
    public String subcategory;
    public String image;
    public String apk;
    public String description;
    public String whatsNew;
    public boolean featured;
    public String developerName;
    public boolean blocked;
    public String blockReason;

    public AppItem(String id, String name, String category, String image, String apk, String description, boolean featured) {
        this(id, name, category, image, apk, description, featured, "Publicador não informado", "");
    }

    public AppItem(String id, String name, String category, String image, String apk, String description,
                   boolean featured, String developerName) {
        this(id, name, category, image, apk, description, featured, developerName, "");
    }

    public AppItem(String id, String name, String category, String image, String apk, String description,
                   boolean featured, String developerName, String subcategory) {
        this(id, name, category, image, apk, description, featured, developerName, subcategory, "");
    }

    public AppItem(String id, String name, String category, String image, String apk, String description,
                   boolean featured, String developerName, String subcategory, String whatsNew) {
        this(id, name, category, image, apk, description, featured, developerName, subcategory, whatsNew, false, "");
    }

    public AppItem(String id, String name, String category, String image, String apk, String description,
                   boolean featured, String developerName, String subcategory, String whatsNew,
                   boolean blocked, String blockReason) {
        this.id = id == null ? "" : id;
        this.name = name == null ? "" : name;
        this.category = category == null ? "App" : category;
        this.subcategory = subcategory == null ? "" : subcategory.trim();
        this.image = image == null ? "" : image;
        this.apk = apk == null ? "" : apk;
        this.description = description == null ? "" : description;
        this.whatsNew = whatsNew == null ? "" : whatsNew.trim();
        this.featured = featured;
        this.developerName = developerName == null || developerName.trim().isEmpty()
                ? "Publicador não informado" : developerName.trim();
        this.blocked = blocked;
        this.blockReason = blockReason == null ? "" : blockReason.trim();
    }

    public static AppItem fromJson(JSONObject o) {
        return new AppItem(o.optString("id"), o.optString("name"), o.optString("category", "App"),
                o.optString("image"), o.optString("apk"), o.optString("description"),
                o.optBoolean("featured", false), o.optString("developerName", "Publicador não informado"),
                o.optString("subcategory", ""), o.optString("whatsNew", ""),
                o.optBoolean("blocked", false), o.optString("blockReason", ""));
    }

    public static AppItem sanbank() {
        return new AppItem("sanbank-br-digital", "SANBANK BR DIGITAL", "App",
                "https://i.ibb.co/Ld27J25H/shared-image-3.webp",
                "https://github.com/sanbankbrdigital-cyber/san-store/raw/refs/heads/main/SANBANK-BR-DIGITAL-NATIVO-COMPLETO-v3.1.51-sem-top-interbank-icon-ANDROID-5.0-A-17.apk",
                "Aplicativo SANBANK BR DIGITAL para Android. Baixe e conheça os recursos do seu banco digital.", true,
                "Publicador não informado", "Finanças");
    }
}
