package com.sanstore.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.BitmapFactory;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class StoreUi {
    private static final String THEME_PREFS = "san_store_appearance";
    private static final String THEME_KEY = "theme_mode";
    private static final int DARK_BG = Color.rgb(9, 13, 22);
    private static final int DARK_CARD = Color.rgb(18, 26, 40);
    private static final int DARK_CARD_ALT = Color.rgb(27, 38, 57);
    private static final int DARK_TEXT = Color.rgb(245, 248, 255);
    private static final int DARK_MUTED = Color.rgb(165, 177, 198);
    private static final int DARK_BLUE = Color.rgb(123, 151, 255);
    private static final int DARK_GREEN = Color.rgb(104, 226, 184);
    private static final int DARK_GOLD = Color.rgb(255, 203, 126);
    private static final int DARK_BORDER = Color.rgb(43, 57, 79);
    private static final int NAV_BG = 0xffeef2f7;
    private static final int NAV_ACTIVE_BG = 0xffc9e8fc;
    private static final int NAV_ACTIVE = 0xff075f95;
    private static final int NAV_INACTIVE = 0xff515b66;
    private static boolean lightThemeActive;
    public static int BG = DARK_BG;
    public static int CARD = DARK_CARD;
    public static int CARD_ALT = DARK_CARD_ALT;
    public static int TEXT = DARK_TEXT;
    public static int MUTED = DARK_MUTED;
    public static int BLUE = DARK_BLUE;
    public static int GREEN = DARK_GREEN;
    public static int GOLD = DARK_GOLD;
    private static int BORDER = DARK_BORDER;
    private static final ExecutorService IMAGES = Executors.newFixedThreadPool(3);
    private static final Map<Activity, LoadingState> LOADERS = new WeakHashMap<>();
    private static final Map<Activity, Boolean> RENDERED_THEMES = new WeakHashMap<>();
    private static final Map<Activity, Integer> CARD_ENTRY_COUNTS = new WeakHashMap<>();

    private static final class LoadingState {
        int requests;
        Dialog dialog;
    }

    private StoreUi() {}

    public static boolean isLightTheme(Activity activity) {
        return "light".equals(activity.getSharedPreferences(THEME_PREFS, Activity.MODE_PRIVATE).getString(THEME_KEY, "dark"));
    }

    public static void prepareTheme(Activity activity) {
        applyPalette(activity);
    }

    public static void saveLightTheme(Activity activity, boolean light) {
        activity.getSharedPreferences(THEME_PREFS, Activity.MODE_PRIVATE).edit()
                .putString(THEME_KEY, light ? "light" : "dark").apply();
    }

    private static void applyPalette(Activity activity) {
        lightThemeActive = isLightTheme(activity);
        if (lightThemeActive) {
            BG = 0xffedf3fa;
            CARD = 0xfff8fbff;
            CARD_ALT = 0xffe8f0fa;
            TEXT = 0xff182338;
            MUTED = 0xff596a83;
            BLUE = 0xff306fda;
            GREEN = 0xff167a64;
            GOLD = 0xff986900;
            BORDER = 0xffb9cbe2;
        } else {
            BG = DARK_BG;
            CARD = DARK_CARD;
            CARD_ALT = DARK_CARD_ALT;
            TEXT = DARK_TEXT;
            MUTED = DARK_MUTED;
            BLUE = DARK_BLUE;
            GREEN = DARK_GREEN;
            GOLD = DARK_GOLD;
            BORDER = DARK_BORDER;
        }
        synchronized (RENDERED_THEMES) { RENDERED_THEMES.put(activity, lightThemeActive); }
        synchronized (CARD_ENTRY_COUNTS) { CARD_ENTRY_COUNTS.put(activity, 0); }
    }

    public static void refreshThemeIfChanged(Activity activity) {
        boolean current = isLightTheme(activity);
        Boolean rendered;
        synchronized (RENDERED_THEMES) { rendered = RENDERED_THEMES.get(activity); }
        if (rendered != null && rendered != current && !activity.isFinishing() && !activity.isDestroyed()) {
            activity.recreate();
        }
    }

    public static void forgetTheme(Activity activity) {
        synchronized (RENDERED_THEMES) { RENDERED_THEMES.remove(activity); }
    }

    private static int themedBackgroundColor(int color) {
        if (!lightThemeActive) return color;
        int rgb = color & 0x00ffffff;
        int replacement;
        switch (rgb) {
            case 0x090d16: replacement = 0xfff4f6fa; break;
            case 0x121a28: replacement = 0xffffffff; break;
            case 0x1b2639: replacement = 0xffe9eff7; break;
            case 0x151e2d: replacement = 0xfff2f5fa; break;
            case 0x0e1420: replacement = 0xfffafcfe; break;
            case 0x263b6d: replacement = 0xffdce8f8; break;
            case 0x17243d: replacement = 0xffeaf0f8; break;
            case 0x344b78: replacement = 0xffc4d1e2; break;
            case 0x202f4c: replacement = 0xffdfeaf7; break;
            case 0x202c45: replacement = 0xffe5edf7; break;
            case 0x172337: replacement = 0xffeaf0f7; break;
            case 0x354767: replacement = 0xffc8d4e4; break;
            case 0x263046: replacement = 0xffe4eaf2; break;
            case 0x2b3a53: replacement = 0xffccd6e3; break;
            case 0x222f4a: replacement = 0xffe5edf6; break;
            case 0x3a3022: replacement = 0xfffff0d7; break;
            case 0x174137: replacement = 0xffe0f2e8; break;
            case 0x2b3d61: replacement = 0xffe2ebf8; break;
            case 0x1b3b4a: replacement = 0xffdff0f2; break;
            case 0x1b2840: replacement = 0xffe8eef7; break;
            case 0x142a29: replacement = 0xffe1f3eb; break;
            case 0x211f1c: replacement = 0xfffff4df; break;
            case 0x4b4030: replacement = 0xffe8d9ba; break;
            case 0x2c554e: replacement = 0xffbddbcd; break;
            case 0x3a465a: replacement = 0xffd7e0eb; break;
            case 0x75603a: replacement = 0xffe4d19d; break;
            default: return color;
        }
        return (color & 0xff000000) | (replacement & 0x00ffffff);
    }

    private static int themedTextColor(int color) {
        if (!lightThemeActive) return color;
        if (color == DARK_TEXT || color == Color.WHITE) return TEXT;
        if (color == DARK_MUTED || color == 0xffc2cde2) return MUTED;
        if (color == DARK_BLUE) return BLUE;
        if (color == DARK_GREEN) return GREEN;
        if (color == DARK_GOLD || color == 0xffffbd74 || color == 0xffffb86b) return GOLD;
        if (color == 0xffd6e0ff || color == 0xffdce5ff || color == 0xffd7e2ff) return 0xff3c5575;
        if (color == 0xffa5e1e8) return 0xff287782;
        return color;
    }

    public static void showLoading(Activity activity) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        synchronized (LOADERS) {
            LoadingState state = LOADERS.get(activity);
            if (state == null) {
                state = new LoadingState();
                state.dialog = createLoadingDialog(activity);
                LOADERS.put(activity, state);
            }
            state.requests++;
            if (!state.dialog.isShowing()) {
                state.dialog.show();
                Window window = state.dialog.getWindow();
                if (window != null) {
                    window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                    WindowManager.LayoutParams params = window.getAttributes();
                    int available = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 48);
                    params.width = Math.min(dp(activity, 340), available);
                    params.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    params.gravity = Gravity.CENTER;
                    params.dimAmount = 0.42f;
                    window.setAttributes(params);
                }
            }
        }
    }

    public static void hideLoading(Activity activity) {
        if (activity == null) return;
        synchronized (LOADERS) {
            LoadingState state = LOADERS.get(activity);
            if (state == null) return;
            state.requests--;
            if (state.requests <= 0) {
                try {
                    if (state.dialog != null && state.dialog.isShowing()) state.dialog.dismiss();
                } catch (RuntimeException ignored) {
                }
                LOADERS.remove(activity);
            }
        }
    }

    private static Dialog createLoadingDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout card = vertical(activity);
        card.setPadding(dp(activity, 21), dp(activity, 20), dp(activity, 21), dp(activity, 18));
        card.setBackground(shape(CARD, dp(activity, 24), BORDER));
        card.setElevation(dp(activity, 10));

        LinearLayout header = horizontal(activity);
        ProgressBar spinner = new ProgressBar(activity);
        spinner.setIndeterminate(true);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        spinner.setContentDescription("Carregando");
        header.addView(spinner, new LinearLayout.LayoutParams(dp(activity, 34), dp(activity, 34)));

        LinearLayout copy = vertical(activity);
        copy.setPadding(dp(activity, 14), 0, 0, 0);
        copy.addView(text(activity, "Por favor, aguarde", 16, TEXT, true));
        TextView subtitle = text(activity, "Carregando os dados da loja…", 12, MUTED, false);
        subtitle.setPadding(0, dp(activity, 4), 0, 0);
        copy.addView(subtitle);
        header.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(header);

        ProgressBar bar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        bar.setProgressTintList(ColorStateList.valueOf(BLUE));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(activity, 6));
        barParams.topMargin = dp(activity, 16);
        card.addView(bar, barParams);

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return dialog;
    }

    public static int dp(Activity a, float value) {
        return (int) (value * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static void animateCard(Activity activity, View view) {
        int index;
        synchronized (CARD_ENTRY_COUNTS) {
            index = CARD_ENTRY_COUNTS.containsKey(activity) ? CARD_ENTRY_COUNTS.get(activity) : 0;
            CARD_ENTRY_COUNTS.put(activity, index + 1);
        }
        view.setAlpha(0f);
        view.setTranslationY(dp(activity, 10));
        long delay = Math.min(index * 38L, 228L);
        view.post(() -> view.animate().alpha(1f).translationY(0f).setStartDelay(delay)
                .setDuration(340L).setInterpolator(new DecelerateInterpolator()).start());
    }

    private static void addPressAnimation(View view) {
        view.setOnTouchListener((target, event) -> {
            if (!target.isEnabled()) return false;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                target.animate().cancel();
                target.animate().scaleX(0.975f).scaleY(0.975f).setDuration(90L)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP ||
                    event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                target.animate().scaleX(1f).scaleY(1f).setDuration(170L)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
            return false;
        });
    }

    private static boolean isGlassSurfaceColor(int color) {
        if (color == CARD || color == CARD_ALT) return true;
        int rgb = color & 0x00ffffff;
        switch (rgb) {
            case 0x090d16: case 0x121a28: case 0x1b2639: case 0x151e2d: case 0x0e1420:
            case 0x263b6d: case 0x17243d: case 0x344b78: case 0x202f4c: case 0x202c45:
            case 0x172337: case 0x354767: case 0x263046: case 0x2b3a53: case 0x222f4a:
            case 0x1b2840: case 0x243149: case 0x18263d:
                return true;
            default:
                return false;
        }
    }

    private static int glassFillColor(int color, boolean top) {
        if (!isGlassSurfaceColor(color)) return themedBackgroundColor(color);
        if (lightThemeActive) return top ? 0xeaffffff : 0xcce8f1fb;
        return top ? 0xc72b4566 : 0xa8192b43;
    }

    private static int glassEdgeColor(int requestedStroke) {
        if (lightThemeActive) return 0xa8ffffff;
        return 0x89dceaff;
    }

    public static GradientDrawable shape(int color, int radius, int stroke) {
        boolean glass = isGlassSurfaceColor(color);
        GradientDrawable d;
        if (glass) {
            d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{glassFillColor(color, true), glassFillColor(color, false)});
        } else {
            d = new GradientDrawable();
            d.setColor(themedBackgroundColor(color));
        }
        d.setCornerRadius(radius);
        if (glass) d.setStroke(1, glassEdgeColor(stroke));
        else if (stroke != 0) d.setStroke(1, themedBackgroundColor(stroke));
        return d;
    }

    public static GradientDrawable gradient(int from, int to, int radius, int stroke) {
        boolean glass = isGlassSurfaceColor(from) || isGlassSurfaceColor(to);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{glass ? glassFillColor(from, true) : themedBackgroundColor(from),
                        glass ? glassFillColor(to, false) : themedBackgroundColor(to)});
        d.setCornerRadius(radius);
        if (glass) d.setStroke(1, glassEdgeColor(stroke));
        else if (stroke != 0) d.setStroke(1, themedBackgroundColor(stroke));
        return d;
    }

    private static RippleDrawable ripple(int color, int radius, int stroke, int rippleColor) {
        GradientDrawable content = shape(color, radius, stroke);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(radius);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    public static LinearLayout vertical(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout horizontal(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static TextView text(Activity a, String value, float size, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(themedTextColor(color));
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        else t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setIncludeFontPadding(true);
        return t;
    }

    public static TextView badge(Activity a, String value, int background, int foreground) {
        TextView t = text(a, value, 10, foreground, true);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(a, 10), dp(a, 6), dp(a, 10), dp(a, 6));
        t.setBackground(shape(background, dp(a, 30), 0));
        return t;
    }

    public static LinearLayout screen(Activity a, String title, String subtitle, boolean back) {
        return screenInternal(a, title, subtitle, back, null, null);
    }

    public static LinearLayout screenWithBottomNav(Activity a, String title, String subtitle, boolean back, String selectedTab) {
        return screenInternal(a, title, subtitle, back, selectedTab, null);
    }

    public static LinearLayout screenWithFixedToolbar(Activity a, String title, String subtitle,
                                                       boolean back, View fixedToolbar) {
        return screenInternal(a, title, subtitle, back, null, fixedToolbar);
    }

    public static LinearLayout screenWithBottomNavAndFixedToolbar(Activity a, String title,
            String subtitle, boolean back, String selectedTab, View fixedToolbar) {
        return screenInternal(a, title, subtitle, back, selectedTab, fixedToolbar);
    }

    public static void setTouchFeedback(View view) {
        addPressAnimation(view);
    }

    private static LinearLayout screenInternal(Activity a, String title, String subtitle,
                                               boolean back, String selectedTab, View fixedToolbar) {
        applyPalette(a);
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(Build.VERSION.SDK_INT >= 26 && lightThemeActive ? NAV_BG : BG);
        if (Build.VERSION.SDK_INT >= 23) {
            int systemUi = a.getWindow().getDecorView().getSystemUiVisibility();
            if (lightThemeActive) systemUi |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else systemUi &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                if (lightThemeActive) systemUi |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else systemUi &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            a.getWindow().getDecorView().setSystemUiVisibility(systemUi);
        }
        LinearLayout outer = vertical(a);
        outer.setBackground(new GlassBackdropDrawable(lightThemeActive));

        LinearLayout header = horizontal(a);
        header.setPadding(dp(a, 20), dp(a, 15), dp(a, 20), dp(a, 12));
        if (back) {
            TextView b = text(a, "‹", 32, TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setContentDescription("Voltar");
            b.setBackground(ripple(CARD_ALT, dp(a, 18), BORDER, 0x33ffffff));
            header.addView(b, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));
            addPressAnimation(b);
            b.setOnClickListener(v -> a.finish());
        }

        LinearLayout titles = vertical(a);
        if (back) titles.setPadding(dp(a, 12), 0, 0, 0);
        TextView heading = text(a, title, back ? 21 : 24, TEXT, true);
        heading.setMaxLines(1);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(heading);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView sub = text(a, subtitle, 12, MUTED, false);
            sub.setPadding(0, dp(a, 3), 0, 0);
            sub.setMaxLines(2);
            titles.addView(sub);
        }
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        outer.addView(header);

        if (fixedToolbar != null) {
            LinearLayout pinned = vertical(a);
            pinned.setPadding(dp(a, 20), dp(a, 1), dp(a, 20), dp(a, 11));
            pinned.addView(fixedToolbar, new LinearLayout.LayoutParams(-1, dp(a, 58)));
            outer.addView(pinned, new LinearLayout.LayoutParams(-1, -2));
        }

        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content = vertical(a);
        content.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), dp(a, 32));
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (selectedTab != null) {
            outer.addView(bottomNavigation(a, selectedTab), new LinearLayout.LayoutParams(-1, dp(a, 66)));
        }

        outer.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        outer.setAlpha(0f);
        outer.setTranslationY(dp(a, 8));
        a.setContentView(outer);
        outer.requestApplyInsets();
        outer.post(() -> outer.animate().alpha(1f).translationY(0f).setDuration(320L)
                .setInterpolator(new DecelerateInterpolator()).start());
        return content;
    }

    private static LinearLayout bottomNavigation(Activity a, String selectedTab) {
        LinearLayout nav = vertical(a);
        nav.setPadding(dp(a, 10), 0, dp(a, 10), 0);
        nav.setBackground(shape(lightThemeActive ? CARD : 0xff1b2639, dp(a, 22), BORDER));
        nav.setElevation(dp(a, 8));
        View divider = new View(a);
        divider.setBackgroundColor(lightThemeActive ? 0x99ffffff : 0x5adceaff);
        nav.addView(divider, new LinearLayout.LayoutParams(-1, dp(a, 1)));

        LinearLayout row = horizontal(a);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(a, 12), dp(a, 4), dp(a, 12), dp(a, 4));
        nav.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
        addNavigationTab(a, row, selectedTab, "apps", "Apps", 0);
        addNavigationTab(a, row, selectedTab, "games", "Jogos", 1);
        addNavigationTab(a, row, selectedTab, "profile", "Perfil", 2);
        return nav;
    }

    private static void addNavigationTab(Activity a, LinearLayout row, String selectedTab,
                                         String tab, String label, int iconType) {
        boolean selected = tab.equals(selectedTab);
        LinearLayout item = vertical(a);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(a, 4), dp(a, 3), dp(a, 4), dp(a, 2));
        int activeColor = lightThemeActive ? NAV_ACTIVE : BLUE;
        int inactiveColor = lightThemeActive ? NAV_INACTIVE : MUTED;
        item.setBackground(selected ? shape(lightThemeActive ? NAV_ACTIVE_BG : 0xff243a5e, dp(a, 23), 0) : new ColorDrawable(Color.TRANSPARENT));
        item.setClickable(true);
        item.setFocusable(true);
        item.setContentDescription(label);

        BottomIcon icon = new BottomIcon(a, iconType, selected ? activeColor : inactiveColor);
        item.addView(icon, new LinearLayout.LayoutParams(dp(a, 24), dp(a, 24)));
        TextView caption = text(a, label, 11, selected ? activeColor : inactiveColor, selected);
        caption.setGravity(Gravity.CENTER);
        caption.setPadding(0, dp(a, 1), 0, 0);
        item.addView(caption);
        row.addView(item, new LinearLayout.LayoutParams(0, dp(a, 54), 1));
        addPressAnimation(item);
        item.setOnClickListener(v -> openNavigationTab(a, tab));
    }

    private static void openNavigationTab(Activity activity, String tab) {
        Class<?> target;
        if ("games".equals(tab)) target = GamesActivity.class;
        else if ("profile".equals(tab)) target = AccountActivity.class;
        else target = AppsActivity.class;
        if (activity.getClass() == target) return;
        Intent intent = new Intent(activity, target);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivity(intent);
    }

    private static final class BottomIcon extends View {
        private final int kind;
        private final int color;
        private final float density;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        BottomIcon(Activity activity, int kind, int color) {
            super(activity);
            this.kind = kind;
            this.color = color;
            this.density = activity.getResources().getDisplayMetrics().density;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.save();
            canvas.translate(getWidth() / 2f - 12f * density, getHeight() / 2f - 12f * density);
            paint.setColor(color);
            paint.setStrokeWidth(2f * density);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            if (kind == 0) {
                paint.setStyle(Paint.Style.FILL);
                for (int y = 0; y < 2; y++) for (int x = 0; x < 2; x++) {
                    float left = (3 + x * 10) * density;
                    float top = (3 + y * 10) * density;
                    canvas.drawRoundRect(new RectF(left, top, left + 7 * density, top + 7 * density),
                            1.8f * density, 1.8f * density, paint);
                }
            } else if (kind == 1) {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawRoundRect(new RectF(2.5f * density, 6.5f * density, 21.5f * density, 18.5f * density),
                        5.5f * density, 5.5f * density, paint);
                canvas.drawLine(6 * density, 12.5f * density, 10 * density, 12.5f * density, paint);
                canvas.drawLine(8 * density, 10.5f * density, 8 * density, 14.5f * density, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(16 * density, 11.5f * density, 1.15f * density, paint);
                canvas.drawCircle(18.7f * density, 14.3f * density, 1.15f * density, paint);
            } else {
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(12 * density, 7.5f * density, 3.4f * density, paint);
                Path shoulders = new Path();
                shoulders.moveTo(4 * density, 21 * density);
                shoulders.cubicTo(4.8f * density, 16.5f * density, 8 * density, 14.6f * density,
                        12 * density, 14.6f * density);
                shoulders.cubicTo(16 * density, 14.6f * density, 19.2f * density, 16.5f * density,
                        20 * density, 21 * density);
                canvas.drawPath(shoulders, paint);
            }
            canvas.restore();
        }
    }

    public static TextView label(Activity a, String value) {
        TextView t = text(a, value, 12, MUTED, true);
        t.setLetterSpacing(0.025f);
        t.setPadding(dp(a, 2), dp(a, 17), 0, dp(a, 8));
        return t;
    }

    public static EditText input(Activity a, String hint, boolean multiline) {
        EditText e = new EditText(a);
        e.setSingleLine(!multiline);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(122, 137, 160));
        e.setHint(hint);
        e.setTextSize(14);
        e.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        e.setBackground(shape(Color.rgb(14, 20, 32), dp(a, 20), BORDER));
        e.setElevation(dp(a, 3));
        e.setSelectAllOnFocus(false);
        if (multiline) {
            e.setGravity(Gravity.TOP);
            e.setMinLines(3);
            e.setMaxLines(6);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(a, 5);
        e.setLayoutParams(p);
        return e;
    }

    public static Button button(Activity a, String title, boolean primary) {
        Button b = new Button(a);
        b.setText(title);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setLetterSpacing(0.015f);
        b.setPadding(dp(a, 18), dp(a, 12), dp(a, 18), dp(a, 12));
        if (primary) {
            b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44ffffff),
                    gradient(0xff708dff, 0xff5b73e8, dp(a, 20), 0),
                    shape(Color.WHITE, dp(a, 20), 0)));
        } else {
            b.setBackground(ripple(CARD_ALT, dp(a, 20), BORDER, 0x33ffffff));
        }
        b.setMinHeight(dp(a, 52));
        b.setElevation(dp(a, 5));
        addPressAnimation(b);
        return b;
    }

    public static void gap(Activity a, LinearLayout into, int height) {
        View v = new View(a);
        into.addView(v, new LinearLayout.LayoutParams(1, dp(a, height)));
    }

    public static void section(Activity a, LinearLayout into, String title) {
        TextView t = text(a, title, 18, TEXT, true);
        t.setPadding(0, dp(a, 22), 0, dp(a, 12));
        into.addView(t);
    }

    public static View appCard(Activity a, AppItem app, Runnable onClick) {
        LinearLayout card = vertical(a);
        card.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));
        card.setBackground(ripple(CARD, dp(a, 24), BORDER, 0x24ffffff));
        card.setElevation(dp(a, 7));
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription("Abrir detalhes de " + app.name);

        LinearLayout row = horizontal(a);
        ImageView icon = new ImageView(a);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(shape(Color.rgb(36, 49, 73), dp(a, 20), 0));
        icon.setClipToOutline(true);
        icon.setImageDrawable(a.getDrawable(android.R.drawable.sym_def_app_icon));
        icon.setTag(app.image);
        loadImage(icon, app.image);
        FrameLayout iconFrame = new FrameLayout(a);
        iconFrame.addView(icon, new FrameLayout.LayoutParams(dp(a, 68), dp(a, 68)));
        if (app.blocked) {
            TextView lock = text(a, "🔒", 12, Color.WHITE, true);
            lock.setGravity(Gravity.CENTER);
            lock.setContentDescription("App bloqueado");
            lock.setBackground(shape(0xffb94354, dp(a, 16), 0));
            FrameLayout.LayoutParams lockParams = new FrameLayout.LayoutParams(dp(a, 28), dp(a, 28),
                    Gravity.END | Gravity.BOTTOM);
            iconFrame.addView(lock, lockParams);
        }
        row.addView(iconFrame, new LinearLayout.LayoutParams(dp(a, 68), dp(a, 68)));

        LinearLayout info = vertical(a);
        info.setPadding(dp(a, 14), 0, 0, 0);
        TextView name = text(a, app.name, 16, TEXT, true);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(name);
        if (app.blocked) {
            TextView blockedBadge = badge(a, "🔒 BLOQUEADO", 0xff4b2830, 0xffffc2ca);
            LinearLayout.LayoutParams blockedParams = new LinearLayout.LayoutParams(-2, -2);
            blockedParams.topMargin = dp(a, 5);
            info.addView(blockedBadge, blockedParams);
        }
        TextView publisher = text(a, "Por " + app.developerName, 11, MUTED, false);
        publisher.setMaxLines(1);
        publisher.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams publisherParams = new LinearLayout.LayoutParams(-1, -2);
        publisherParams.topMargin = dp(a, 4);
        info.addView(publisher, publisherParams);
        if (app.subcategory != null && !app.subcategory.trim().isEmpty() && !"Sem categoria".equalsIgnoreCase(app.subcategory)) {
            TextView subcategory = badge(a, app.subcategory, 0xff1b3b4a, 0xffa5e1e8);
            LinearLayout.LayoutParams subcategoryParams = new LinearLayout.LayoutParams(-2, -2);
            subcategoryParams.topMargin = dp(a, 5);
            info.addView(subcategory, subcategoryParams);
        }

        LinearLayout tags = horizontal(a);
        TextView category = badge(a, "Game".equals(app.category) ? "JOGO" : "APLICATIVO", 0xff222f4a, BLUE);
        tags.addView(category);
        if (app.featured) {
            TextView featured = badge(a, "DESTAQUE", 0xff3a3022, GOLD);
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-2, -2);
            fp.leftMargin = dp(a, 6);
            tags.addView(featured, fp);
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(a, 8);
        info.addView(tags, tp);
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(row);

        TextView desc = text(a, app.description, 13, MUTED, false);
        desc.setMaxLines(3);
        desc.setEllipsize(TextUtils.TruncateAt.END);
        desc.setLineSpacing(dp(a, 2), 1f);
        desc.setPadding(0, dp(a, 14), 0, dp(a, 13));
        card.addView(desc);

        TextView open = text(a, "Ver detalhes   ›", 13, BLUE, true);
        open.setGravity(Gravity.CENTER_VERTICAL);
        open.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8));
        open.setBackground(shape(0xff1b2840, dp(a, 14), 0));
        card.addView(open, new LinearLayout.LayoutParams(-2, -2));
        addPressAnimation(card);
        card.setOnClickListener(v -> onClick.run());
        animateCard(a, card);

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(a, 14);
        card.setLayoutParams(p);
        return card;
    }

    public static void loadImage(ImageView target, String src) {
        if (src == null || !src.startsWith("https://")) return;
        IMAGES.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(src).openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(9000);
                c.setInstanceFollowRedirects(true);
                Bitmap bitmap = BitmapFactory.decodeStream(c.getInputStream());
                if (bitmap != null) target.post(() -> {
                    if (src.equals(target.getTag())) target.setImageBitmap(bitmap);
                });
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private static final class GlassBackdropDrawable extends Drawable {
        private final boolean light;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private int alpha = 255;
        private ColorFilter colorFilter;

        GlassBackdropDrawable(boolean light) { this.light = light; }

        @Override public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            float width = bounds.width();
            float height = bounds.height();
            if (width <= 0 || height <= 0) return;
            paint.setAlpha(alpha);
            paint.setColorFilter(colorFilter);
            paint.setShader(new LinearGradient(bounds.left, bounds.top, bounds.right, bounds.bottom,
                    light ? new int[]{0xffe8f0fb, 0xfff8fbff, 0xffe5eef9}
                            : new int[]{0xff0a1220, 0xff101b2e, 0xff0a1423},
                    null, Shader.TileMode.CLAMP));
            canvas.drawRect(bounds, paint);
            paint.setShader(new RadialGradient(bounds.left + width * 0.13f, bounds.top + height * 0.08f,
                    Math.max(width, height) * 0.72f,
                    light ? new int[]{0x704c87e8, 0x2a71a5d8, 0x00000000}
                            : new int[]{0x744c76d4, 0x30365f9a, 0x00000000},
                    new float[]{0f, 0.52f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(bounds, paint);
            paint.setShader(new RadialGradient(bounds.left + width * 0.91f, bounds.top + height * 0.48f,
                    Math.max(width, height) * 0.62f,
                    light ? new int[]{0x503bc5bc, 0x183c91c0, 0x00000000}
                            : new int[]{0x503b71a4, 0x20275d75, 0x00000000},
                    new float[]{0f, 0.48f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(bounds, paint);
            paint.setShader(null);
        }

        @Override public void setAlpha(int value) {
            alpha = Math.max(0, Math.min(255, value));
            invalidateSelf();
        }

        @Override public void setColorFilter(ColorFilter filter) {
            colorFilter = filter;
            invalidateSelf();
        }

        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    public static android.content.Intent appIntent(Activity a, Class<?> target, AppItem x) {
        android.content.Intent i = new android.content.Intent(a, target);
        i.putExtra("id", x.id);
        i.putExtra("name", x.name);
        i.putExtra("category", x.category);
        i.putExtra("image", x.image);
        i.putExtra("apk", x.apk);
        i.putExtra("description", x.description);
        i.putExtra("featured", x.featured);
        i.putExtra("developerName", x.developerName);
        i.putExtra("subcategory", x.subcategory);
        i.putExtra("whatsNew", x.whatsNew);
        i.putExtra("blocked", x.blocked);
        i.putExtra("blockReason", x.blockReason);
        return i;
    }

    public static void openDetails(Activity a, AppItem x) {
        a.startActivity(appIntent(a, AppDetailsActivity.class, x));
    }

    public static AppItem fromIntent(android.content.Intent i) {
        return new AppItem(i.getStringExtra("id"), i.getStringExtra("name"), i.getStringExtra("category"),
                i.getStringExtra("image"), i.getStringExtra("apk"), i.getStringExtra("description"),
                i.getBooleanExtra("featured", false), i.getStringExtra("developerName"),
                i.getStringExtra("subcategory"), i.getStringExtra("whatsNew"),
                i.getBooleanExtra("blocked", false), i.getStringExtra("blockReason"));
    }
}
