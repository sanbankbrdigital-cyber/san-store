package com.sanstore.app;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class SearchActivity extends Activity {
    private static final int REQUEST_VOICE_SEARCH = 4711;
    private static final int REQUEST_AUDIO_PERMISSION = 4712;
    private final ArrayList<AppItem> apps = new ArrayList<>();
    private LinearLayout list;
    private EditText search;
    private Dialog voiceDialog;
    private TextView voiceStatus;
    private Button retryVoiceButton;
    private ImageView voiceMicrophone;
    private VoiceWaveform waveform;
    private SpeechRecognizer speechRecognizer;
    private ValueAnimator pulseAnimator;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        StoreUi.prepareTheme(this);
        LinearLayout searchBar = buildSearchBar();
        LinearLayout content = StoreUi.screenWithFixedToolbar(this, "Buscar",
                "Encontre aplicativos e jogos", true, searchBar);
        list = StoreUi.vertical(this);
        content.addView(list);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render(); }
            @Override public void afterTextChanged(Editable editable) { }
        });
        search.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (keyboard != null) keyboard.hideSoftInputFromWindow(search.getWindowToken(), 0);
                search.clearFocus();
                return true;
            }
            return false;
        });
        ApiClient.getApps(this, (items, error) -> {
            if (isFinishing()) return;
            apps.clear();
            if (error == null) apps.addAll(items);
            else apps.add(AppItem.sanbank());
            render();
        });
    }

    private LinearLayout buildSearchBar() {
        LinearLayout bar = StoreUi.horizontal(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(StoreUi.dp(this, 13), StoreUi.dp(this, 5), StoreUi.dp(this, 6), StoreUi.dp(this, 5));
        bar.setBackground(StoreUi.shape(StoreUi.CARD_ALT, StoreUi.dp(this, 28), 0xff2b394f));
        bar.setElevation(StoreUi.dp(this, 5));

        TextView searchIcon = StoreUi.text(this, "⌕", 25, StoreUi.MUTED, false);
        searchIcon.setGravity(Gravity.CENTER);
        searchIcon.setContentDescription("Pesquisar");
        bar.addView(searchIcon, new LinearLayout.LayoutParams(StoreUi.dp(this, 32), -1));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(StoreUi.TEXT);
        search.setHintTextColor(StoreUi.MUTED);
        search.setHint("Buscar apps e jogos");
        search.setContentDescription("Buscar aplicativos e jogos");
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(StoreUi.dp(this, 5), StoreUi.dp(this, 8), StoreUi.dp(this, 6), StoreUi.dp(this, 8));
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        bar.addView(search, new LinearLayout.LayoutParams(0, -1, 1));

        ImageView microphone = new ImageView(this);
        microphone.setImageResource(android.R.drawable.ic_btn_speak_now);
        microphone.setColorFilter(Color.WHITE);
        microphone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        microphone.setPadding(StoreUi.dp(this, 12), StoreUi.dp(this, 12),
                StoreUi.dp(this, 12), StoreUi.dp(this, 12));
        microphone.setContentDescription("Pesquisar por voz");
        microphone.setClickable(true);
        microphone.setFocusable(true);
        microphone.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55ffffff),
                StoreUi.gradient(0xff708dff, 0xff5b73e8, StoreUi.dp(this, 24), 0),
                StoreUi.shape(Color.WHITE, StoreUi.dp(this, 24), 0)));
        microphone.setOnClickListener(view -> requestVoiceSearch());
        bar.addView(microphone, new LinearLayout.LayoutParams(StoreUi.dp(this, 48), StoreUi.dp(this, 48)));
        return bar;
    }

    private void requestVoiceSearch() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                new AlertDialog.Builder(this)
                        .setTitle("Permitir pesquisa por voz")
                        .setMessage("O microfone só será usado quando você tocar no botão de voz. A busca por texto continua disponível sem essa permissão.")
                        .setNegativeButton("Agora não", null)
                        .setPositiveButton("Continuar", (dialog, which) -> requestPermissions(
                                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION))
                        .show();
            } else {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
            }
            return;
        }
        showVoiceSearchDialog();
    }

    private void showVoiceSearchDialog() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "O reconhecimento de voz não está disponível neste aparelho.", Toast.LENGTH_LONG).show();
            return;
        }
        Dialog dialog = new Dialog(this);
        LinearLayout panel = StoreUi.vertical(this);
        panel.setPadding(StoreUi.dp(this, 23), StoreUi.dp(this, 22),
                StoreUi.dp(this, 23), StoreUi.dp(this, 20));
        panel.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 30), 0xff344767));
        panel.setElevation(StoreUi.dp(this, 18));

        LinearLayout header = StoreUi.horizontal(this);
        TextView title = StoreUi.text(this, "Pesquisa por voz", 19, StoreUi.TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = StoreUi.text(this, "×", 27, StoreUi.MUTED, false);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Fechar pesquisa por voz");
        header.addView(close, new LinearLayout.LayoutParams(StoreUi.dp(this, 38), StoreUi.dp(this, 38)));
        panel.addView(header);
        close.setOnClickListener(view -> dialog.dismiss());

        voiceMicrophone = new ImageView(this);
        voiceMicrophone.setImageResource(android.R.drawable.ic_btn_speak_now);
        voiceMicrophone.setColorFilter(Color.WHITE);
        voiceMicrophone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        voiceMicrophone.setPadding(StoreUi.dp(this, 20), StoreUi.dp(this, 20),
                StoreUi.dp(this, 20), StoreUi.dp(this, 20));
        voiceMicrophone.setBackground(StoreUi.gradient(0xff708dff, 0xff5b73e8, StoreUi.dp(this, 60), 0));
        LinearLayout.LayoutParams micParams = new LinearLayout.LayoutParams(StoreUi.dp(this, 82), StoreUi.dp(this, 82));
        micParams.gravity = Gravity.CENTER_HORIZONTAL;
        micParams.topMargin = StoreUi.dp(this, 20);
        micParams.bottomMargin = StoreUi.dp(this, 13);
        panel.addView(voiceMicrophone, micParams);

        waveform = new VoiceWaveform(this);
        LinearLayout.LayoutParams waveParams = new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 38));
        panel.addView(waveform, waveParams);

        voiceStatus = StoreUi.text(this, "Fale o nome do aplicativo ou jogo", 14, StoreUi.MUTED, false);
        voiceStatus.setGravity(Gravity.CENTER);
        voiceStatus.setMinHeight(StoreUi.dp(this, 46));
        voiceStatus.setPadding(StoreUi.dp(this, 4), StoreUi.dp(this, 10), StoreUi.dp(this, 4), StoreUi.dp(this, 10));
        panel.addView(voiceStatus);

        TextView privacyNote = StoreUi.text(this,
                "O serviço de fala configurado no aparelho converte sua voz em texto.",
                11, StoreUi.MUTED, false);
        privacyNote.setGravity(Gravity.CENTER);
        privacyNote.setPadding(StoreUi.dp(this, 4), StoreUi.dp(this, 3), StoreUi.dp(this, 4), StoreUi.dp(this, 14));
        panel.addView(privacyNote);

        LinearLayout actions = StoreUi.horizontal(this);
        actions.setGravity(Gravity.CENTER);
        retryVoiceButton = StoreUi.button(this, "Tentar novamente", true);
        retryVoiceButton.setVisibility(View.GONE);
        actions.addView(retryVoiceButton, new LinearLayout.LayoutParams(0, StoreUi.dp(this, 48), 1));
        Button cancel = StoreUi.button(this, "Cancelar", false);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(0, StoreUi.dp(this, 48), 1);
        cancelParams.leftMargin = StoreUi.dp(this, 9);
        actions.addView(cancel, cancelParams);
        panel.addView(actions);
        retryVoiceButton.setOnClickListener(view -> startSpeechRecognition());
        cancel.setOnClickListener(view -> dialog.dismiss());

        dialog.setContentView(panel);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnDismissListener(ignored -> {
            stopPulse();
            releaseSpeechRecognizer();
            voiceStatus = null;
            retryVoiceButton = null;
            voiceMicrophone = null;
            waveform = null;
            if (voiceDialog == dialog) voiceDialog = null;
        });
        voiceDialog = dialog;
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = getResources().getDisplayMetrics().widthPixels - StoreUi.dp(this, 32);
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.BOTTOM;
            params.dimAmount = 0.48f;
            window.setAttributes(params);
        }
        dialog.show();
        if (window != null) {
            window.setLayout(getResources().getDisplayMetrics().widthPixels - StoreUi.dp(this, 32),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        startSpeechRecognition();
    }

    private void startSpeechRecognition() {
        if (voiceDialog == null || isFinishing()) return;
        releaseSpeechRecognizer();
        if (retryVoiceButton != null) retryVoiceButton.setVisibility(View.GONE);
        setListeningState(true);
        setVoiceStatus("Conectando ao serviço de fala…");

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                setVoiceStatus("Estou ouvindo… diga o nome do app ou jogo.");
                setListeningState(true);
            }
            @Override public void onBeginningOfSpeech() {
                setVoiceStatus("Pode continuar falando…");
                if (waveform != null) waveform.setLevel(0.75f);
            }
            @Override public void onRmsChanged(float rmsdB) {
                if (waveform != null) waveform.setLevel(Math.max(0f, Math.min(1f, (rmsdB + 10f) / 20f)));
            }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                setListeningState(false);
                setVoiceStatus("Entendi. Preparando sua busca…");
            }
            @Override public void onError(int error) {
                setListeningState(false);
                releaseSpeechRecognizer();
                if (voiceDialog != null && retryVoiceButton != null) {
                    setVoiceStatus(voiceErrorMessage(error));
                    retryVoiceButton.setVisibility(View.VISIBLE);
                }
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String recognized = matches.get(0);
                    if (search != null) {
                        search.setText(recognized);
                        search.setSelection(search.getText().length());
                    }
                    closeVoiceSearchDialog();
                } else {
                    onError(SpeechRecognizer.ERROR_NO_MATCH);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) setVoiceStatus("Ouvindo: “" + matches.get(0) + "”");
            }
            @Override public void onEvent(int eventType, Bundle params) { }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            speechRecognizer.startListening(intent);
        } catch (RuntimeException error) {
            releaseSpeechRecognizer();
            setListeningState(false);
            setVoiceStatus("Não foi possível iniciar a pesquisa por voz.");
            if (retryVoiceButton != null) retryVoiceButton.setVisibility(View.VISIBLE);
        }
    }

    private void setVoiceStatus(String message) {
        if (voiceStatus != null) voiceStatus.setText(message);
    }

    private void setListeningState(boolean listening) {
        if (waveform != null) waveform.setListening(listening);
        if (listening && voiceMicrophone != null) {
            if (pulseAnimator == null) {
                pulseAnimator = ValueAnimator.ofFloat(1f, 1.11f);
                pulseAnimator.setDuration(700L);
                pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
                pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
                pulseAnimator.addUpdateListener(animation -> {
                    if (voiceMicrophone != null) {
                        float scale = (float) animation.getAnimatedValue();
                        voiceMicrophone.setScaleX(scale);
                        voiceMicrophone.setScaleY(scale);
                    }
                });
            }
            if (!pulseAnimator.isStarted()) pulseAnimator.start();
        } else {
            stopPulse();
        }
    }

    private void stopPulse() {
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
            pulseAnimator = null;
        }
        if (voiceMicrophone != null) {
            voiceMicrophone.setScaleX(1f);
            voiceMicrophone.setScaleY(1f);
        }
    }

    private String voiceErrorMessage(int error) {
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
            return "Não consegui entender. Toque em tentar novamente e fale mais perto do microfone.";
        if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT)
            return "O serviço de fala não respondeu. Confira a conexão e tente novamente.";
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
            return "O Android não liberou o microfone. Você pode continuar pesquisando por texto.";
        return "A pesquisa por voz foi interrompida. Tente novamente ou digite sua busca.";
    }

    private void closeVoiceSearchDialog() {
        if (voiceDialog != null) voiceDialog.dismiss();
    }

    private void releaseSpeechRecognizer() {
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (RuntimeException ignored) { }
            try { speechRecognizer.destroy(); } catch (RuntimeException ignored) { }
            speechRecognizer = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_AUDIO_PERMISSION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showVoiceSearchDialog();
        } else {
            Toast.makeText(this, "Sem acesso ao microfone, você ainda pode pesquisar digitando.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        releaseSpeechRecognizer();
        stopPulse();
        if (voiceDialog != null) {
            Dialog dialog = voiceDialog;
            voiceDialog = null;
            dialog.dismiss();
        }
        super.onDestroy();
    }

    private void render() {
        if (list == null || search == null) return;
        list.removeAllViews();
        String query = search.getText().toString().trim().toLowerCase(new Locale("pt", "BR"));
        int count = 0;
        for (AppItem app : apps) {
            String haystack = (app.name + " " + app.description + " " + app.category)
                    .toLowerCase(new Locale("pt", "BR"));
            if (query.isEmpty() || haystack.contains(query)) {
                count++;
                list.addView(StoreUi.appCard(this, app, () -> StoreUi.openDetails(this, app)));
            }
        }
        if (count == 0) {
            TextView empty = StoreUi.text(this, "Nenhum aplicativo encontrado.", 14, StoreUi.MUTED, false);
            empty.setPadding(StoreUi.dp(this, 4), StoreUi.dp(this, 20), StoreUi.dp(this, 4), 0);
            list.addView(empty);
        }
    }

    private static final class VoiceWaveform extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private boolean listening;
        private float level = 0.3f;

        VoiceWaveform(Activity activity) {
            super(activity);
            density = activity.getResources().getDisplayMetrics().density;
            paint.setColor(StoreUi.BLUE);
            paint.setStyle(Paint.Style.FILL);
        }

        void setListening(boolean active) { listening = active; postInvalidate(); }
        void setLevel(float value) { level = Math.max(0f, Math.min(1f, value)); postInvalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float unit = density;
            float centerY = getHeight() / 2f;
            float barWidth = 4f * unit;
            float gap = 7f * unit;
            float total = 7f * barWidth + 6f * gap;
            float left = (getWidth() - total) / 2f;
            long time = System.currentTimeMillis();
            for (int i = 0; i < 7; i++) {
                float motion = listening ? 0.30f + 0.70f * (float)Math.abs(Math.sin(time / 190.0 + i * 0.78)) : 0.24f;
                float height = (5f + level * 24f * motion) * unit;
                float x = left + i * (barWidth + gap);
                paint.setAlpha(155 + (i % 3) * 32);
                canvas.drawRoundRect(new RectF(x, centerY - height / 2f, x + barWidth, centerY + height / 2f),
                        barWidth / 2f, barWidth / 2f, paint);
            }
            paint.setAlpha(255);
            if (listening) postInvalidateDelayed(36L);
        }
    }
}
