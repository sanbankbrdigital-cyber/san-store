package com.sanstore.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class EditPublishedAppActivity extends Activity {
    private AppItem app;
    private EditText imageUrl;
    private EditText apkUrl;
    private EditText description;
    private EditText whatsNew;
    private TextView status;
    private Button submit;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        app = StoreUi.fromIntent(getIntent());
        render();
    }

    private void render() {
        LinearLayout content = StoreUi.screen(this, "Atualizar aplicativo", app.name, true);

        LinearLayout notice = StoreUi.vertical(this);
        notice.setPadding(StoreUi.dp(this, 15), StoreUi.dp(this, 14), StoreUi.dp(this, 15), StoreUi.dp(this, 14));
        notice.setBackground(StoreUi.shape(StoreUi.CARD, StoreUi.dp(this, 20), 0xff2b3a53));
        notice.setElevation(StoreUi.dp(this, 5));
        notice.addView(StoreUi.text(this, "O app atual continua publicado enquanto o administrador analisa esta atualização.",
                13, StoreUi.MUTED, false));
        content.addView(notice);

        StoreUi.section(this, content, "Dados da atualização");
        StoreUi.label(this, "URL HTTPS do novo ícone");
        imageUrl = StoreUi.input(this, "https://.../icone.webp", false);
        imageUrl.setText(app.image);
        content.addView(imageUrl);

        StoreUi.label(this, "URL HTTPS do novo APK");
        apkUrl = StoreUi.input(this, "https://.../aplicativo.apk", false);
        apkUrl.setText(app.apk);
        content.addView(apkUrl);

        StoreUi.label(this, "Descrição do aplicativo");
        description = StoreUi.input(this, "Descreva o que o app faz", true);
        description.setText(app.description);
        content.addView(description);

        StoreUi.label(this, "Novidades desta versão");
        whatsNew = StoreUi.input(this, "Descreva as novidades deste lançamento (até 500 caracteres)", true);
        whatsNew.setText(app.whatsNew);
        content.addView(whatsNew);

        status = StoreUi.text(this, "", 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 10), 0, StoreUi.dp(this, 8));
        content.addView(status);

        submit = StoreUi.button(this, "Enviar atualização para aprovação", true);
        submit.setOnClickListener(v -> sendForReview());
        content.addView(submit, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));
    }

    private void sendForReview() {
        String image = imageUrl.getText().toString().trim();
        String apk = apkUrl.getText().toString().trim();
        String text = description.getText().toString().trim();
        String changes = whatsNew.getText().toString().trim();
        if (!image.startsWith("https://") || !apk.startsWith("https://") || text.length() < 5 ||
                text.length() > 350 || changes.length() > 500) {
            status.setText("Use URLs HTTPS válidas; descrição de 5 a 350 caracteres e novidades de até 500.");
            status.setTextColor(StoreUi.GOLD);
            return;
        }
        submit.setEnabled(false);
        submit.setText("Enviando para análise…");
        status.setText("O app publicado não muda até a aprovação do administrador.");
        status.setTextColor(StoreUi.MUTED);
        ApiClient.submitAppUpdate(this, app, image, apk, text, changes, (response, error) -> {
            if (isFinishing()) return;
            submit.setEnabled(true);
            submit.setText("Enviar atualização para aprovação");
            if (error != null) {
                status.setText(error.getMessage());
                status.setTextColor(StoreUi.GOLD);
                return;
            }
            Toast.makeText(this, "Atualização enviada para aprovação.", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
