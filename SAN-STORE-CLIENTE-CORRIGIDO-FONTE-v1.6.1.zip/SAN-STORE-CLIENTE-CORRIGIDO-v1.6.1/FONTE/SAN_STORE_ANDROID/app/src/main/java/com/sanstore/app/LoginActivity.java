package com.sanstore.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText identifier;
    private EditText password;
    private TextView status;
    private Button loginButton;
    private Button registerButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!ApiClient.sessionToken(this).isEmpty()) verifySavedSession();
        else renderLogin("");
    }

    private void verifySavedSession() {
        LinearLayout content = StoreUi.screen(this, "SAN STORE", "Verificando sua sessão", false);
        TextView message = StoreUi.text(this, "Conectando à sua conta com segurança…", 14, StoreUi.MUTED, false);
        content.addView(message);
        ApiClient.verifySession(this, (session, error) -> {
            if (isFinishing()) return;
            if (error == null) openStore();
            else renderLogin("Não foi possível validar a sessão. Entre novamente.");
        });
    }

    private void renderLogin(String notice) {
        LinearLayout content = StoreUi.screen(this, "SAN STORE", "Entre para acessar a loja", false);

        LinearLayout hero = StoreUi.vertical(this);
        hero.setPadding(StoreUi.dp(this, 18), StoreUi.dp(this, 19), StoreUi.dp(this, 18), StoreUi.dp(this, 19));
        hero.setBackground(StoreUi.gradient(0xff263b6d, 0xff17243d, StoreUi.dp(this, 24), 0xff344b78));
        hero.setElevation(StoreUi.dp(this, 6));
        hero.addView(StoreUi.badge(this, "CONTA SAN STORE", 0xff2b3d61, 0xffd7e2ff));
        TextView headline = StoreUi.text(this, "Sua loja, do seu jeito.", 22, StoreUi.TEXT, true);
        headline.setPadding(0, StoreUi.dp(this, 13), 0, 0);
        hero.addView(headline);
        TextView description = StoreUi.text(this, "Entre ou crie sua conta para continuar.", 13, 0xffc2cde2, false);
        description.setPadding(0, StoreUi.dp(this, 7), 0, 0);
        hero.addView(description);
        content.addView(hero);

        StoreUi.section(this, content, "Entrar na conta");
        StoreUi.label(this, "Conta ou e-mail SAN STORE");
        identifier = StoreUi.input(this, "conta ou nome@sanstore.com", false);
        identifier.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        content.addView(identifier);

        StoreUi.label(this, "Senha");
        password = StoreUi.input(this, "Sua senha (8 a 10 caracteres)", false);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        content.addView(password);

        status = StoreUi.text(this, notice, 12, StoreUi.GOLD, false);
        status.setPadding(0, StoreUi.dp(this, 7), 0, StoreUi.dp(this, 8));
        content.addView(status);

        loginButton = StoreUi.button(this, "Entrar", true);
        loginButton.setOnClickListener(v -> login());
        content.addView(loginButton, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 54)));

        TextView separator = StoreUi.text(this, "AINDA NÃO TEM CONTA?", 11, StoreUi.MUTED, true);
        separator.setLetterSpacing(0.06f);
        separator.setPadding(0, StoreUi.dp(this, 22), 0, StoreUi.dp(this, 9));
        content.addView(separator);
        registerButton = StoreUi.button(this, "Criar uma conta", false);
        registerButton.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        content.addView(registerButton, new LinearLayout.LayoutParams(-1, StoreUi.dp(this, 52)));
    }

    private void login() {
        String user = identifier.getText().toString().trim();
        String pass = password.getText().toString();
        if (user.isEmpty()) { showError("Digite sua conta ou e-mail."); return; }
        if (!passwordValid(pass)) { showError("A senha precisa ter 8 a 10 caracteres, com maiúscula, minúscula, número e símbolo."); return; }

        setBusy(true);
        status.setText("Entrando com segurança…");
        status.setTextColor(StoreUi.MUTED);
        ApiClient.login(this, user, pass, (session, error) -> {
            if (isFinishing()) return;
            setBusy(false);
            if (error != null) { showError(error.getMessage()); return; }
            openStore();
        });
    }

    private boolean passwordValid(String value) {
        if (value == null || value.length() < 8 || value.length() > 10) return false;
        boolean upper = false, lower = false, digit = false, special = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= 'A' && c <= 'Z') upper = true;
            else if (c >= 'a' && c <= 'z') lower = true;
            else if (c >= '0' && c <= '9') digit = true;
            else special = true;
        }
        return upper && lower && digit && special;
    }

    private void setBusy(boolean busy) {
        loginButton.setEnabled(!busy);
        registerButton.setEnabled(!busy);
        loginButton.setText(busy ? "Aguarde…" : "Entrar");
    }

    private void showError(String message) {
        status.setText(message == null || message.trim().isEmpty() ? "Não foi possível entrar. Confira os dados e tente novamente." : message);
        status.setTextColor(StoreUi.GOLD);
    }

    private void openStore() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
